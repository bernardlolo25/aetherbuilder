<?php
require_once __DIR__ . '/config/database.php';

$message = '';
$error = '';

try {
    $count = (int) db()->query("SELECT COUNT(*) FROM admins")->fetchColumn();
    if ($count > 0) {
        http_response_code(403);
        exit('Setup is locked because an administrator account already exists. For security, delete setup.php from your hosting account.');
    }
} catch (Throwable $e) {
    http_response_code(500);
    exit('Database connection or table error: ' . htmlspecialchars($e->getMessage()) . '<br>Please confirm you imported schema.sql into your MySQL database.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $key = $_POST['setup_key'] ?? '';
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!hash_equals(ADMIN_SETUP_KEY, $key)) {
        $error = 'Incorrect setup key. Check ADMIN_SETUP_KEY in config/config.php.';
    } elseif (!preg_match('/^[A-Za-z0-9_.-]{3,100}$/', $username)) {
        $error = 'Username must be 3–100 characters and use letters, numbers, dots, dashes or underscores.';
    } elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 10) {
        $error = 'Use a password with at least 10 characters.';
    } else {
        $stmt = db()->prepare("INSERT INTO admins (username, email, password_hash, role) VALUES (?, ?, ?, 'superadmin')");
        $stmt->execute([$username, $email ?: null, password_hash($password, PASSWORD_DEFAULT)]);
        $message = 'Superadmin created successfully! Delete setup.php from your htdocs folder now, then click Sign in below.';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Initial Administrator Setup</title>
  <link rel="stylesheet" href="assets/css/app.css?v=1.4.0">
  <script src="assets/js/admin.js?v=1.4.0" defer></script>
</head>
<body class="auth-page">
  <main class="auth-card">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <div class="brand-mark">⚡</div>
      <button id="theme-toggle-btn" class="theme-btn" type="button"><span id="theme-label">🌙 Dark Mode</span></button>
    </div>
    <h1>Initial Administrator Setup</h1>
    <p style="color:var(--text-muted); font-size:13px; margin:0 0 16px;">Create the first superadmin account for your Messenger Bot.</p>

    <?php if ($error): ?>
      <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($message): ?>
      <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
      <p style="margin-top:16px;"><a class="btn btn-primary" href="admin/login.php" style="width:100%; text-align:center;">Go to Admin Login ➔</a></p>
    <?php else: ?>
      <form method="post">
        <div class="form-group">
          <label>Setup Key (from config/config.php)</label>
          <input type="password" name="setup_key" required autocomplete="off" placeholder="Paste ADMIN_SETUP_KEY">
        </div>
        <div class="form-group">
          <label>Superadmin Username</label>
          <input name="username" required minlength="3" maxlength="100" placeholder="e.g. admin">
        </div>
        <div class="form-group">
          <label>Email Address (Optional)</label>
          <input type="email" name="email" placeholder="admin@example.com">
        </div>
        <div class="form-group">
          <label>Password (Minimum 10 characters)</label>
          <input type="password" name="password" required minlength="10" autocomplete="new-password">
        </div>
        <button class="btn btn-primary" style="width:100%; margin-top:8px;" type="submit">Create Superadmin Account</button>
      </form>
    <?php endif; ?>
  </main>
</body>
</html>
