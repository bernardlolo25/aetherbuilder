<?php
/**
 * Shared Admin Navigation Layout (Production / Apache Single-Host Architecture)
 * Produces the clean dark sidebar and header matching the high-end dashboard design
 * Includes live versioning indicators and GitHub update notification alerts
 */

require_once __DIR__ . '/updater.php';

function renderAdminHeader($activePage = 'dashboard') {
    $pdo = function_exists('db') ? db() : null;
    $currentVersion = AppUpdater::getCurrentVersion();

    // Self-healing database migration: ensure flow_nodes.node_type supports 'carousel' and modern types
    if ($pdo) {
        try {
            $pdo->exec("ALTER TABLE flow_nodes MODIFY COLUMN node_type VARCHAR(50) NOT NULL DEFAULT 'message'");
        } catch (Throwable $e) {}
    }

    // Check for pending update from cache
    $updateInfo = null;
    $hasUpdate = false;
    $activeToken = AppUpdater::getGitHubToken($pdo);
    if ($pdo) {
        try {
            $updateInfo = AppUpdater::checkForUpdates($pdo, false);
            $hasUpdate = !empty($updateInfo['has_update']);
        } catch (Throwable $e) {}
    }

    $pages = [
        'dashboard' => [
            'title' => 'Dashboard',
            'url' => 'dashboard.php',
            'svg' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>'
        ],
        'ai-studio' => [
            'title' => 'AI Flow Studio',
            'url' => 'ai-studio.php',
            'badge' => 'AI Assist',
            'badge_color' => 'badge-purple',
            'svg' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg>'
        ],
        'products' => [
            'title' => 'Products & Services',
            'url' => 'products.php',
            'badge' => 'Catalog',
            'badge_color' => 'badge-emerald',
            'svg' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>'
        ],
        'flow-builder' => [
            'title' => 'Decision Trees',
            'url' => 'flow-builder.php',
            'svg' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg>'
        ],
        'keywords' => [
            'title' => 'Keyword Triggers',
            'url' => 'keywords.php',
            'svg' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>'
        ],
        'responses' => [
            'title' => 'FAQ Knowledge Base',
            'url' => 'responses.php',
            'badge' => 'Approved',
            'badge_color' => 'badge-blue',
            'svg' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>'
        ],
        'simulator' => [
            'title' => 'Test Simulator',
            'url' => 'simulator.php',
            'svg' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>'
        ],
        'conversations' => [
            'title' => 'Live Conversations',
            'url' => 'conversations.php',
            'svg' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>'
        ],
        'leads' => [
            'title' => 'Captured Leads',
            'url' => 'leads.php',
            'svg' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>'
        ],
        'analytics' => [
            'title' => 'Bot Analytics',
            'url' => 'analytics.php',
            'badge' => 'Insights',
            'badge_color' => 'badge-blue',
            'svg' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>'
        ],
        'webhook-logs' => [
            'title' => 'Webhook Inspector',
            'url' => 'webhook-logs.php',
            'badge' => 'Live',
            'badge_color' => 'badge-emerald',
            'svg' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>'
        ],
        'updates' => [
            'title' => 'System Updates',
            'url' => 'updates.php',
            'badge' => $hasUpdate ? ('v' . htmlspecialchars($updateInfo['latest_version'])) : '',
            'badge_color' => 'badge-amber',
            'svg' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>'
        ],
        'settings' => [
            'title' => 'Bot Settings',
            'url' => 'settings.php',
            'svg' => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>'
        ],
    ];

    $username = $_SESSION['admin_username'] ?? 'Admin';
    $role = $_SESSION['admin_role'] ?? 'Administrator';
    $avatarInitial = strtoupper(substr($username, 0, 1));
?>
<aside class="sidebar">
  <div class="side-brand">
    <div class="brand-mark">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
      </svg>
    </div>
    <div class="brand-info">
      <div style="display: flex; align-items: center; gap: 6px;">
        <span class="brand-title">Chat Bot Admin</span>
      </div>
      <span class="brand-subtitle">
        Enterprise Suite • <strong class="version-tag" title="Installed Version">v<?php echo htmlspecialchars($currentVersion); ?></strong>
      </span>
    </div>
  </div>

  <nav class="sidebar-nav">
    <?php foreach ($pages as $key => $page): ?>
      <a href="<?php echo htmlspecialchars($page['url']); ?>" class="<?php echo ($activePage === $key) ? 'active' : ''; ?>">
        <?php echo $page['svg']; ?>
        <span><?php echo htmlspecialchars($page['title']); ?></span>
        <?php if (!empty($page['badge'])): ?>
          <span class="nav-badge <?php echo $page['badge_color'] ?? ''; ?>"><?php echo htmlspecialchars($page['badge']); ?></span>
        <?php endif; ?>
      </a>
    <?php endforeach; ?>
  </nav>

  <div class="side-bottom">
    <div class="admin-badge">
      <span class="admin-avatar"><?php echo htmlspecialchars($avatarInitial); ?></span>
      <div class="admin-meta">
        <span class="admin-name"><?php echo htmlspecialchars($username); ?></span>
        <span class="admin-role"><?php echo htmlspecialchars($role); ?></span>
      </div>
    </div>
    <a href="logout.php" class="logout-link" title="Sign Out">Sign out ↗</a>
  </div>
</aside>

<?php if ($hasUpdate && $activePage !== 'updates'): ?>
<!-- Global Update Notification Banner -->
<div class="update-notification-banner" id="global-update-banner">
  <div class="update-banner-content">
    <div class="update-banner-icon">🚀</div>
    <div class="update-banner-text">
      <strong>Important Update Available!</strong>
      <span>Version <strong>v<?php echo htmlspecialchars($updateInfo['latest_version']); ?></strong> is ready to install (You are currently on v<?php echo htmlspecialchars($currentVersion); ?>).</span>
    </div>
  </div>
  <div class="update-banner-actions">
    <a href="updates.php" class="btn btn-sm btn-white">View Changelog</a>
    <button type="button" class="btn btn-sm btn-accent" onclick="startQuickUpdate('<?php echo htmlspecialchars($updateInfo['latest_version']); ?>', '<?php echo htmlspecialchars($updateInfo['download_url'] ?? ''); ?>', '<?php echo htmlspecialchars($activeToken); ?>')">
      ⚡ Update Now
    </button>
  </div>
</div>
<?php endif; ?>

<!-- Quick Update Modal Container -->
<div id="quick-update-modal" class="update-modal-backdrop" style="display: none;">
  <div class="update-modal-card">
    <div class="update-modal-header">
      <div style="display: flex; align-items: center; gap: 10px;">
        <div class="update-modal-icon">🔄</div>
        <div>
          <h3 style="margin: 0; font-size: 1.1rem; font-weight: 700;">Installing System Update</h3>
          <p style="margin: 0; font-size: 0.8rem; color: var(--text-muted);">Downloading and applying update package...</p>
        </div>
      </div>
    </div>
    <div class="update-modal-body">
      <div class="update-progress-bar-wrap">
        <div id="quick-update-progress-bar" class="update-progress-bar" style="width: 15%;"></div>
      </div>
      <div id="quick-update-status-text" class="update-status-text">Connecting to update server...</div>
      <div class="update-preservation-notice">
        🔒 <strong>Safe Update:</strong> Database credentials in <code>config/config.php</code> and customer conversation history are strictly protected.
      </div>
    </div>
  </div>
</div>
<?php } ?>
