<?php
/**
 * Authentication and Session Management
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

// Safe session startup across all PHP versions (PHP 7.0 - 8.4)
if (session_status() === PHP_SESSION_NONE) {
    @ini_set('session.cookie_httponly', '1');
    @session_start();
}

/**
 * Check if admin is currently authenticated
 */
function isLoggedIn(): bool {
    return !empty($_SESSION['admin_id']);
}

/**
 * Require admin authentication
 */
function require_admin(): void {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

/**
 * Require login alias (backward and cross compatibility)
 */
function requireLogin(): void {
    require_admin();
}


/**
 * Safe HTML string escaping
 */
function e(?string $v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}
