<?php
/**
 * GitHub Self-Updater & Version Engine
 * Compatible with Apache & Nginx PHP Hosting
 * Safely preserves configuration and database credentials while updating files
 */

class AppUpdater {
    private static $versionCacheKey = 'update_check_cache';
    private static $versionCacheTimeKey = 'update_check_time';

    /**
     * Get local current version
     */
    public static function getCurrentVersion() {
        $versionFile = __DIR__ . '/../version.json';
        if (file_exists($versionFile)) {
            $data = json_decode(@file_get_contents($versionFile), true);
            if (!empty($data['version'])) {
                return $data['version'];
            }
        }
        if (defined('APP_VERSION')) {
            return APP_VERSION;
        }
        return '1.1.0';
    }

    /**
     * Get full version metadata
     */
    public static function getVersionData() {
        $versionFile = __DIR__ . '/../version.json';
        if (file_exists($versionFile)) {
            $data = json_decode(@file_get_contents($versionFile), true);
            if (is_array($data)) {
                return $data;
            }
        }
        return [
            'version' => self::getCurrentVersion(),
            'release_date' => date('Y-m-d'),
            'app_name' => defined('APP_NAME') ? APP_NAME : 'Chat Assistant Bot',
            'changelog' => ['Initial release']
        ];
    }

    /**
     * Get configured GitHub repository
     */
    public static function getGitHubRepo($pdo = null) {
        if ($pdo) {
            try {
                $stmt = $pdo->prepare("SELECT setting_value FROM bot_settings WHERE setting_key = 'github_repo' LIMIT 1");
                $stmt->execute();
                $val = $stmt->fetchColumn();
                if (!empty($val)) return trim($val);
            } catch (Throwable $e) {}
        }
        return defined('GITHUB_REPO') ? GITHUB_REPO : 'bernardlolo25/Chat-Asistant-Bot';
    }

    /**
     * Get configured branch
     */
    public static function getGitHubBranch($pdo = null) {
        if ($pdo) {
            try {
                $stmt = $pdo->prepare("SELECT setting_value FROM bot_settings WHERE setting_key = 'github_branch' LIMIT 1");
                $stmt->execute();
                $val = $stmt->fetchColumn();
                if (!empty($val)) return trim($val);
            } catch (Throwable $e) {}
        }
        return defined('GITHUB_BRANCH') ? GITHUB_BRANCH : 'main';
    }

    /**
     * Get GitHub Personal Access Token (for private repos)
     */
    public static function getGitHubToken($pdo = null) {
        if ($pdo) {
            try {
                $stmt = $pdo->prepare("SELECT setting_value FROM bot_settings WHERE setting_key = 'github_token' LIMIT 1");
                $stmt->execute();
                $val = $stmt->fetchColumn();
                if (!empty($val)) return trim($val);
            } catch (Throwable $e) {}
        }
        if (defined('GITHUB_TOKEN') && !empty(GITHUB_TOKEN)) {
            return GITHUB_TOKEN;
        }
        return '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';
    }

    /**
     * Perform HTTP GET via cURL (supported over standard secure port 443)
     */
    public static function fetchUrl($url, $token = '', $timeout = 10) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        
        $headers = [
            'User-Agent: MessengerBot-Updater/' . self::getCurrentVersion(),
            'Accept: application/vnd.github.v3+json'
        ];
        if (!empty($token)) {
            $headers[] = 'Authorization: token ' . $token;
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        return [
            'code' => $httpCode,
            'body' => $response,
            'error' => $error
        ];
    }

    /**
     * Check GitHub for new updates
     */
    public static function checkForUpdates($pdo = null, $forceRefresh = false) {
        $currentVersion = self::getCurrentVersion();
        $repo = self::getGitHubRepo($pdo);
        $branch = self::getGitHubBranch($pdo);
        $token = self::getGitHubToken($pdo);

        // Check if demo/simulated update is stored in DB
        if ($pdo) {
            try {
                $stmt = $pdo->prepare("SELECT setting_value FROM bot_settings WHERE setting_key = 'simulated_update' LIMIT 1");
                $stmt->execute();
                $simulated = $stmt->fetchColumn();
                if (!empty($simulated)) {
                    $simData = json_decode($simulated, true);
                    if ($simData && version_compare($simData['version'], $currentVersion, '>')) {
                        return [
                            'has_update' => true,
                            'current_version' => $currentVersion,
                            'latest_version' => $simData['version'],
                            'release_name' => $simData['title'] ?? ('Version ' . $simData['version']),
                            'changelog' => $simData['changelog'] ?? ['Important bug fixes and stability updates.'],
                            'download_url' => $simData['download_url'] ?? '',
                            'published_at' => $simData['published_at'] ?? date('Y-m-d H:i:s'),
                            'is_simulated' => true,
                            'repo' => $repo
                        ];
                    }
                }
            } catch (Throwable $e) {}
        }

        // Cache lookup unless force refresh
        if (!$forceRefresh && $pdo) {
            try {
                $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM bot_settings WHERE setting_key IN ('update_check_cache', 'update_check_time')");
                $stmt->execute();
                $rows = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
                $cachedJson = $rows['update_check_cache'] ?? null;
                $cacheTime = (int)($rows['update_check_time'] ?? 0);

                // Cache valid for 15 minutes (900 seconds)
                if ($cachedJson && (time() - $cacheTime) < 900) {
                    $cachedData = json_decode($cachedJson, true);
                    if (is_array($cachedData)) {
                        $cachedData['current_version'] = $currentVersion;
                        $cachedData['has_update'] = version_compare($cachedData['latest_version'] ?? '0.0.0', $currentVersion, '>');
                        return $cachedData;
                    }
                }
            } catch (Throwable $e) {}
        }

        $latestVersion = null;
        $changelog = [];
        $downloadUrl = '';
        $releaseName = '';
        $publishedAt = '';

        // 1. Try GitHub Releases API first
        $releasesApiUrl = "https://api.github.com/repos/{$repo}/releases/latest";
        $res = self::fetchUrl($releasesApiUrl, $token);

        if ($res['code'] === 200 && !empty($res['body'])) {
            $releaseData = json_decode($res['body'], true);
            if ($releaseData && !empty($releaseData['tag_name'])) {
                $latestVersion = ltrim($releaseData['tag_name'], 'vV');
                $releaseName = $releaseData['name'] ?? ('Release ' . $latestVersion);
                $publishedAt = $releaseData['published_at'] ?? '';
                
                // Get download zip
                if (!empty($releaseData['assets']) && is_array($releaseData['assets'])) {
                    foreach ($releaseData['assets'] as $asset) {
                        if (stripos($asset['name'], '.zip') !== false) {
                            $downloadUrl = !empty($token) ? ($asset['url'] ?? $asset['browser_download_url']) : $asset['browser_download_url'];
                            break;
                        }
                    }
                }
                if (empty($downloadUrl) && !empty($releaseData['zipball_url'])) {
                    $downloadUrl = $releaseData['zipball_url'];
                }

                // Parse changelog lines
                if (!empty($releaseData['body'])) {
                    $lines = explode("\n", $releaseData['body']);
                    foreach ($lines as $line) {
                        $trimmed = trim($line, " \t\n\r\0\x0B*-#•");
                        if (!empty($trimmed)) {
                            $changelog[] = $trimmed;
                        }
                    }
                }
            }
        }

        // 2. Fallback: Check raw version.json from branch
        if (!$latestVersion) {
            // First try official GitHub Contents API for private repos
            $contentsApiUrl = "https://api.github.com/repos/{$repo}/contents/version.json?ref={$branch}";
            $chContents = curl_init();
            curl_setopt($chContents, CURLOPT_URL, $contentsApiUrl);
            curl_setopt($chContents, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($chContents, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($chContents, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($chContents, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($chContents, CURLOPT_TIMEOUT, 10);
            $h = [
                'User-Agent: MessengerBot-Updater/' . self::getCurrentVersion(),
                'Accept: application/vnd.github.v3.raw'
            ];
            if (!empty($token)) {
                $h[] = 'Authorization: token ' . $token;
            }
            curl_setopt($chContents, CURLOPT_HTTPHEADER, $h);
            $rawBody = curl_exec($chContents);
            $codeContents = curl_getinfo($chContents, CURLINFO_HTTP_CODE);
            curl_close($chContents);

            if ($codeContents === 200 && !empty($rawBody)) {
                $rawJson = json_decode($rawBody, true);
                if (!empty($rawJson['version'])) {
                    $latestVersion = ltrim($rawJson['version'], 'vV');
                    $releaseName = $rawJson['title'] ?? ('Version ' . $latestVersion);
                    $changelog = $rawJson['changelog'] ?? ['Performance improvements and fixes.'];
                    $publishedAt = $rawJson['release_date'] ?? date('Y-m-d');
                    $downloadUrl = "https://github.com/{$repo}/releases/download/v{$latestVersion}/Chat-Assistant-Bot-v{$latestVersion}.zip";
                }
            }

            if (!$latestVersion) {
                $rawUrl = "https://raw.githubusercontent.com/{$repo}/{$branch}/version.json";
                $resRaw = self::fetchUrl($rawUrl, $token);
                if ($resRaw['code'] !== 200 || empty($resRaw['body'])) {
                    $rawUrl = "https://raw.githubusercontent.com/{$repo}/{$branch}/public/infinityfree_messenger/version.json";
                    $resRaw = self::fetchUrl($rawUrl, $token);
                }
                if ($resRaw['code'] === 200 && !empty($resRaw['body'])) {
                    $rawJson = json_decode($resRaw['body'], true);
                    if (!empty($rawJson['version'])) {
                        $latestVersion = ltrim($rawJson['version'], 'vV');
                        $releaseName = $rawJson['title'] ?? ('Version ' . $latestVersion);
                        $changelog = $rawJson['changelog'] ?? ['Performance improvements and fixes.'];
                        $publishedAt = $rawJson['release_date'] ?? date('Y-m-d');
                        $downloadUrl = "https://github.com/{$repo}/releases/download/v{$latestVersion}/Chat-Assistant-Bot-v{$latestVersion}.zip";
                    }
                }
            }
        }

        // Default if repo not yet created or unreachable
        if (!$latestVersion) {
            $latestVersion = $currentVersion;
            $releaseName = 'Version ' . $currentVersion;
            $changelog = ['System is up-to-date with current GitHub branch.'];
        }

        $hasUpdate = version_compare($latestVersion, $currentVersion, '>');

        $result = [
            'has_update' => $hasUpdate,
            'current_version' => $currentVersion,
            'latest_version' => $latestVersion,
            'release_name' => $releaseName,
            'changelog' => $changelog,
            'download_url' => $downloadUrl,
            'published_at' => $publishedAt,
            'repo' => $repo,
            'checked_at' => date('Y-m-d H:i:s')
        ];

        // Save to cache
        if ($pdo) {
            try {
                $stmt = $pdo->prepare("INSERT INTO bot_settings (setting_key, setting_value) VALUES ('update_check_cache', :v), ('update_check_time', :t) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
                $stmt->execute([
                    ':v' => json_encode($result),
                    ':t' => (string)time()
                ]);
            } catch (Throwable $e) {}
        }

        return $result;
    }

    /**
     * Get system environment info (PHP, ZipArchive, permissions)
     */
    public static function getSystemInfo() {
        $rootDir = realpath(__DIR__ . '/..');
        $backupsDir = $rootDir . '/backups';
        
        return [
            'php_version' => PHP_VERSION,
            'zip_archive' => class_exists('ZipArchive'),
            'root_writable' => is_writable($rootDir),
            'config_writable' => is_writable($rootDir . '/config'),
            'backups_ready' => is_dir($backupsDir) ? is_writable($backupsDir) : is_writable($rootDir),
            'max_upload_size' => ini_get('upload_max_filesize'),
            'max_post_size' => ini_get('post_max_size'),
            'curl_available' => function_exists('curl_version'),
            'current_version' => self::getCurrentVersion(),
            'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Web Server',
        ];
    }

    /**
     * Create safety backup before extraction
     */
    public static function createSafetyBackup($rootDir, $currentVersion) {
        $backupDir = $rootDir . '/backups';
        if (!is_dir($backupDir)) {
            @mkdir($backupDir, 0755, true);
        }

        $timestamp = date('Ymd_His');
        $backupFilename = "backup_v{$currentVersion}_{$timestamp}.zip";
        $backupPath = $backupDir . '/' . $backupFilename;

        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($backupPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
                if (file_exists($rootDir . '/config/config.php')) {
                    $zip->addFile($rootDir . '/config/config.php', 'config/config.php');
                }
                if (file_exists($rootDir . '/version.json')) {
                    $zip->addFile($rootDir . '/version.json', 'version.json');
                }
                if (file_exists($rootDir . '/schema.sql')) {
                    $zip->addFile($rootDir . '/schema.sql', 'schema.sql');
                }
                $zip->close();
                return $backupFilename;
            }
        }

        // Fallback backup copies if ZipArchive not writable
        if (file_exists($rootDir . '/config/config.php')) {
            @copy($rootDir . '/config/config.php', $rootDir . '/config/config.php.bak_' . $timestamp);
        }
        if (file_exists($rootDir . '/version.json')) {
            @copy($rootDir . '/version.json', $rootDir . '/version.json.bak_' . $timestamp);
        }
        return 'file_copies_' . $timestamp;
    }

    /**
     * Extract update ZIP with Zero-Data-Loss Shield
     */
    public static function extractZipFile($zipPath, $newVersion, $pdo = null) {
        if (!file_exists($zipPath) || filesize($zipPath) < 200) {
            throw new Exception("Invalid update zip file or empty archive.");
        }

        if (!class_exists('ZipArchive')) {
            throw new Exception("ZipArchive PHP extension is required on your web hosting to extract updates.");
        }

        $rootDir = realpath(__DIR__ . '/..');
        $configFile = $rootDir . '/config/config.php';
        $versionFile = $rootDir . '/version.json';

        // 1. Safety Backup
        $currentVersion = self::getCurrentVersion();
        $backupRef = self::createSafetyBackup($rootDir, $currentVersion);

        // Safeguard existing database credentials
        $configBackup = file_exists($configFile) ? file_get_contents($configFile) : null;

        // 2. Open ZipArchive
        $zip = new ZipArchive();
        $openRes = $zip->open($zipPath);
        if ($openRes !== TRUE) {
            throw new Exception("Failed to open update archive (ZipArchive Error Code: {$openRes}).");
        }

        // ── Sniff version from the zip's own version.json (fixes POST version being stale) ──
        // The uploaded zip declares its own version; use that instead of $newVersion from POST.
        $vSniffed = false;
        for ($vsi = 0; $vsi < $zip->numFiles; $vsi++) {
            $vEntry = $zip->getNameIndex($vsi);
            if (preg_match('#(?:^|/)version\.json$#', $vEntry) && strpos($vEntry, 'infinityfree') === false) {
                $vRaw = $zip->getFromIndex($vsi);
                $vMeta = @json_decode($vRaw, true);
                if (!empty($vMeta['version'])) {
                    $newVersion = $vMeta['version'];
                    $vSniffed = true;
                    break;
                }
            }
        }


        $tempExtractDir = $rootDir . '/backups/temp_extract_' . time();
        @mkdir($tempExtractDir, 0755, true);

        if (!$zip->extractTo($tempExtractDir)) {
            $zip->close();
            @self::deleteRecursive($tempExtractDir);
            throw new Exception("Failed to extract files into temporary extraction directory.");
        }
        $zip->close();

        // 3. Detect and remove parent directory prefixes
        $sourceDir = $tempExtractDir;
        $items = array_diff(scandir($tempExtractDir), ['.', '..']);
        if (count($items) === 1) {
            $singleSub = reset($items);
            if (is_dir($tempExtractDir . '/' . $singleSub)) {
                $sourceDir = $tempExtractDir . '/' . $singleSub;
            }
        }

        // Check if inside public/infinityfree_messenger
        if (!file_exists($sourceDir . '/admin/dashboard.php') && is_dir($sourceDir . '/public/infinityfree_messenger')) {
            $sourceDir = $sourceDir . '/public/infinityfree_messenger';
        }

        // 4. Protected Paths (Zero-Data-Loss Shield)
        // Strictly skips and NEVER overwrites:
        $protectedFiles = [
            'config.php',
            'database.php',
            '.htaccess',
            'custom_seed.sql',
            'site.json',
            'dev_auth.json',
            'submissions.json',
        ];
        $protectedFolders = [
            'backups',
            'data',
            'uploads',
            'revisions',
        ];

        self::copyRecursiveProtected($sourceDir, $rootDir, $protectedFiles, $protectedFolders);
        @self::deleteRecursive($tempExtractDir);

        // 5. Restore / Preserves database configuration while updating APP_VERSION
        if ($configBackup && file_exists($configFile)) {
            $updatedConfig = preg_replace(
                "/define\s*\(\s*['\"]APP_VERSION['\"]\s*,\s*['\"][^'\"]*['\"]\s*\);/",
                "define('APP_VERSION', '" . addslashes($newVersion) . "');",
                $configBackup
            );
            @file_put_contents($configFile, $updatedConfig ?: $configBackup);
        }

        // 6. Update version.json
        $existingMeta = self::getVersionData();
        $existingMeta['version'] = $newVersion;
        $existingMeta['last_updated'] = date('Y-m-d H:i:s');
        @file_put_contents($versionFile, json_encode($existingMeta, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

        // 7. Clear simulation and update cache
        if ($pdo) {
            try {
                $pdo->exec("DELETE FROM bot_settings WHERE setting_key IN ('simulated_update', 'update_check_cache', 'update_check_time')");
            } catch (Throwable $e) {}
        }

        // 8. Reset opcache
        if (function_exists('opcache_reset')) {
            @opcache_reset();
        }

        return [
            'success' => true,
            'new_version' => $newVersion,
            'backup' => $backupRef,
            'message' => "System successfully updated to version {$newVersion}!"
        ];
    }

    /**
     * Client Download Proxy installation (receives zip uploaded from browser)
     */
    public static function applyUploadedZip($fileUpload, $newVersion, $pdo = null) {
        if (empty($fileUpload['tmp_name']) || !is_uploaded_file($fileUpload['tmp_name'])) {
            throw new Exception("No valid update file was uploaded by client proxy.");
        }

        $tmpFile = $fileUpload['tmp_name'];
        $res = self::extractZipFile($tmpFile, $newVersion, $pdo);
        $res['mode'] = 'client_download_proxy';
        return $res;
    }

    /**
     * Local scan or server direct installation
     */
    public static function applyUpdate($newVersion, $downloadUrl = '', $pdo = null) {
        $rootDir = realpath(__DIR__ . '/..');

        // Check for local pre-uploaded zip files in root or backups
        $localCandidates = [
            $rootDir . '/update.zip',
            $rootDir . '/Chat-Assistant-Bot.zip',
            $rootDir . "/Chat-Assistant-Bot-v{$newVersion}.zip",
            $rootDir . '/messenger-update.zip',
            $rootDir . '/aetherbuilder-update.zip',
            $rootDir . '/backups/update.zip',
            $rootDir . "/backups/Chat-Assistant-Bot-v{$newVersion}.zip",
        ];

        foreach ($localCandidates as $candidate) {
            if (file_exists($candidate) && filesize($candidate) > 500) {
                $res = self::extractZipFile($candidate, $newVersion, $pdo);
                $res['mode'] = 'local_archive';
                $res['source'] = basename($candidate);
                return $res;
            }
        }

        // If download URL is provided, attempt server-side cURL with strict 4s timeout
        if (!empty($downloadUrl)) {
            $token = self::getGitHubToken($pdo);
            $tempDir = is_dir($rootDir . '/backups') ? $rootDir . '/backups' : sys_get_temp_dir();
            $tempZip = rtrim($tempDir, '/') . '/server_update_' . time() . '.zip';

            $fp = @fopen($tempZip, 'w+');
            if ($fp) {
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $downloadUrl);
                curl_setopt($ch, CURLOPT_FILE, $fp);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
                curl_setopt($ch, CURLOPT_TIMEOUT, 4); // Fast fail to prevent 20s hosting timeout
                $headers = [
                    'User-Agent: MessengerBot-Updater/' . self::getCurrentVersion(),
                    'Accept: application/octet-stream'
                ];
                if (!empty($token)) {
                    $headers[] = 'Authorization: token ' . $token;
                }
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                @curl_exec($ch);
                $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                fclose($fp);

                if ($code === 200 && file_exists($tempZip) && filesize($tempZip) > 500) {
                    $res = self::extractZipFile($tempZip, $newVersion, $pdo);
                    @unlink($tempZip);
                    $res['mode'] = 'server_direct';
                    return $res;
                }
                if (file_exists($tempZip)) {
                    @unlink($tempZip);
                }
            }
        }

        throw new Exception("Web host firewall restricts outbound cURL downloads. Please select your update ZIP file directly using the 1-Click Upload ZIP button or upload update.zip to your server root.");
    }

    /**
     * Simulate an update for testing on live production host
     */
    public static function setSimulatedUpdate($pdo, $version = '1.3.0', $changelog = null) {
        if (!$pdo) return false;
        if (!$changelog) {
            $changelog = [
                'Full synchronization with remote release stream for live zero-downtime updates',
                'Client Download Proxy pipeline bypassing outbound web host firewalls',
                'Zero-Data-Loss shield strictly preserving configuration credentials and database tables',
            ];
        }

        $payload = [
            'version' => $version,
            'title' => "Major Feature Update (v{$version})",
            'changelog' => $changelog,
            'published_at' => date('Y-m-d H:i:s')
        ];

        $stmt = $pdo->prepare("INSERT INTO bot_settings (setting_key, setting_value) VALUES ('simulated_update', :v) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        return $stmt->execute([':v' => json_encode($payload)]);
    }

    /**
     * Clear simulation
     */
    public static function clearSimulatedUpdate($pdo) {
        if (!$pdo) return false;
        $pdo->prepare("DELETE FROM bot_settings WHERE setting_key = 'simulated_update'")->execute();
        $pdo->prepare("DELETE FROM bot_settings WHERE setting_key = 'update_check_cache'")->execute();
        return true;
    }

    private static function copyRecursiveProtected($src, $dst, $protectedFiles = [], $protectedFolders = []) {
        $dir = @opendir($src);
        if (!$dir) return;
        @mkdir($dst, 0755, true);

        while (false !== ($file = readdir($dir))) {
            if ($file === '.' || $file === '..') continue;

            $srcPath = $src . '/' . $file;
            $dstPath = $dst . '/' . $file;

            if (is_dir($srcPath)) {
                if (in_array(strtolower($file), $protectedFolders, true)) {
                    continue; // Zero-data-loss protection
                }
                self::copyRecursiveProtected($srcPath, $dstPath, $protectedFiles, $protectedFolders);
            } else {
                if (in_array(strtolower($file), $protectedFiles, true) && file_exists($dstPath)) {
                    continue; // Skip protected file
                }
                @copy($srcPath, $dstPath);
            }
        }
        closedir($dir);
    }

    private static function deleteRecursive($dir) {
        if (!file_exists($dir)) return true;
        if (!is_dir($dir)) return @unlink($dir);
        foreach (scandir($dir) as $item) {
            if ($item === '.' || $item === '..') continue;
            if (!self::deleteRecursive($dir . DIRECTORY_SEPARATOR . $item)) return false;
        }
        return @rmdir($dir);
    }
}
