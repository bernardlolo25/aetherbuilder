import React, { useState, useEffect } from 'react';
import { Header, ActiveTab } from './components/Header';
import { MessengerSimulator } from './components/MessengerSimulator';
import { FlowBuilder } from './components/FlowBuilder';
import { ProductsManager } from './components/ProductsManager';
import { AIFlowStudio } from './components/AIFlowStudio';
import { KeywordManager } from './components/KeywordManager';
import { CannedResponses } from './components/CannedResponses';
import { LiveInbox } from './components/LiveInbox';
import { LeadsManager } from './components/LeadsManager';
import { MetaWebhookConfig } from './components/MetaWebhookConfig';
import { SystemUpdates } from './components/SystemUpdates';
import { PhpExportModal } from './components/PhpExportModal';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import {
  initialNodes,
  initialKeywords,
  initialCannedResponses,
  initialSettings,
  sampleLeads,
  initialProducts,
} from './data/initialBotData';
import {
  FlowNode,
  KeywordTrigger,
  CannedResponse,
  BotSettings,
  Lead,
  ConversationSession,
  ProductItem,
} from './types/chatbot';
import {
  processUserMessage,
  isCurrentlyOpen,
} from './services/ruleEngine';

function MainAppContent() {
  const { theme } = useTheme();
  const [activeTab, setActiveTab] = useState<ActiveTab>('simulator');

  // Persistence helpers
  const loadStored = <T,>(key: string, fallback: T): T => {
    try {
      const item = localStorage.getItem(`messenger_bot_${key}`);
      return item ? JSON.parse(item) : fallback;
    } catch {
      return fallback;
    }
  };

  const saveStored = <T,>(key: string, data: T) => {
    try {
      localStorage.setItem(`messenger_bot_${key}`, JSON.stringify(data));
    } catch (e) {
      console.warn('Storage quota notice:', e);
    }
  };

  // State
  const [nodes, setNodes] = useState<FlowNode[]>(() => loadStored('nodes', initialNodes));
  const [keywords, setKeywords] = useState<KeywordTrigger[]>(() =>
    loadStored('keywords', initialKeywords)
  );
  const [products, setProducts] = useState<ProductItem[]>(() =>
    loadStored('products', initialProducts)
  );
  const [selectedProductIdsForAI, setSelectedProductIdsForAI] = useState<string[]>(() =>
    products.map((p) => p.id)
  );
  const [cannedResponses, setCannedResponses] = useState<CannedResponse[]>(() =>
    loadStored('canned', initialCannedResponses)
  );
  const [settings, setSettings] = useState<BotSettings>(() =>
    loadStored('settings', initialSettings)
  );
  const [leads, setLeads] = useState<Lead[]>(() => loadStored('leads', sampleLeads));

  // Sync to localStorage
  useEffect(() => {
    saveStored('nodes', nodes);
  }, [nodes]);

  useEffect(() => {
    saveStored('keywords', keywords);
  }, [keywords]);

  useEffect(() => {
    saveStored('products', products);
  }, [products]);

  useEffect(() => {
    saveStored('canned', cannedResponses);
  }, [cannedResponses]);

  useEffect(() => {
    saveStored('settings', settings);
  }, [settings]);

  useEffect(() => {
    saveStored('leads', leads);
  }, [leads]);

  // Simulated Session
  const [activeSession, setActiveSession] = useState<ConversationSession>(() => {
    const startNode = nodes.find((n) => n.isStart) || nodes[0];
    return {
      id: 'session-client-demo',
      userId: 'psid_user_web_987654',
      userName: 'Messenger Guest',
      avatarUrl:
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
      currentNodeId: startNode?.id || 'node-start',
      collectedData: {},
      status: 'active_bot',
      lastActivity: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      messages: [
        {
          id: 'msg-start-init',
          sender: 'bot',
          text:
            startNode?.responseText ||
            '👋 Welcome to our 24/7 automated support! How may we assist you today?',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          options: startNode?.options || [],
          carouselCards: startNode?.carouselCards || [],
          nodeKey: startNode?.nodeKey || 'start',
        },
      ],
    };
  });

  const [sessions, setSessions] = useState<ConversationSession[]>([activeSession]);
  const [forcedHoursState, setForcedHoursState] = useState<boolean | null>(null);

  const isOpen = forcedHoursState !== null ? forcedHoursState : isCurrentlyOpen(settings);

  // Message Sending in Simulator
  const handleSendMessage = async (text: string, payload?: string) => {
    const userTimestamp = new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });

    const userMsg = {
      id: `msg-u-${Date.now()}`,
      sender: 'user' as const,
      text: text || (payload ? `Selected: ${payload}` : ''),
      timestamp: userTimestamp,
    };

    const sessionWithUserMsg: ConversationSession = {
      ...activeSession,
      messages: [...activeSession.messages, userMsg],
      lastActivity: userTimestamp,
    };

    // If session is human takeover and user did not type reset
    if (
      sessionWithUserMsg.status === 'human_takeover' &&
      !['restart', 'menu', 'reset', 'start'].includes(text.trim().toLowerCase())
    ) {
      setActiveSession(sessionWithUserMsg);
      setSessions((prev) =>
        prev.map((s) => (s.id === sessionWithUserMsg.id ? sessionWithUserMsg : s))
      );
      return;
    }

    // Process via Rule Engine
    const result = processUserMessage({
      userInput: text,
      payload,
      session: sessionWithUserMsg,
      nodes,
      keywords,
      settings,
    });

    const botTimestamp = new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });

    const targetNode = nodes.find((n) => n.id === result.nodeId);

    const botMsg = {
      id: `msg-b-${Date.now()}`,
      sender: 'bot' as const,
      text: result.replyText,
      timestamp: botTimestamp,
      options: result.options,
      carouselCards: targetNode?.carouselCards || [],
      nodeKey: result.nodeKey,
      matchedTrigger: result.matchedTriggerName,
    };

    const updatedSession: ConversationSession = {
      ...result.updatedSession,
      messages: [...sessionWithUserMsg.messages, botMsg],
      lastActivity: botTimestamp,
    };

    setActiveSession(updatedSession);
    setSessions((prev) =>
      prev.map((s) => (s.id === updatedSession.id ? updatedSession : s))
    );

    if (result.newLeadCreated) {
      setLeads((prev) => [result.newLeadCreated!, ...prev]);
    }
  };

  const handleResetChat = async () => {
    const startNode = nodes.find((n) => n.isStart) || nodes[0];
    const initialMsg = {
      id: `msg-reset-${Date.now()}`,
      sender: 'bot' as const,
      text:
        startNode?.responseText ||
        '👋 Welcome to our 24/7 automated support! How may we assist you today?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      options: startNode?.options || [],
      carouselCards: startNode?.carouselCards || [],
      nodeKey: startNode?.nodeKey || 'start',
    };

    const resetSession: ConversationSession = {
      ...activeSession,
      currentNodeId: startNode?.id || 'node-start',
      currentInputStep: undefined,
      collectedData: {},
      status: 'active_bot',
      messages: [initialMsg],
    };

    setActiveSession(resetSession);
    setSessions((prev) =>
      prev.map((s) => (s.id === resetSession.id ? resetSession : s))
    );
  };

  const handleToggleSimulatedHours = (forcedOpen: boolean | null) => {
    setForcedHoursState(forcedOpen);
  };

  // Node Management Handlers
  const handleSaveNode = async (savedNode: FlowNode) => {
    setNodes((prev) => {
      const exists = prev.some((n) => n.id === savedNode.id);
      if (exists) {
        return prev.map((n) => (n.id === savedNode.id ? savedNode : n));
      }
      return [...prev, savedNode];
    });
  };

  const handleDeleteNode = async (id: string) => {
    setNodes((prev) => prev.filter((n) => n.id !== id));
  };

  const handleSetStartNode = async (id: string) => {
    setNodes((prev) =>
      prev.map((n) => ({
        ...n,
        isStart: n.id === id,
      }))
    );
  };

  const handleAddNode = async (nodeData: Partial<FlowNode>) => {
    const newNode: FlowNode = {
      id: nodeData.id || `node-${Date.now()}`,
      nodeKey: nodeData.nodeKey || `node_key_${Date.now()}`,
      nodeName: nodeData.nodeName || 'New Node',
      nodeType: nodeData.nodeType || 'message',
      responseText: nodeData.responseText || 'Hello! How can we assist you?',
      isStart: nodeData.isStart || false,
      isActive: nodeData.isActive !== undefined ? nodeData.isActive : true,
      options: nodeData.options || [],
      carouselCards: nodeData.carouselCards,
      inputConfig: nodeData.inputConfig,
    };
    setNodes((prev) => [...prev, newNode]);
  };

  // Product Management Handlers
  const handleAddProduct = (productData: Omit<ProductItem, 'id' | 'createdAt'>) => {
    const newProduct: ProductItem = {
      ...productData,
      id: `prod-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setProducts((prev) => [newProduct, ...prev]);
    setSelectedProductIdsForAI((prev) => [...prev, newProduct.id]);
  };

  const handleUpdateProduct = (id: string, updated: Partial<ProductItem>) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updated } : p))
    );
  };

  const handleDeleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    setSelectedProductIdsForAI((prev) => prev.filter((itemId) => itemId !== id));
  };

  const handleSeedSampleProducts = () => {
    setProducts(initialProducts);
    setSelectedProductIdsForAI(initialProducts.map((p) => p.id));
  };

  const handleOpenAIPromptBuilderWithProducts = (productIds: string[]) => {
    setSelectedProductIdsForAI(productIds);
    setActiveTab('ai-studio');
  };

  const handleToggleSelectProduct = (id: string) => {
    setSelectedProductIdsForAI((prev) =>
      prev.includes(id) ? prev.filter((itemId) => itemId !== id) : [...prev, id]
    );
  };

  const handleSelectAllProducts = (select: boolean) => {
    if (select) {
      setSelectedProductIdsForAI(products.map((p) => p.id));
    } else {
      setSelectedProductIdsForAI([]);
    }
  };

  // Flow Import Handler (from AI Flow Studio)
  const handleImportFlow = (
    importedNodes: FlowNode[],
    importedKeywords: KeywordTrigger[] = [],
    clearExisting = false
  ) => {
    if (clearExisting) {
      setNodes(importedNodes);
      if (importedKeywords.length > 0) {
        setKeywords(importedKeywords);
      }
    } else {
      // Merge: overwrite nodes with matching keys or ids, append new ones
      setNodes((prev) => {
        const merged = [...prev];
        importedNodes.forEach((node) => {
          const idx = merged.findIndex((n) => n.id === node.id || n.nodeKey === node.nodeKey);
          if (idx !== -1) {
            merged[idx] = node;
          } else {
            merged.push(node);
          }
        });
        return merged;
      });

      if (importedKeywords.length > 0) {
        setKeywords((prev) => {
          const merged = [...prev];
          importedKeywords.forEach((kw) => {
            const idx = merged.findIndex((k) => k.id === kw.id || k.keyword === kw.keyword);
            if (idx !== -1) {
              merged[idx] = kw;
            } else {
              merged.push(kw);
            }
          });
          return merged;
        });
      }
    }

    // Reset simulator chat to new start node
    const newStart = importedNodes.find((n) => n.isStart) || importedNodes[0];
    if (newStart) {
      setActiveSession((prev) => ({
        ...prev,
        currentNodeId: newStart.id,
        messages: [
          {
            id: `msg-imported-${Date.now()}`,
            sender: 'bot',
            text: newStart.responseText,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            options: newStart.options || [],
            carouselCards: newStart.carouselCards || [],
            nodeKey: newStart.nodeKey,
          },
        ],
      }));
    }
  };

  // Keyword CRUD Handlers
  const handleAddKeyword = async (kw: Partial<KeywordTrigger>) => {
    const newKw: KeywordTrigger = {
      id: `kw-${Date.now()}`,
      keyword: kw.keyword || '',
      matchType: kw.matchType || 'contains',
      priority: kw.priority || 10,
      destinationNodeId: kw.destinationNodeId || nodes[0]?.id || 'node-start',
      category: kw.category || 'general',
      isEnabled: kw.isEnabled !== undefined ? kw.isEnabled : true,
      customResponseText: kw.customResponseText,
      notes: kw.notes,
    };
    setKeywords((prev) => [newKw, ...prev]);
  };

  const handleUpdateKeyword = async (id: string, kw: Partial<KeywordTrigger>) => {
    setKeywords((prev) =>
      prev.map((k) => (k.id === id ? { ...k, ...kw } : k))
    );
  };

  const handleDeleteKeyword = async (id: string) => {
    setKeywords((prev) => prev.filter((k) => k.id !== id));
  };

  // Canned Responses Handlers
  const handleAddCannedResponse = async (canned: Partial<CannedResponse>) => {
    const newCanned: CannedResponse = {
      id: `canned-${Date.now()}`,
      title: canned.title || 'Quick Response',
      category: canned.category || 'General',
      text: canned.text || '',
      quickReplies: canned.quickReplies || [],
      tags: canned.tags || [],
    };
    setCannedResponses((prev) => [newCanned, ...prev]);
  };

  const handleDeleteCannedResponse = async (id: string) => {
    setCannedResponses((prev) => prev.filter((c) => c.id !== id));
  };

  // Live Inbox Agent Handlers
  const handleAgentReply = async (sessionId: string, text: string) => {
    const timestamp = new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });

    const agentMsg = {
      id: `msg-agent-${Date.now()}`,
      sender: 'agent' as const,
      text,
      timestamp,
    };

    setSessions((prev) =>
      prev.map((s) => {
        if (s.id === sessionId) {
          const updated = {
            ...s,
            messages: [...s.messages, agentMsg],
            lastActivity: timestamp,
          };
          if (activeSession.id === sessionId) {
            setActiveSession(updated);
          }
          return updated;
        }
        return s;
      })
    );
  };

  const handleUpdateStatus = async (
    sessionId: string,
    status: ConversationSession['status']
  ) => {
    setSessions((prev) =>
      prev.map((s) => {
        if (s.id === sessionId) {
          const updated = { ...s, status };
          if (activeSession.id === sessionId) {
            setActiveSession(updated);
          }
          return updated;
        }
        return s;
      })
    );
  };

  // Leads Handlers
  const handleUpdateLeadStatus = async (
    id: string,
    status: Lead['status'],
    notes?: string
  ) => {
    setLeads((prev) =>
      prev.map((lead) =>
        lead.id === id
          ? {
              ...lead,
              status,
              ...(notes !== undefined ? { notes } : {}),
            }
          : lead
      )
    );
  };

  // Settings Save Handler
  const handleSaveSettings = async (newSettings: BotSettings) => {
    setSettings(newSettings);
  };

  const unreadInboxCount = sessions.filter(
    (s) => s.status === 'human_takeover'
  ).length;

  return (
    <div
      data-theme={theme}
      className={`${
        theme === 'dark' ? 'dark bg-[#090d16] text-slate-100' : 'light bg-slate-50 text-slate-900'
      } min-h-screen transition-colors duration-200 flex flex-col font-sans`}
    >
      {/* Navigation Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isOpen={isOpen}
        settings={settings}
        leadsCount={leads.length}
        unreadInboxCount={unreadInboxCount}
        productsCount={products.length}
      />

      {/* Main Tab Content */}
      <main className="flex-1 pb-16">
        {activeTab === 'simulator' && (
          <MessengerSimulator
            session={activeSession}
            nodes={nodes}
            settings={settings}
            isOpen={isOpen}
            onSendMessage={handleSendMessage}
            onResetChat={handleResetChat}
            onToggleSimulatedHours={handleToggleSimulatedHours}
            forcedHoursState={forcedHoursState}
            leads={leads}
          />
        )}

        {activeTab === 'flows' && (
          <FlowBuilder
            nodes={nodes}
            onSaveNode={handleSaveNode}
            onDeleteNode={handleDeleteNode}
            onSetStartNode={handleSetStartNode}
            onAddNode={handleAddNode}
          />
        )}

        {activeTab === 'products' && (
          <ProductsManager
            products={products}
            onAddProduct={handleAddProduct}
            onUpdateProduct={handleUpdateProduct}
            onDeleteProduct={handleDeleteProduct}
            onSeedSampleProducts={handleSeedSampleProducts}
            onOpenAIPromptBuilderWithProducts={handleOpenAIPromptBuilderWithProducts}
          />
        )}

        {activeTab === 'ai-studio' && (
          <AIFlowStudio
            products={products}
            selectedProductIds={selectedProductIdsForAI}
            onToggleSelectProduct={handleToggleSelectProduct}
            onSelectAllProducts={handleSelectAllProducts}
            onImportFlow={handleImportFlow}
            onNavigateToSimulator={() => setActiveTab('simulator')}
          />
        )}

        {activeTab === 'keywords' && (
          <KeywordManager
            keywords={keywords}
            nodes={nodes}
            onAddKeyword={handleAddKeyword}
            onUpdateKeyword={handleUpdateKeyword}
            onDeleteKeyword={handleDeleteKeyword}
          />
        )}

        {activeTab === 'canned' && (
          <CannedResponses
            cannedResponses={cannedResponses}
            onAddCannedResponse={handleAddCannedResponse}
            onDeleteCannedResponse={handleDeleteCannedResponse}
          />
        )}

        {activeTab === 'inbox' && (
          <LiveInbox
            sessions={sessions.length > 0 ? sessions : [activeSession]}
            cannedResponses={cannedResponses}
            onAgentReply={handleAgentReply}
            onUpdateStatus={handleUpdateStatus}
          />
        )}

        {activeTab === 'leads' && (
          <LeadsManager
            leads={leads}
            onUpdateLeadStatus={handleUpdateLeadStatus}
          />
        )}

        {activeTab === 'webhook' && (
          <MetaWebhookConfig
            settings={settings}
            onSaveSettings={handleSaveSettings}
          />
        )}

        {activeTab === 'updates' && (
          <SystemUpdates />
        )}

        {activeTab === 'export' && (
          <PhpExportModal
            nodes={nodes}
            keywords={keywords}
            settings={settings}
          />
        )}
      </main>

      {/* Modern Minimal Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800/80 bg-white dark:bg-[#0f172a] py-4 px-6 text-center text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>
              24/7 Facebook Messenger Assistant · Product Catalog & AI Studio Flow Suite
            </span>
          </div>
          <span className="text-slate-400 dark:text-slate-500">
            Enterprise Single-Host Web Architecture · Version 1.5.7
          </span>
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <MainAppContent />
    </ThemeProvider>
  );
}
