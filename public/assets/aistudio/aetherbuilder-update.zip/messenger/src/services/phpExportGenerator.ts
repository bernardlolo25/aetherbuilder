import { FlowNode, KeywordTrigger, BotSettings } from '../types/chatbot';

export function generateConfigPhp(): string {
  return `<?php
/**
 * Production Single-Host Database & App Configuration
 * Generated for: https://uspf-mcle.ct.ws/messenger
 */

// MySQL Hostname & Credentials
define('DB_HOST', 'sql309.infinityfree.com');
define('DB_NAME', 'if0_43065915_messenger_bot');
define('DB_USER', 'if0_43065915');
define('DB_PASS', 'peRlm46G9qB');

// Admin Setup Secret & Facebook Messenger Verify Token
define('ADMIN_SETUP_KEY', 'AetherBuilder_Messenger_Verify_8K3mN5pQ7rT1vX9zC4wL2hF6dJ8sB0');

define('APP_NAME', 'Chat Assistant Bot');
define('APP_BASE_URL', 'https://uspf-mcle.ct.ws/messenger');
define('APP_VERSION', '1.5.7');
define('GITHUB_REPO', 'bernardlolo25/Chat-Asistant-Bot');
define('GITHUB_BRANCH', 'main');
define('GITHUB_TOKEN', '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');
`;
}

export function generateSchemaSql(nodes: FlowNode[], keywords: KeywordTrigger[], settings: BotSettings): string {
  return `-- =========================================
-- MESSENGER BOT DATABASE
-- Initial Database Structure v1.0
-- Production Host Schema
-- =========================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 1. ADMIN ACCOUNTS
CREATE TABLE IF NOT EXISTS admins (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(190) DEFAULT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('superadmin','admin','editor')
        NOT NULL DEFAULT 'admin',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    last_login DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. FLOW VERSIONS
CREATE TABLE IF NOT EXISTS flow_versions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    version_name VARCHAR(150) NOT NULL,
    status ENUM('draft','published','archived')
        NOT NULL DEFAULT 'draft',
    created_by BIGINT UNSIGNED DEFAULT NULL,
    published_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES admins(id)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. DECISION TREE NODES
CREATE TABLE IF NOT EXISTS flow_nodes (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    version_id BIGINT UNSIGNED NOT NULL,
    node_key VARCHAR(100) NOT NULL,
    node_name VARCHAR(150) NOT NULL,
    node_type VARCHAR(50) NOT NULL DEFAULT 'message',
    response_text TEXT,
    is_start TINYINT(1) NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_node_key (version_id, node_key),
    FOREIGN KEY (version_id) REFERENCES flow_versions(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. NODE OPTIONS / QUICK REPLIES
CREATE TABLE IF NOT EXISTS flow_options (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    node_id BIGINT UNSIGNED NOT NULL,
    option_label VARCHAR(255) NOT NULL,
    option_payload VARCHAR(255) NOT NULL,
    destination_node_id BIGINT UNSIGNED DEFAULT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (node_id) REFERENCES flow_nodes(id)
        ON DELETE CASCADE,
    FOREIGN KEY (destination_node_id) REFERENCES flow_nodes(id)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. KEYWORD TRIGGERS
CREATE TABLE IF NOT EXISTS keyword_triggers (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    keyword VARCHAR(255) NOT NULL,
    match_type ENUM('exact','contains','phrase')
        NOT NULL DEFAULT 'contains',
    node_id BIGINT UNSIGNED NOT NULL,
    priority INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (node_id) REFERENCES flow_nodes(id)
        ON DELETE CASCADE,
    INDEX idx_keyword_active (is_active, priority)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. MESSENGER CONVERSATIONS
CREATE TABLE IF NOT EXISTS conversations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    page_scoped_id VARCHAR(100) NOT NULL UNIQUE,
    current_node_id BIGINT UNSIGNED DEFAULT NULL,
    flow_version_id BIGINT UNSIGNED DEFAULT NULL,
    conversation_status ENUM('active','completed','closed')
        NOT NULL DEFAULT 'active',
    human_takeover TINYINT(1) NOT NULL DEFAULT 0,
    context_data LONGTEXT DEFAULT NULL,
    last_interaction DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (current_node_id) REFERENCES flow_nodes(id)
        ON DELETE SET NULL,
    FOREIGN KEY (flow_version_id) REFERENCES flow_versions(id)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. MESSAGE HISTORY
CREATE TABLE IF NOT EXISTS messages (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    conversation_id BIGINT UNSIGNED NOT NULL,
    direction ENUM('incoming','outgoing') NOT NULL,
    message_text TEXT,
    message_type VARCHAR(50) DEFAULT 'text',
    meta_message_id VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id)
        ON DELETE CASCADE,
    INDEX idx_message_history (conversation_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. LEAD INFORMATION
CREATE TABLE IF NOT EXISTS leads (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    conversation_id BIGINT UNSIGNED DEFAULT NULL,
    page_scoped_id VARCHAR(100) NOT NULL,
    full_name VARCHAR(190) DEFAULT NULL,
    email VARCHAR(190) DEFAULT NULL,
    phone VARCHAR(50) DEFAULT NULL,
    notes TEXT,
    lead_status ENUM('new','contacted','qualified','completed')
        NOT NULL DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. GENERAL BOT SETTINGS
CREATE TABLE IF NOT EXISTS bot_settings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(150) NOT NULL UNIQUE,
    setting_value LONGTEXT DEFAULT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. ADMIN ACTIVITY LOG
CREATE TABLE IF NOT EXISTS admin_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    admin_id BIGINT UNSIGNED DEFAULT NULL,
    action VARCHAR(150) NOT NULL,
    details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admins(id)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. PRODUCTS & SERVICES CATALOG
CREATE TABLE IF NOT EXISTS products (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100) DEFAULT 'Services',
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    currency VARCHAR(10) NOT NULL DEFAULT 'USD',
    description TEXT,
    sku VARCHAR(100) DEFAULT NULL,
    stock_status ENUM('available','in_stock','preorder','out_of_stock') NOT NULL DEFAULT 'available',
    features TEXT,
    image_url LONGTEXT,
    action_label VARCHAR(100) DEFAULT 'Order Now',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_products_category (category),
    INDEX idx_products_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. CANNED RESPONSES & KNOWLEDGE BASE
CREATE TABLE IF NOT EXISTS canned_responses (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL DEFAULT 'General',
    response_text TEXT NOT NULL,
    quick_replies TEXT DEFAULT NULL,
    tags VARCHAR(255) DEFAULT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_canned_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- =========================================
-- INITIAL BOT CONFIGURATION & SEED DATA
-- =========================================

INSERT INTO bot_settings (setting_key, setting_value)
VALUES
('bot_name', 'Chat Assistant Bot'),
('bot_enabled', '1'),
('verify_token', 'AetherBuilder_Messenger_Verify_8K3mN5pQ7rT1vX9zC4wL2hF6dJ8sB0'),
('default_response', 'Sorry, I did not understand that. Please choose an option from the menu or type help.'),
('welcome_message', '👋 Hello! Welcome to our 24/7 Support Assistant. How may we help you today?')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- Flow Version
INSERT IGNORE INTO flow_versions (id, version_name, status)
VALUES (1, 'Main 24/7 Chatbot Flow', 'published');

-- Flow Nodes
INSERT IGNORE INTO flow_nodes (id, version_id, node_key, node_name, node_type, response_text, is_start)
VALUES
(1, 1, 'start', 'Main Menu & Welcome Greeting', 'menu', '👋 Welcome to the MCLE Messenger Assistant! How may we help you? Please choose an option below or type your question anytime.', 1),
(2, 1, 'pricing', 'Pricing & Rates', 'message', '💰 Pricing & Rates Overview:\\n\\n• Standard Service Pass: $49\\n• Professional Package: $129\\n• Enterprise / Group: Custom rates available.\\n\\nAll packages include 24/7 automated support access.', 0),
(3, 1, 'hours', 'Hours & Location', 'message', '🕒 Operating Schedule & Location:\\n\\n• Live Support: Monday–Friday 9:00 AM – 6:00 PM\\n• Automated Bot: Available 24 Hours / 7 Days\\n• Office: 500 Business Plaza, Suite 400', 0),
(4, 1, 'lead_capture', 'Submit Inquiry', 'input', 'Please enter your Full Name, Email, and Question so our team can follow up immediately:', 0),
(5, 1, 'human_agent', 'Speak to Agent', 'message', '🔔 We have notified our support desk. A team member has been alerted and will join this conversation shortly.', 0);

-- Quick Replies / Options
INSERT IGNORE INTO flow_options (id, node_id, option_label, option_payload, destination_node_id, sort_order)
VALUES
(1, 1, '💳 Pricing & Fees', 'PAYLOAD_PRICING', 2, 1),
(2, 1, '🕒 Business Hours', 'PAYLOAD_HOURS', 3, 2),
(3, 1, '📝 Submit Inquiry', 'PAYLOAD_LEAD', 4, 3),
(4, 1, '👤 Speak to Agent', 'PAYLOAD_AGENT', 5, 4),
(5, 2, '📝 Submit Inquiry', 'PAYLOAD_LEAD', 4, 1),
(6, 2, '↩ Main Menu', 'PAYLOAD_MENU', 1, 2),
(7, 3, '💳 View Pricing', 'PAYLOAD_PRICING', 2, 1),
(8, 3, '↩ Main Menu', 'PAYLOAD_MENU', 1, 2);

-- Keyword Triggers
INSERT IGNORE INTO keyword_triggers (id, keyword, match_type, node_id, priority, is_active)
VALUES
(1, 'hi, hello, hey, start, menu, restart', 'contains', 1, 100, 1),
(2, 'price, pricing, cost, fee, how much, rate', 'contains', 2, 90, 1),
(3, 'hour, hours, open, time, location, address', 'contains', 3, 85, 1),
(4, 'agent, human, person, representative, support', 'contains', 5, 95, 1),
(5, 'register, inquiry, quote, enroll, contact me', 'contains', 4, 80, 1);
`;
}

export function generateWebhookPhp(): string {
  return `<?php
/**
 * Facebook Messenger 24/7 Automated Webhook
 * Configured for: https://uspf-mcle.ct.ws/messenger/webhook.php
 * 100% Rule-based: No AI integration.
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/send_api.php';

header('Content-Type: text/plain; charset=utf-8');

$pdo = db();

// Fetch verify token from bot_settings or fallback to ADMIN_SETUP_KEY
$tokenStmt = $pdo->prepare("SELECT setting_value FROM bot_settings WHERE setting_key = 'verify_token' LIMIT 1");
$tokenStmt->execute();
$dbToken = $tokenStmt->fetchColumn();

$verifyToken = $dbToken ?: (defined('ADMIN_SETUP_KEY') ? ADMIN_SETUP_KEY : 'AetherBuilder_Messenger_Verify_8K3mN5pQ7rT1vX9zC4wL2hF6dJ8sB0');

// Fetch Page Access Token
$pageStmt = $pdo->prepare("SELECT setting_value FROM bot_settings WHERE setting_key = 'page_access_token' LIMIT 1");
$pageStmt->execute();
$pageAccessToken = $pageStmt->fetchColumn() ?: '';

// ==============================================================
// 1. META WEBHOOK VERIFICATION (GET)
// ==============================================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $hubMode = $_GET['hub_mode'] ?? '';
    $hubVerifyToken = $_GET['hub_verify_token'] ?? '';
    $hubChallenge = $_GET['hub_challenge'] ?? '';

    if ($hubMode === 'subscribe' && $hubVerifyToken === $verifyToken) {
        http_response_code(200);
        echo $hubChallenge;
        exit;
    }

    http_response_code(403);
    echo 'Forbidden: Invalid verify token.';
    exit;
}

// ==============================================================
// 2. INCOMING MESSENGER WEBHOOK EVENTS (POST)
// ==============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true);

    if (empty($data['object']) || $data['object'] !== 'page' || empty($data['entry'])) {
        http_response_code(400);
        exit('Invalid webhook payload format.');
    }

    // Acknowledge receipt to Meta immediately (HTTP 200)
    http_response_code(200);
    echo 'EVENT_RECEIVED';

    foreach ($data['entry'] as $entry) {
        if (empty($entry['messaging'])) continue;

        foreach ($entry['messaging'] as $event) {
            $senderId = $event['sender']['id'] ?? null;
            if (!$senderId) continue;

            $messageText = '';
            $payload = null;

            if (!empty($event['message']['text'])) {
                $messageText = trim($event['message']['text']);
            }
            if (!empty($event['message']['quick_reply']['payload'])) {
                $payload = $event['message']['quick_reply']['payload'];
            }
            if (!empty($event['postback']['payload'])) {
                $payload = $event['postback']['payload'];
            }

            if ($messageText === '' && empty($payload)) continue;

            handleIncomingCustomerMessage($pdo, $senderId, $messageText, $payload, $pageAccessToken);
        }
    }

    exit;
}

/**
 * Core Rule Engine for incoming Messenger conversations
 * Uses: conversations, flow_nodes, flow_options, keyword_triggers, messages, leads
 */
function handleIncomingCustomerMessage(PDO $pdo, string $senderId, string $userText, ?string $payload, string $pageAccessToken): void {
    // 1. Find or create conversation session
    $stmt = $pdo->prepare("SELECT * FROM conversations WHERE page_scoped_id = ? LIMIT 1");
    $stmt->execute([$senderId]);
    $conv = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$conv) {
        $startNode = $pdo->query("SELECT id FROM flow_nodes WHERE is_start = 1 AND is_active = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);
        $startId = $startNode ? (int)$startNode['id'] : 1;

        $ins = $pdo->prepare("INSERT INTO conversations (page_scoped_id, current_node_id, flow_version_id, conversation_status, human_takeover, last_interaction) VALUES (?, ?, 1, 'active', 0, NOW())");
        $ins->execute([$senderId, $startId]);
        $convId = (int)$pdo->lastInsertId();
        $humanTakeover = 0;
    } else {
        $convId = (int)$conv['id'];
        $humanTakeover = (int)$conv['human_takeover'];
    }

    // 2. Log incoming message
    $logStmt = $pdo->prepare("INSERT INTO messages (conversation_id, direction, message_text, message_type) VALUES (?, 'incoming', ?, 'text')");
    $logStmt->execute([$convId, $userText ?: ($payload ? "Selected: {$payload}" : '')]);

    // If human agent has taken over and user didn't ask to reset
    if ($humanTakeover === 1 && empty($payload) && !in_array(strtolower($userText), ['restart', 'menu', 'reset'], true)) {
        return;
    }

    // 3. Show typing indicator
    if (!empty($pageAccessToken)) {
        fb_send_action($pageAccessToken, $senderId, 'typing_on');
    }

    $targetNodeId = null;

    // A. Payload / Quick reply matching
    if (!empty($payload)) {
        $optStmt = $pdo->prepare("SELECT destination_node_id FROM flow_options WHERE option_payload = ? LIMIT 1");
        $optStmt->execute([$payload]);
        $targetOpt = $optStmt->fetch(PDO::FETCH_ASSOC);
        if ($targetOpt && !empty($targetOpt['destination_node_id'])) {
            $targetNodeId = (int)$targetOpt['destination_node_id'];
        }
    }

    // B. Keyword triggers evaluation (highest priority first)
    if (!$targetNodeId && $userText !== '') {
        $kwStmt = $pdo->query("SELECT * FROM keyword_triggers WHERE is_active = 1 ORDER BY priority DESC");
        $keywords = $kwStmt->fetchAll(PDO::FETCH_ASSOC);

        $cleanText = mb_strtolower(trim($userText));

        foreach ($keywords as $kwRow) {
            $matchType = $kwRow['match_type'];
            $rawKws = array_map('trim', explode(',', mb_strtolower($kwRow['keyword'])));

            foreach ($rawKws as $singleKw) {
                if ($singleKw === '') continue;
                $isMatch = false;

                if ($matchType === 'exact') {
                    $isMatch = ($cleanText === $singleKw);
                } elseif ($matchType === 'contains' || $matchType === 'phrase') {
                    $isMatch = (mb_strpos($cleanText, $singleKw) !== false);
                }

                if ($isMatch) {
                    $targetNodeId = (int)$kwRow['node_id'];
                    break 2;
                }
            }
        }
    }

    // C. Default Fallback or Start Node
    if (!$targetNodeId) {
        $startNode = $pdo->query("SELECT id FROM flow_nodes WHERE is_start = 1 AND is_active = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);
        $targetNodeId = $startNode ? (int)$startNode['id'] : 1;
    }

    // 4. Fetch the target node details
    $nodeStmt = $pdo->prepare("SELECT * FROM flow_nodes WHERE id = ? LIMIT 1");
    $nodeStmt->execute([$targetNodeId]);
    $node = $nodeStmt->fetch(PDO::FETCH_ASSOC);

    if (!$node) return;

    // Fetch options / buttons
    $optsStmt = $pdo->prepare("SELECT * FROM flow_options WHERE node_id = ? ORDER BY sort_order ASC");
    $optsStmt->execute([$node['id']]);
    $nodeOptions = $optsStmt->fetchAll(PDO::FETCH_ASSOC);

    $replyText = $node['response_text'];

    // If node is an inquiry/lead capture node, automatically record in leads table
    if ($node['node_type'] === 'input' && $userText !== '') {
        $leadCheck = $pdo->prepare("SELECT id FROM leads WHERE page_scoped_id = ? LIMIT 1");
        $leadCheck->execute([$senderId]);
        if (!$leadCheck->fetchColumn()) {
            $insLead = $pdo->prepare("INSERT INTO leads (conversation_id, page_scoped_id, full_name, notes, lead_status) VALUES (?, ?, 'Messenger User', ?, 'new')");
            $insLead->execute([$convId, $senderId, $userText]);
        }
    }

    // Update conversation record
    $upd = $pdo->prepare("UPDATE conversations SET current_node_id = ?, last_interaction = NOW() WHERE id = ?");
    $upd->execute([$node['id'], $convId]);

    // Log outgoing message
    $logBot = $pdo->prepare("INSERT INTO messages (conversation_id, direction, message_text, message_type) VALUES (?, 'outgoing', ?, 'text')");
    $logBot->execute([$convId, $replyText]);

    // Send reply via Meta Send API
    if (!empty($pageAccessToken)) {
        $quickReplies = [];
        foreach ($nodeOptions as $opt) {
            $quickReplies[] = [
                'content_type' => 'text',
                'title' => mb_substr($opt['option_label'], 0, 20),
                'payload' => $opt['option_payload'] ?: ('PAYLOAD_' . $opt['id'])
            ];
        }

        fb_send_message($pageAccessToken, $senderId, $replyText, $quickReplies);
    }
}
`;
}

export function generateSendApiPhp(): string {
  return `<?php
/**
 * Facebook Graph Send API v19.0 Integration Helper
 * Sends standard text, quick replies, and sender actions to users.
 */

function fb_send_message(string $pageAccessToken, string $recipientId, string $text, array $quickReplies = []): array {
    $url = 'https://graph.facebook.com/v19.0/me/messages?access_token=' . urlencode($pageAccessToken);

    $messageData = [
        'text' => $text,
    ];

    if (!empty($quickReplies)) {
        $messageData['quick_replies'] = array_slice($quickReplies, 0, 13);
    }

    $payload = [
        'recipient' => ['id' => $recipientId],
        'message' => $messageData,
        'messaging_type' => 'RESPONSE',
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return [
        'status' => $httpCode,
        'response' => json_decode($response, true)
    ];
}

function fb_send_action(string $pageAccessToken, string $recipientId, string $action = 'typing_on'): void {
    $url = 'https://graph.facebook.com/v19.0/me/messages?access_token=' . urlencode($pageAccessToken);
    $payload = [
        'recipient' => ['id' => $recipientId],
        'sender_action' => $action,
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_exec($ch);
    curl_close($ch);
}
`;
}

export function generateAppCss(): string {
  return `/**
 * Professional Single-Host Admin Stylesheet
 * Supports Dark & Light Theme Presets via CSS Custom Variables
 * Optimized for Modern Production PHP Web Hosting
 */

:root, [data-theme="light"] {
  --bg-page: #f8fafc;
  --bg-surface: #ffffff;
  --bg-subtle: #f1f5f9;
  --border-color: #e2e8f0;
  --border-focus: #2563eb;
  --text-main: #0f172a;
  --text-muted: #64748b;
  --text-subtle: #94a3b8;
  --accent: #2563eb;
  --accent-hover: #1d4ed8;
  --accent-light: #eff6ff;
  --accent-text: #1d4ed8;
  --card-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
  --sidebar-bg: #0f172a;
  --sidebar-text: #cbd5e1;
  --sidebar-active: #1e293b;
  --badge-bg: #f1f5f9;
  --badge-text: #334155;
  --badge-border: #cbd5e1;
}

[data-theme="dark"] {
  --bg-page: #090d16;
  --bg-surface: #111827;
  --bg-subtle: #1f2937;
  --border-color: #232d3f;
  --border-focus: #3b82f6;
  --text-main: #f8fafc;
  --text-muted: #94a3b8;
  --text-subtle: #64748b;
  --accent: #3b82f6;
  --accent-hover: #2563eb;
  --accent-light: #1e293b;
  --accent-text: #93c5fd;
  --card-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3);
  --sidebar-bg: #090d16;
  --sidebar-text: #94a3b8;
  --sidebar-active: #1e293b;
  --badge-bg: #1f2937;
  --badge-text: #e2e8f0;
  --badge-border: #374151;
}

* { box-sizing: border-box; }
body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  color: var(--text-main);
  background: var(--bg-page);
  line-height: 1.5;
  transition: background-color 0.2s ease, color 0.2s ease;
}

a { color: var(--accent); text-decoration: none; }
a:hover { text-decoration: underline; }

.app-layout { display: flex; min-height: 100vh; }
.sidebar {
  width: 250px;
  background: var(--sidebar-bg);
  color: var(--sidebar-text);
  padding: 20px 16px;
  display: flex;
  flex-direction: column;
  border-right: 1px solid var(--border-color);
}
.side-brand {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 8px 24px;
  font-weight: 700;
  font-size: 15px;
  color: #fff;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}
.brand-mark {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: var(--accent);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 800;
  font-size: 16px;
}
.sidebar nav { display: grid; gap: 4px; margin-top: 16px; }
.sidebar nav a {
  display: flex;
  align-items: center;
  padding: 10px 12px;
  color: var(--sidebar-text);
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
  text-decoration: none;
  transition: all 0.15s;
}
.sidebar nav a:hover, .sidebar nav a.active {
  background: var(--sidebar-active);
  color: #fff;
}
.sidebar-footer {
  margin-top: auto;
  padding-top: 16px;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 12px;
}

.main-content {
  flex: 1;
  padding: 28px 36px;
  max-width: 1350px;
  margin: 0 auto;
}
.top-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  padding-bottom: 16px;
  border-bottom: 1px solid var(--border-color);
}
.top-header h1 {
  margin: 0;
  font-size: 22px;
  font-weight: 700;
  letter-spacing: -0.02em;
}

.theme-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: var(--bg-surface);
  color: var(--text-main);
  border: 1px solid var(--border-color);
  padding: 7px 12px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 12px;
  font-weight: 600;
  transition: all 0.15s;
}
.theme-btn:hover { background: var(--bg-subtle); }

.stat-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 16px;
  margin-bottom: 24px;
}
.stat-card {
  background: var(--bg-surface);
  border: 1px solid var(--border-color);
  border-radius: 12px;
  padding: 18px 20px;
  box-shadow: var(--card-shadow);
}
.stat-card .label { font-size: 12px; color: var(--text-muted); font-weight: 500; }
.stat-card .value { font-size: 26px; font-weight: 700; margin: 6px 0 2px; }
.stat-card .sub { font-size: 11px; color: var(--text-subtle); }

.table-wrap {
  background: var(--bg-surface);
  border: 1px solid var(--border-color);
  border-radius: 12px;
  overflow: hidden;
  box-shadow: var(--card-shadow);
  margin-bottom: 24px;
}
table { width: 100%; border-collapse: collapse; text-align: left; font-size: 13px; }
thead {
  background: var(--bg-subtle);
  border-bottom: 1px solid var(--border-color);
}
th {
  padding: 12px 16px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--text-muted);
}
td {
  padding: 12px 16px;
  border-bottom: 1px solid var(--border-color);
  color: var(--text-main);
}
tr:last-child td { border-bottom: 0; }
tr:hover td { background: var(--bg-subtle); }

.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 8px 16px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  border: 1px solid transparent;
  transition: all 0.15s;
}
.btn-primary { background: var(--accent); color: #fff; }
.btn-primary:hover { background: var(--accent-hover); }
.btn-secondary {
  background: var(--bg-surface);
  color: var(--text-main);
  border-color: var(--border-color);
}
.btn-secondary:hover { background: var(--bg-subtle); }
`;
}

export function generateAdminJs(): string {
  return `/**
 * Client-side script for Single Host PHP Admin Dashboard
 * Manages Dark/Light mode theme presets and UI interactions
 */

(function () {
  'use strict';

  function initTheme() {
    const savedTheme = localStorage.getItem('fb_admin_theme') || 
      (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    applyTheme(savedTheme);

    const toggleBtn = document.getElementById('theme-toggle-btn');
    if (toggleBtn) {
      toggleBtn.addEventListener('click', function () {
        const current = document.documentElement.getAttribute('data-theme') || 'light';
        const next = current === 'dark' ? 'light' : 'dark';
        applyTheme(next);
      });
    }
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    document.body.setAttribute('data-theme', theme);
    localStorage.setItem('fb_admin_theme', theme);
    const label = document.getElementById('theme-label');
    if (label) {
      label.textContent = theme === 'dark' ? '☀️ Light Mode' : '🌙 Dark Mode';
    }
  }

  window.exportTableToCSV = function (tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;

    let csv = [];
    const rows = table.querySelectorAll('tr');

    for (let i = 0; i < rows.length; i++) {
      let row = [], cols = rows[i].querySelectorAll('td, th');
      for (let j = 0; j < cols.length; j++) {
        if (cols[j].classList.contains('no-export')) continue;
        let text = cols[j].innerText.replace(/"/g, '""').trim();
        row.push('"' + text + '"');
      }
      if (row.length > 0) csv.push(row.join(','));
    }

    const csvBlob = new Blob([csv.join('\\n')], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(csvBlob);
    link.download = filename || 'leads-export.csv';
    link.click();
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTheme);
  } else {
    initTheme();
  }
})();
`;
}
