import { FlowNode, KeywordTrigger, BotSettings, FlowOption, ConversationSession, Lead } from '../types/chatbot';

export interface ProcessMessageResult {
  replyText: string;
  options: FlowOption[];
  nodeId: string;
  nodeKey: string;
  matchedTriggerName?: string;
  isHumanHandoff?: boolean;
  isAfterHoursNotice?: boolean;
  updatedSession: ConversationSession;
  newLeadCreated?: Lead;
}

export function isCurrentlyOpen(settings: BotSettings): boolean {
  if (!settings.businessHoursEnabled) return true;
  try {
    const now = new Date();
    // Default day of week: 0 = Sun, 1 = Mon ... 6 = Sat
    const day = now.getDay() === 0 ? 7 : now.getDay();
    if (!settings.businessDays.includes(day)) {
      return false;
    }

    const [startH, startM] = settings.businessHoursStart.split(':').map(Number);
    const [endH, endM] = settings.businessHoursEnd.split(':').map(Number);

    const currentMinutes = now.getHours() * 60 + now.getMinutes();
    const startMinutes = startH * 60 + startM;
    const endMinutes = endH * 60 + endM;

    return currentMinutes >= startMinutes && currentMinutes <= endMinutes;
  } catch {
    return true;
  }
}

export function evaluateKeywordMatch(
  inputText: string,
  trigger: KeywordTrigger
): { matched: boolean; matchedKeyword: string } {
  if (!trigger.isEnabled) return { matched: false, matchedKeyword: '' };

  const cleanedInput = inputText.trim().toLowerCase();
  if (!cleanedInput) return { matched: false, matchedKeyword: '' };

  const rawKeywords = trigger.keyword
    .split(',')
    .map(k => k.trim().toLowerCase())
    .filter(Boolean);

  for (const kw of rawKeywords) {
    if (trigger.matchType === 'exact') {
      if (cleanedInput === kw) {
        return { matched: true, matchedKeyword: kw };
      }
    } else if (trigger.matchType === 'contains') {
      // Substring match or word boundary match
      if (cleanedInput.includes(kw)) {
        return { matched: true, matchedKeyword: kw };
      }
    } else if (trigger.matchType === 'starts_with') {
      if (cleanedInput.startsWith(kw)) {
        return { matched: true, matchedKeyword: kw };
      }
    } else if (trigger.matchType === 'regex') {
      try {
        const regex = new RegExp(kw, 'i');
        if (regex.test(cleanedInput)) {
          return { matched: true, matchedKeyword: kw };
        }
      } catch {
        // ignore invalid regex
      }
    }
  }

  return { matched: false, matchedKeyword: '' };
}

export function processUserMessage(params: {
  userInput: string;
  payload?: string;
  session: ConversationSession;
  nodes: FlowNode[];
  keywords: KeywordTrigger[];
  settings: BotSettings;
}): ProcessMessageResult {
  const { userInput, payload, session, nodes, keywords, settings } = params;
  const nodeMap = new Map<string, FlowNode>(nodes.map(n => [n.id, n]));
  const startNode = nodes.find(n => n.isStart) || nodes[0];
  const currentNode = nodeMap.get(session.currentNodeId) || startNode;

  let updatedSession: ConversationSession = {
    ...session,
    collectedData: { ...session.collectedData },
    lastActivity: new Date().toISOString(),
  };

  let newLeadCreated: Lead | undefined;

  // 1. Direct Payload / Button Click handling
  if (payload) {
    // Check if payload points to a specific option in current node or matches any option
    let targetNodeId = '';

    for (const n of nodes) {
      const opt = n.options.find(o => o.payload === payload);
      if (opt && opt.destinationNodeId) {
        targetNodeId = opt.destinationNodeId;
        break;
      }
    }

    if (!targetNodeId) {
      // Check persistent menu items
      const menuItem = settings.persistentMenuItems.find(m => m.destinationNodeId && payload.includes(m.destinationNodeId));
      if (menuItem?.destinationNodeId) {
        targetNodeId = menuItem.destinationNodeId;
      }
    }

    if (targetNodeId && nodeMap.has(targetNodeId)) {
      const targetNode = nodeMap.get(targetNodeId)!;
      updatedSession.currentNodeId = targetNode.id;
      if (targetNode.nodeType === 'agent_handoff') {
        updatedSession.status = 'human_takeover';
      }

      return {
        replyText: targetNode.responseText,
        options: targetNode.options,
        nodeId: targetNode.id,
        nodeKey: targetNode.nodeKey,
        isHumanHandoff: targetNode.nodeType === 'agent_handoff',
        updatedSession,
      };
    }
  }

  const trimmedText = userInput.trim();

  // 2. Check if currently in an input-capture node
  if (currentNode.nodeType === 'input' && currentNode.inputConfig) {
    const config = currentNode.inputConfig;

    // Validate if regex provided
    if (config.validationRegex) {
      try {
        const regex = new RegExp(config.validationRegex, 'i');
        if (!regex.test(trimmedText)) {
          return {
            replyText: `⚠️ ${config.validationErrorMessage || 'Please provide a valid response.'}`,
            options: [{ id: 'cancel-opt', label: '↩ Cancel & Return to Menu', destinationNodeId: startNode.id, payload: 'PAYLOAD_MENU' }],
            nodeId: currentNode.id,
            nodeKey: currentNode.nodeKey,
            updatedSession,
          };
        }
      } catch {
        // continue
      }
    }

    // Save field to session data
    const fieldName = config.fieldToCapture === 'custom' && config.customFieldName
      ? config.customFieldName
      : config.fieldToCapture;

    updatedSession.collectedData[fieldName] = trimmedText;

    // Check if we reached the final lead capture step or need to save lead
    const destNode = nodeMap.get(config.destinationNodeIdOnSuccess);

    // If we captured all basic contact information, create a lead record
    if (config.fieldToCapture === 'inquiry' || (destNode && destNode.nodeKey === 'lead_confirmation')) {
      newLeadCreated = {
        id: `lead-${Date.now()}`,
        sessionId: session.id,
        fullName: updatedSession.collectedData['name'] || session.userName || 'Anonymous Inquirer',
        email: updatedSession.collectedData['email'] || '',
        phone: updatedSession.collectedData['phone'] || '',
        inquiry: updatedSession.collectedData['inquiry'] || trimmedText,
        capturedAt: new Date().toLocaleString(),
        status: 'new',
        notes: 'Captured automatically via 24/7 Messenger Support Flow',
      };
    }

    if (destNode) {
      updatedSession.currentNodeId = destNode.id;
      return {
        replyText: destNode.responseText,
        options: destNode.options,
        nodeId: destNode.id,
        nodeKey: destNode.nodeKey,
        updatedSession,
        newLeadCreated,
      };
    }
  }

  // 3. Match against Keyword Triggers (highest priority first)
  const sortedKeywords = [...keywords].sort((a, b) => (b.priority || 0) - (a.priority || 0));

  for (const trigger of sortedKeywords) {
    const match = evaluateKeywordMatch(trimmedText, trigger);
    if (match.matched) {
      const targetNode = nodeMap.get(trigger.destinationNodeId) || startNode;
      updatedSession.currentNodeId = targetNode.id;

      if (targetNode.nodeType === 'agent_handoff') {
        updatedSession.status = 'human_takeover';
      }

      const text = trigger.customResponseText || targetNode.responseText;

      return {
        replyText: text,
        options: targetNode.options,
        nodeId: targetNode.id,
        nodeKey: targetNode.nodeKey,
        matchedTriggerName: `Trigger "${match.matchedKeyword}" (${trigger.category})`,
        isHumanHandoff: targetNode.nodeType === 'agent_handoff',
        updatedSession,
        newLeadCreated,
      };
    }
  }

  // 4. Check if text matches any current node's options by text label
  const matchingOption = currentNode.options.find(
    opt => opt.label.toLowerCase().includes(trimmedText.toLowerCase()) ||
           trimmedText.toLowerCase().includes(opt.label.toLowerCase())
  );

  if (matchingOption && matchingOption.destinationNodeId) {
    const targetNode = nodeMap.get(matchingOption.destinationNodeId);
    if (targetNode) {
      updatedSession.currentNodeId = targetNode.id;
      if (targetNode.nodeType === 'agent_handoff') {
        updatedSession.status = 'human_takeover';
      }

      return {
        replyText: targetNode.responseText,
        options: targetNode.options,
        nodeId: targetNode.id,
        nodeKey: targetNode.nodeKey,
        matchedTriggerName: `Option Button "${matchingOption.label}"`,
        isHumanHandoff: targetNode.nodeType === 'agent_handoff',
        updatedSession,
        newLeadCreated,
      };
    }
  }

  // 5. Check business hours offline notice
  const open = isCurrentlyOpen(settings);
  let prefix = '';
  let isAfterHoursNotice = false;

  if (!open && settings.offlineMessage) {
    prefix = `${settings.offlineMessage}\n\n`;
    isAfterHoursNotice = true;
  }

  // 6. Deterministic Fallback Response (no AI)
  return {
    replyText: `${prefix}${settings.fallbackMessage}`,
    options: currentNode.options.length > 0 ? currentNode.options : startNode.options,
    nodeId: currentNode.id,
    nodeKey: 'fallback',
    isAfterHoursNotice,
    updatedSession,
    newLeadCreated,
  };
}
