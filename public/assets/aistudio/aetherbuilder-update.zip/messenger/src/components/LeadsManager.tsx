import React, { useState } from 'react';
import { 
  Download, 
  Mail, 
  Phone, 
  Search, 
  Filter, 
  Calendar
} from 'lucide-react';
import { Lead } from '../types/chatbot';

interface LeadsManagerProps {
  leads: Lead[];
  onUpdateLeadStatus: (id: string, status: Lead['status'], notes?: string) => Promise<void>;
}

export const LeadsManager: React.FC<LeadsManagerProps> = ({
  leads,
  onUpdateLeadStatus,
}) => {
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLeads = leads.filter(l => {
    if (statusFilter !== 'all' && l.status !== statusFilter) return false;
    if (searchTerm) {
      return (
        l.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        l.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        l.phone.toLowerCase().includes(searchTerm.toLowerCase()) ||
        l.inquiry.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    return true;
  });

  const exportCsv = () => {
    const headers = ['ID', 'Full Name', 'Email', 'Phone', 'Inquiry', 'Captured At', 'Status', 'Notes'];
    const rows = leads.map(l => [
      `"${l.id}"`,
      `"${l.fullName.replace(/"/g, '""')}"`,
      `"${l.email}"`,
      `"${l.phone}"`,
      `"${l.inquiry.replace(/"/g, '""')}"`,
      `"${l.capturedAt}"`,
      `"${l.status}"`,
      `"${(l.notes || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `leads-export-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 bg-white dark:bg-[#111827] p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">Captured Leads & Inquiries CRM</h2>
            <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
              {leads.length} Captured Inquiries
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Collected 24/7 through Facebook Messenger interactive forms and decision tree steps.
          </p>
        </div>

        <button
          onClick={exportCsv}
          disabled={leads.length === 0}
          className="inline-flex items-center px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 mr-1.5" />
          Export to CSV
        </button>
      </div>

      {/* Tab Purpose & Usage Guide Banner */}
      <div className="mb-6 rounded-xl border-l-4 border-l-blue-600 border border-slate-200 dark:border-slate-800 bg-gradient-to-r from-blue-50/70 via-white to-transparent dark:from-blue-950/20 dark:via-slate-900/40 dark:to-transparent p-5 space-y-3">
        <div className="flex items-start gap-3">
          <span className="text-2xl leading-none">👥</span>
          <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300 w-full">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Tab Purpose & How to Use Captured Leads CRM
              </h3>
              <p className="leading-relaxed mt-0.5">
                <strong>Purpose:</strong> View, manage, and follow up with prospective clients, seminar registrants, and customers who submitted their contact details (Full Name, Email, Phone number, and Inquiry Notes) during 24/7 automated decision tree flows.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  1. Automatic 24/7 Lead Capture
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  When a customer completes an <strong>Input Node</strong> step in Messenger, their contact info and inquiry are automatically stored here with a timestamp.
                </span>
              </div>

              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  2. Pipeline Status Tracking
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  Change any lead's status dropdown: <code>New</code> → <code>Contacted</code> → <code>Resolved</code> → <code>Archived</code>. Keep your sales or compliance team in sync.
                </span>
              </div>

              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  3. 1-Click CSV Export
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  Click <strong>Export to CSV</strong> at top right to download all customer inquiries into an Excel or Google Sheets spreadsheet for your external CRM!
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div className="relative max-w-sm w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search leads by name, email, or inquiry..."
            className="w-full bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-xs text-slate-500 dark:text-slate-400">Filter Status:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-white dark:bg-[#111827] text-xs text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-1.5 focus:outline-none focus:border-blue-500"
          >
            <option value="all">All ({leads.length})</option>
            <option value="new">New Inquiries</option>
            <option value="contacted">Contacted</option>
            <option value="resolved">Resolved / Converted</option>
            <option value="archived">Archived</option>
          </select>
        </div>
      </div>

      {/* Leads Table */}
      <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs">
        {filteredLeads.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-4">Customer Contact</th>
                  <th className="py-3 px-4">Inquiry / Topic Requested</th>
                  <th className="py-3 px-4">Captured At</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredLeads.map((lead) => (
                  <tr key={lead.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900 dark:text-slate-100 text-sm">{lead.fullName}</div>
                      <div className="flex items-center space-x-3 mt-1 text-[11px] text-slate-500 dark:text-slate-400">
                        {lead.email && (
                          <a
                            href={`mailto:${lead.email}`}
                            className="hover:text-blue-600 dark:hover:text-blue-400 flex items-center"
                          >
                            <Mail className="w-3 h-3 mr-1 inline text-slate-400" /> {lead.email}
                          </a>
                        )}
                        {lead.phone && (
                          <a
                            href={`tel:${lead.phone}`}
                            className="hover:text-blue-600 dark:hover:text-blue-400 flex items-center"
                          >
                            <Phone className="w-3 h-3 mr-1 inline text-slate-400" /> {lead.phone}
                          </a>
                        )}
                      </div>
                    </td>

                    <td className="py-3 px-4 max-w-xs">
                      <div className="text-slate-800 dark:text-slate-200 line-clamp-2 leading-relaxed">
                        {lead.inquiry}
                      </div>
                      {lead.notes && (
                        <div className="text-[10px] text-slate-500 italic mt-0.5">
                          Note: {lead.notes}
                        </div>
                      )}
                    </td>

                    <td className="py-3 px-4 text-slate-500 dark:text-slate-400 text-[11px] whitespace-nowrap">
                      <div className="flex items-center">
                        <Calendar className="w-3 h-3 mr-1 text-slate-400" />
                        {lead.capturedAt}
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <select
                        value={lead.status}
                        onChange={(e) => onUpdateLeadStatus(lead.id, e.target.value as Lead['status'])}
                        className="text-xs font-medium rounded-lg px-2.5 py-1 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 focus:outline-none"
                      >
                        <option value="new">New</option>
                        <option value="contacted">Contacted</option>
                        <option value="resolved">Resolved</option>
                        <option value="archived">Archived</option>
                      </select>
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-2">
                        {lead.email && (
                          <a
                            href={`mailto:${lead.email}?subject=Follow-up on your Inquiry`}
                            className="p-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg transition"
                            title="Send Direct Email"
                          >
                            <Mail className="w-3.5 h-3.5" />
                          </a>
                        )}
                        {lead.phone && (
                          <a
                            href={`tel:${lead.phone}`}
                            className="p-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg transition"
                            title="Call Phone Number"
                          >
                            <Phone className="w-3.5 h-3.5" />
                          </a>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-8 text-center text-slate-500 dark:text-slate-400 text-xs">
            No leads match current filter.
          </div>
        )}
      </div>
    </div>
  );
};
