import React from 'react';
import { 
  MessageSquare, 
  GitFork, 
  Key, 
  BookOpen, 
  Inbox, 
  Users, 
  Webhook, 
  Download, 
  Sun,
  Moon,
  ShieldCheck,
  GitBranch,
  Package,
  Sparkles
} from 'lucide-react';
import { BotSettings } from '../types/chatbot';
import { useTheme } from '../context/ThemeContext';

export type ActiveTab = 
  | 'simulator' 
  | 'flows' 
  | 'products'
  | 'ai-studio'
  | 'keywords' 
  | 'canned' 
  | 'inbox' 
  | 'leads' 
  | 'webhook' 
  | 'updates'
  | 'export';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isOpen: boolean;
  settings: BotSettings;
  leadsCount: number;
  unreadInboxCount: number;
  productsCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  isOpen,
  settings,
  leadsCount,
  unreadInboxCount,
  productsCount = 0,
}) => {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="border-b transition-colors bg-white dark:bg-[#0f172a] border-slate-200 dark:border-slate-800/80 sticky top-0 z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-lg bg-blue-600 dark:bg-blue-600 flex items-center justify-center text-white font-bold text-lg shadow-sm">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-base text-slate-900 dark:text-slate-100 tracking-tight">
                  Messenger 24/7 Support Bot Studio
                </span>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                  <ShieldCheck className="w-3 h-3 mr-1 inline text-blue-600 dark:text-blue-400" /> 100% Rule-Based
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block">
                Automated customer support & decision trees for Facebook Pages
              </p>
            </div>
          </div>

          {/* Right Controls: Theme Preset & Status & Export */}
          <div className="flex items-center space-x-2.5">
            {/* 24/7 Status Indicator */}
            <div className="hidden lg:flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 text-xs">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-600"></span>
              </span>
              <span className="text-slate-600 dark:text-slate-300 font-medium">
                Bot: <span className="text-slate-900 dark:text-slate-100 font-semibold">24/7 Active</span>
              </span>
              <span className="text-slate-300 dark:text-slate-600">|</span>
              <span className="text-slate-600 dark:text-slate-300">
                Desk: {isOpen ? 'Open (Live Team)' : 'After-Hours'}
              </span>
            </div>

            {/* Theme Preset Switcher (Light / Dark) */}
            <button
              onClick={toggleTheme}
              className="inline-flex items-center px-2 sm:px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 transition cursor-pointer shrink-0"
              title="Toggle Light / Dark theme preset"
              aria-label="Toggle theme preset"
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="w-3.5 h-3.5 sm:mr-1.5 text-amber-400" />
                  <span className="hidden sm:inline">Light Mode</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 sm:mr-1.5 text-slate-600" />
                  <span className="hidden sm:inline">Dark Mode</span>
                </>
              )}
            </button>

            {/* Export Package Shortcut */}
            <button
              onClick={() => setActiveTab('export')}
              className="inline-flex items-center px-2.5 sm:px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white shadow-xs transition shrink-0"
            >
              <Download className="w-3.5 h-3.5 sm:mr-1.5" />
              <span className="hidden sm:inline">Export Web Package</span>
              <span className="sm:hidden ml-1">Export</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 overflow-x-auto pb-1 scrollbar-none border-t border-slate-100 dark:border-slate-800/80 pt-1">
          <button
            onClick={() => setActiveTab('simulator')}
            className={`flex items-center px-3 py-2 text-xs font-medium rounded-md transition whitespace-nowrap ${
              activeTab === 'simulator'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 mr-1.5" />
            Messenger Simulator
          </button>

          <button
            onClick={() => setActiveTab('flows')}
            className={`flex items-center px-3 py-2 text-xs font-medium rounded-md transition whitespace-nowrap ${
              activeTab === 'flows'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <GitFork className="w-3.5 h-3.5 mr-1.5" />
            Decision Tree Flows
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`flex items-center px-3 py-2 text-xs font-medium rounded-md transition whitespace-nowrap relative ${
              activeTab === 'products'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <Package className="w-3.5 h-3.5 mr-1.5 text-blue-500" />
            Products & Services
            {productsCount > 0 && (
              <span className="ml-1.5 px-1.5 py-0.2 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 text-[10px] rounded-full font-bold">
                {productsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('ai-studio')}
            className={`flex items-center px-3 py-2 text-xs font-medium rounded-md transition whitespace-nowrap ${
              activeTab === 'ai-studio'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
            AI Flow Studio
          </button>

          <button
            onClick={() => setActiveTab('keywords')}
            className={`flex items-center px-3 py-2 text-xs font-medium rounded-md transition whitespace-nowrap ${
              activeTab === 'keywords'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <Key className="w-3.5 h-3.5 mr-1.5" />
            Keyword Triggers
          </button>

          <button
            onClick={() => setActiveTab('canned')}
            className={`flex items-center px-3 py-2 text-xs font-medium rounded-md transition whitespace-nowrap ${
              activeTab === 'canned'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 mr-1.5" />
            24/7 FAQ Knowledge Base
          </button>

          <button
            onClick={() => setActiveTab('inbox')}
            className={`flex items-center px-3 py-2 text-xs font-medium rounded-md transition whitespace-nowrap relative ${
              activeTab === 'inbox'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <Inbox className="w-3.5 h-3.5 mr-1.5" />
            Live Inbox & Takeover
            {unreadInboxCount > 0 && (
              <span className="ml-1.5 px-1.5 py-0.2 bg-slate-900 dark:bg-slate-700 text-white text-[10px] rounded-full font-bold">
                {unreadInboxCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('leads')}
            className={`flex items-center px-3 py-2 text-xs font-medium rounded-md transition whitespace-nowrap relative ${
              activeTab === 'leads'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <Users className="w-3.5 h-3.5 mr-1.5" />
            Captured Leads
            {leadsCount > 0 && (
              <span className="ml-1.5 px-1.5 py-0.2 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 text-[10px] rounded-full font-bold">
                {leadsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('webhook')}
            className={`flex items-center px-3 py-2 text-xs font-medium rounded-md transition whitespace-nowrap ${
              activeTab === 'webhook'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <Webhook className="w-3.5 h-3.5 mr-1.5" />
            Meta Webhook & Settings
          </button>

          <button
            onClick={() => setActiveTab('updates')}
            className={`flex items-center px-3 py-2 text-xs font-medium rounded-md transition whitespace-nowrap ${
              activeTab === 'updates'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <GitBranch className="w-3.5 h-3.5 mr-1.5" />
            System Updates & Versioning
            <span className="ml-1.5 px-1.5 py-0.2 bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 text-[10px] rounded-full font-bold">
              v1.5.7
            </span>
          </button>

          <button
            onClick={() => setActiveTab('export')}
            className={`flex items-center px-3 py-2 text-xs font-medium rounded-md transition whitespace-nowrap ${
              activeTab === 'export'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            <Download className="w-3.5 h-3.5 mr-1.5" />
            Host Deployment Package
          </button>
        </div>
      </div>
    </header>
  );
};
