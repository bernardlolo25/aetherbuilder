import React, { useState, useMemo } from 'react';
import { 
  Sparkles, 
  Copy, 
  Check, 
  ExternalLink, 
  Package, 
  CheckSquare, 
  Square, 
  Bot, 
  FileJson, 
  Upload, 
  Layers, 
  RefreshCw, 
  Zap,
  ShoppingBag,
  Send,
  AlertCircle,
  HelpCircle,
  Play
} from 'lucide-react';
import { ProductItem, FlowNode, KeywordTrigger } from '../types/chatbot';
import { GoogleGenAI } from '@google/genai';

interface AIFlowStudioProps {
  products: ProductItem[];
  selectedProductIds: string[];
  onToggleSelectProduct: (id: string) => void;
  onSelectAllProducts: (select: boolean) => void;
  onImportFlow: (nodes: FlowNode[], keywords?: KeywordTrigger[], clearExisting?: boolean) => void;
  onNavigateToSimulator: () => void;
}

export const AIFlowStudio: React.FC<AIFlowStudioProps> = ({
  products,
  selectedProductIds,
  onToggleSelectProduct,
  onSelectAllProducts,
  onImportFlow,
  onNavigateToSimulator,
}) => {
  const [businessType, setBusinessType] = useState('Professional Services & Education');
  const [businessTone, setBusinessTone] = useState<'friendly' | 'professional' | 'persuasive' | 'concise'>('friendly');
  const [botGoal, setBotGoal] = useState<'sales_and_orders' | 'lead_generation' | 'support_and_faq'>('sales_and_orders');
  const [includeKeywords, setIncludeKeywords] = useState(true);
  const [includeLeadCapture, setIncludeLeadCapture] = useState(true);
  const [customInstructions, setCustomInstructions] = useState('');
  
  const [copiedPrompt, setCopiedPrompt] = useState(false);
  const [copiedTemplate, setCopiedTemplate] = useState(false);
  const [jsonInput, setJsonInput] = useState('');
  const [importStatus, setImportStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  const selectedProducts = useMemo(() => {
    return products.filter((p) => selectedProductIds.includes(p.id));
  }, [products, selectedProductIds]);

  // Generate the Master Prompt incorporating all selected products and prices
  const generatedPrompt = useMemo(() => {
    const productsList = selectedProducts.map((p, idx) => {
      const priceFormatted = `${p.currency === 'USD' ? '$' : p.currency === 'PHP' ? '₱' : `${p.currency} `}${p.price.toLocaleString()}`;
      return `${idx + 1}. **${p.name}**
   - Category: ${p.category}
   - Price: ${priceFormatted} (${p.currency})
   - SKU: ${p.sku || 'N/A'}
   - Description: ${p.description || 'Quality product/service'}
   - Image Link: ${p.imageUrl || 'No image'}
   - Key Features: ${p.features && p.features.length > 0 ? p.features.join(', ') : 'Direct support included'}
   - Action Button: "${p.actionButtonLabel || 'Order Now'}"`;
    }).join('\n\n');

    return `You are an expert Facebook Messenger 24/7 Chatbot Architect and Conversational Flow Designer.

TASK:
Generate a deterministic, production-grade decision tree chatbot flow for Facebook Messenger for our business: "${businessType}".

BUSINESS CONTEXT & GOAL:
- Tone of Voice: ${businessTone}
- Primary Objective: ${botGoal === 'sales_and_orders' ? 'Showcase product catalog, handle price inquiries, and capture customer orders/inquiries' : 'Capture qualified customer leads and inquiries'}
- Connected Lead Capture: ${includeLeadCapture ? 'YES - after customer selects an item or requests an order, guide them to provide Name, Email, and Phone number' : 'NO'}
- Keyword Triggers: ${includeKeywords ? 'YES - generate keyword triggers like "pricing", "catalog", "order", "rates", "services", "buy"' : 'NO'}
${customInstructions ? `- Special Instructions: ${customInstructions}` : ''}

OFFICIAL PRODUCT & SERVICES CATALOG TO FEATURE IN THE BOT:
${productsList || 'No specific products provided. Generate a sample catalog for our business.'}

OUTPUT FORMAT SPECIFICATION:
Please respond ONLY with a clean, valid JSON object following this exact schema so our Messenger bot engine can import it in 1 click:

{
  "nodes": [
    {
      "id": "node-welcome",
      "nodeKey": "welcome_catalog",
      "nodeName": "Welcome Greeting & Products Menu",
      "nodeType": "start",
      "responseText": "👋 Welcome to our automated Messenger assistant! Explore our featured products & services below:",
      "isStart": true,
      "isActive": true,
      "options": [
        {
          "id": "opt-cat-1",
          "label": "🛍 View Products & Rates",
          "destinationNodeId": "node-catalog-carousel",
          "payload": "PAYLOAD_CATALOG"
        },
        {
          "id": "opt-cat-2",
          "label": "👤 Talk to Live Agent",
          "destinationNodeId": "node-handoff",
          "payload": "PAYLOAD_AGENT"
        }
      ]
    },
    {
      "id": "node-catalog-carousel",
      "nodeKey": "product_showcase",
      "nodeName": "Product Catalog Carousel",
      "nodeType": "carousel",
      "responseText": "Here are our featured offerings with current pricing. Tap below to order or get details:",
      "isActive": true,
      "options": [],
      "carouselCards": [
        ${selectedProducts.slice(0, 10).map((p, idx) => `{
          "id": "card-${idx + 1}",
          "title": "${p.name.replace(/"/g, '\\"')}",
          "subtitle": "${p.currency === 'USD' ? '$' : p.currency === 'PHP' ? '₱' : `${p.currency} `}${p.price.toLocaleString()} · ${p.description.replace(/"/g, '\\"').slice(0, 75)}",
          "imageUrl": "${p.imageUrl || 'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=600&q=80'}",
          "buttons": [
            {
              "label": "${p.actionButtonLabel || 'Order Now'}",
              "type": "postback",
              "payload": "PAYLOAD_ORDER_${p.id}",
              "destinationNodeId": "node-lead-name"
            }
          ]
        }`).join(',\n        ')}
      ]
    },
    {
      "id": "node-lead-name",
      "nodeKey": "capture_name",
      "nodeName": "Capture Customer Name",
      "nodeType": "input",
      "responseText": "Awesome choice! Let's get your details so our team can confirm your order immediately.\n\nPlease enter your Full Name:",
      "isActive": true,
      "options": [],
      "inputConfig": {
        "fieldToCapture": "name",
        "destinationNodeIdOnSuccess": "node-lead-email"
      }
    },
    {
      "id": "node-lead-email",
      "nodeKey": "capture_email",
      "nodeName": "Capture Customer Email",
      "nodeType": "input",
      "responseText": "Thank you! What is your best Email Address for confirmation?",
      "isActive": true,
      "options": [],
      "inputConfig": {
        "fieldToCapture": "email",
        "destinationNodeIdOnSuccess": "node-lead-success"
      }
    },
    {
      "id": "node-lead-success",
      "nodeKey": "order_confirmed",
      "nodeName": "Order Confirmation & Thank You",
      "nodeType": "message",
      "responseText": "🎉 Thank you! Your inquiry & order details have been securely logged. Our team will message you right here shortly with next steps.",
      "isActive": true,
      "options": [
        {
          "id": "opt-done-menu",
          "label": "↩ Back to Main Menu",
          "destinationNodeId": "node-welcome",
          "payload": "PAYLOAD_MENU"
        }
      ]
    }
  ],
  "keywords": [
    {
      "id": "kw-price",
      "keyword": "price, rates, pricing, how much, cost, fees",
      "matchType": "contains",
      "priority": 15,
      "destinationNodeId": "node-catalog-carousel",
      "category": "pricing",
      "isEnabled": true
    },
    {
      "id": "kw-catalog",
      "keyword": "catalog, products, services, courses, buy, order",
      "matchType": "contains",
      "priority": 15,
      "destinationNodeId": "node-catalog-carousel",
      "category": "pricing",
      "isEnabled": true
    }
  ]
}

DO NOT wrap the response in markdown quotes if possible. Output valid, parseable JSON only.`;
  }, [
    businessType,
    businessTone,
    botGoal,
    includeKeywords,
    includeLeadCapture,
    customInstructions,
    selectedProducts,
  ]);

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(generatedPrompt);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2500);
  };

  // Dedicated Launchers (from changelog v1.4.4)
  const openAILauncher = (url: string, name: string) => {
    handleCopyPrompt();
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  // 1-Click Instant Flow Generation using direct Gemini API or fallback
  const handleGenerateDirectWithAI = async () => {
    setIsGeneratingAI(true);
    setAiError(null);
    setImportStatus(null);

    try {
      // Call Gemini using @google/genai with fallback handling
      const ai = new GoogleGenAI();
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: generatedPrompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.3,
        },
      });

      const text = response.text;
      if (text) {
        setJsonInput(text);
        setImportStatus({
          type: 'success',
          message: '✨ Flow JSON generated successfully! Review below and click "Import Flow into Bot".',
        });
      } else {
        throw new Error('Empty response from AI');
      }
    } catch (err: unknown) {
      console.warn('AI direct generation fallback:', err);
      // Fallback: build instant instant deterministic flow from selected products
      handleGenerateLocalInstantFlow();
    } finally {
      setIsGeneratingAI(false);
    }
  };

  // Immediate deterministic local flow builder from selected products (0ms wait, guaranteed works offline)
  const handleGenerateLocalInstantFlow = () => {
    const catalogCards = selectedProducts.map((p, idx) => ({
      id: `card-${p.id || idx + 1}`,
      title: p.name,
      subtitle: `${p.currency === 'USD' ? '$' : p.currency === 'PHP' ? '₱' : `${p.currency} `}${p.price.toLocaleString()} · ${p.description.slice(0, 75)}`,
      imageUrl: p.imageUrl || 'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=600&q=80',
      buttons: [
        {
          label: p.actionButtonLabel || 'Order Now',
          type: 'postback' as const,
          payload: `PAYLOAD_ORDER_${p.id}`,
          destinationNodeId: 'node-lead-name',
        },
      ],
    }));

    const instantFlow = {
      nodes: [
        {
          id: 'node-welcome',
          nodeKey: 'welcome_catalog',
          nodeName: 'Welcome Greeting & Catalog Menu',
          nodeType: 'start',
          responseText: `👋 Welcome to ${businessType}! Explore our official catalog and pricing below, or ask us any question anytime:`,
          isStart: true,
          isActive: true,
          options: [
            {
              id: 'opt-cat-1',
              label: '🛍 Browse Products & Rates',
              destinationNodeId: 'node-catalog-carousel',
              payload: 'PAYLOAD_CATALOG',
            },
            {
              id: 'opt-cat-2',
              label: '👤 Talk to Human Specialist',
              destinationNodeId: 'node-handoff',
              payload: 'PAYLOAD_AGENT',
            },
          ],
        },
        {
          id: 'node-catalog-carousel',
          nodeKey: 'product_showcase',
          nodeName: 'Product & Services Catalog Carousel',
          nodeType: 'carousel',
          responseText: `Here are our ${selectedProducts.length} featured offerings with live pricing. Swipe through and tap to order or inquire:`,
          isActive: true,
          options: [],
          carouselCards: catalogCards,
        },
        {
          id: 'node-lead-name',
          nodeKey: 'capture_name',
          nodeName: 'Lead Step 1 - Full Name',
          nodeType: 'input',
          responseText: 'Great choice! Let\'s get your details so our team can follow up immediately.\n\nPlease enter your Full Name:',
          isActive: true,
          options: [],
          inputConfig: {
            fieldToCapture: 'name',
            destinationNodeIdOnSuccess: 'node-lead-email',
          },
        },
        {
          id: 'node-lead-email',
          nodeKey: 'capture_email',
          nodeName: 'Lead Step 2 - Email Address',
          nodeType: 'input',
          responseText: 'Thank you! What is your best Email Address to send confirmation or order invoice to?',
          isActive: true,
          options: [],
          inputConfig: {
            fieldToCapture: 'email',
            destinationNodeIdOnSuccess: 'node-lead-success',
          },
        },
        {
          id: 'node-lead-success',
          nodeKey: 'order_confirmed',
          nodeName: 'Order Inquiry Confirmed',
          nodeType: 'message',
          responseText: '🎉 Thank you! Your request and product selection have been recorded. Our team will review your details and message you right here shortly.',
          isActive: true,
          options: [
            {
              id: 'opt-back-start',
              label: '↩ Back to Main Menu',
              destinationNodeId: 'node-welcome',
              payload: 'PAYLOAD_MENU',
            },
          ],
        },
        {
          id: 'node-handoff',
          nodeKey: 'agent_handoff',
          nodeName: 'Human Live Agent Desk',
          nodeType: 'agent_handoff',
          responseText: '👤 You are now connected to our support desk. A human representative will be with you shortly. You may type your message below:',
          isActive: true,
          options: [
            {
              id: 'opt-back-menu',
              label: '↩ Restart Automated Bot',
              destinationNodeId: 'node-welcome',
              payload: 'PAYLOAD_MENU',
            },
          ],
        },
      ],
      keywords: [
        {
          id: 'kw-price',
          keyword: 'price, rates, pricing, how much, cost, fees, tuition',
          matchType: 'contains',
          priority: 20,
          destinationNodeId: 'node-catalog-carousel',
          category: 'pricing',
          isEnabled: true,
        },
        {
          id: 'kw-catalog',
          keyword: 'catalog, products, services, courses, buy, order, shop',
          matchType: 'contains',
          priority: 20,
          destinationNodeId: 'node-catalog-carousel',
          category: 'pricing',
          isEnabled: true,
        },
        {
          id: 'kw-agent',
          keyword: 'agent, human, support, representative, live chat, speak',
          matchType: 'contains',
          priority: 25,
          destinationNodeId: 'node-handoff',
          category: 'support',
          isEnabled: true,
        },
      ],
    };

    setJsonInput(JSON.stringify(instantFlow, null, 2));
    setImportStatus({
      type: 'success',
      message: `✨ Pre-built Instant Product Carousel Flow generated for ${selectedProducts.length} items! Click "Import Flow into Bot" below.`,
    });
  };

  // Import JSON into bot state
  const handleImportJson = (clearExisting: boolean) => {
    setImportStatus(null);
    if (!jsonInput.trim()) {
      setImportStatus({ type: 'error', message: 'Please paste or generate JSON flow data first.' });
      return;
    }

    try {
      // Clean possible markdown code fences
      let cleaned = jsonInput.trim();
      if (cleaned.startsWith('```json')) {
        cleaned = cleaned.replace(/^```json/, '').replace(/```$/, '').trim();
      } else if (cleaned.startsWith('```')) {
        cleaned = cleaned.replace(/^```/, '').replace(/```$/, '').trim();
      }

      const parsed = JSON.parse(cleaned);

      if (!parsed.nodes || !Array.isArray(parsed.nodes)) {
        throw new Error('JSON must contain a "nodes" array.');
      }

      onImportFlow(parsed.nodes, parsed.keywords || [], clearExisting);
      setImportStatus({
        type: 'success',
        message: `🎉 Successfully imported ${parsed.nodes.length} flow nodes and ${
          parsed.keywords?.length || 0
        } keywords! You can now test it live in the Simulator.`,
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Invalid JSON syntax';
      setImportStatus({
        type: 'error',
        message: `Failed to parse JSON: ${msg}. Please ensure valid formatting.`,
      });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-150">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center space-x-2 text-xs font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400 mb-1">
          <Sparkles className="w-4 h-4" />
          <span>AI Flow Studio & Prompt Generator (v1.5.1)</span>
        </div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 tracking-tight">
          Instant Decision Tree Generator with Product Catalog
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-3xl">
          Select products from your catalog to automatically generate targeted prompts for ChatGPT, DeepSeek, Claude, and Gemini. Copy the prompt or generate the complete JSON flow directly to import into your 24/7 Messenger bot.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Product Selector & Configuration (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Step 1: Select Products */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between mb-3 pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center space-x-2">
                <div className="w-7 h-7 rounded-lg bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold text-xs">
                  1
                </div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  Select Products to Include
                </h3>
              </div>
              <button
                type="button"
                onClick={() => onSelectAllProducts(selectedProductIds.length !== products.length)}
                className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-medium cursor-pointer"
              >
                {selectedProductIds.length === products.length ? 'Deselect All' : 'Select All'}
              </button>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              Chosen items will have prices, specs, and order buttons woven into the generated Messenger flow:
            </p>

            {products.length === 0 ? (
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 text-center text-xs text-slate-500">
                No products found in your catalog. Add products in the "Products" tab to include them here.
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {products.map((p) => {
                  const isChecked = selectedProductIds.includes(p.id);
                  return (
                    <div
                      key={p.id}
                      onClick={() => onToggleSelectProduct(p.id)}
                      className={`p-2.5 rounded-xl border transition flex items-center justify-between cursor-pointer ${
                        isChecked
                          ? 'bg-blue-50/70 dark:bg-blue-950/30 border-blue-400 dark:border-blue-600'
                          : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center space-x-2.5 min-w-0">
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-blue-600 shrink-0" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-400 shrink-0" />
                        )}
                        {p.imageUrl && (
                          <img
                            src={p.imageUrl}
                            alt={p.name}
                            className="w-8 h-8 rounded-lg object-cover shrink-0 border border-slate-200 dark:border-slate-700"
                          />
                        )}
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                            {p.name}
                          </p>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                            {p.category}
                          </p>
                        </div>
                      </div>
                      <span className="text-xs font-bold text-blue-600 dark:text-blue-400 shrink-0 ml-2">
                        {p.currency === 'USD' ? '$' : p.currency === 'PHP' ? '₱' : `${p.currency} `}
                        {p.price.toLocaleString()}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
              <span>Selected for AI Prompt:</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200">
                {selectedProducts.length} of {products.length} Items
              </span>
            </div>
          </div>

          {/* Step 2: Bot Purpose & Flow Settings */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center space-x-2 pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="w-7 h-7 rounded-lg bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-xs">
                2
              </div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Flow Style & Objective
              </h3>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Business Domain / Industry
              </label>
              <input
                type="text"
                value={businessType}
                onChange={(e) => setBusinessType(e.target.value)}
                placeholder="e.g. Legal & MCLE Compliance, Dental Clinic, Boutique Store"
                className="w-full px-3 py-1.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Conversational Tone
                </label>
                <select
                  value={businessTone}
                  onChange={(e) => setBusinessTone(e.target.value as any)}
                  className="w-full px-3 py-1.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                >
                  <option value="friendly">Warm & Friendly</option>
                  <option value="professional">Professional & Crisp</option>
                  <option value="persuasive">High-Converting Sales</option>
                  <option value="concise">Concise & Direct</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Primary Flow Goal
                </label>
                <select
                  value={botGoal}
                  onChange={(e) => setBotGoal(e.target.value as any)}
                  className="w-full px-3 py-1.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                >
                  <option value="sales_and_orders">Direct Orders & Catalog</option>
                  <option value="lead_generation">Inquiry & Lead Capture</option>
                  <option value="support_and_faq">24/7 FAQ & Self-Service</option>
                </select>
              </div>
            </div>

            <div className="space-y-2 pt-1">
              <label className="flex items-center space-x-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeKeywords}
                  onChange={(e) => setIncludeKeywords(e.target.checked)}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <span>Generate matching Keyword Triggers (rates, prices, catalog)</span>
              </label>

              <label className="flex items-center space-x-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeLeadCapture}
                  onChange={(e) => setIncludeLeadCapture(e.target.checked)}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <span>Include automated customer lead capture (Name, Email, Phone)</span>
              </label>
            </div>
          </div>
        </div>

        {/* Right Column: Generated Prompt, 1-Click Launchers, & JSON Importer (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Prompt Viewer & External Window Launchers */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between mb-3 pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center space-x-2">
                <div className="w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold text-xs">
                  3
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    Instant AI Prompt & Launchers
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Pre-formatted with your exact products, prices, and JSON schema
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handleCopyPrompt}
                className={`inline-flex items-center px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                  copiedPrompt
                    ? 'bg-emerald-600 text-white'
                    : 'bg-blue-600 hover:bg-blue-500 text-white shadow-xs'
                }`}
              >
                {copiedPrompt ? (
                  <>
                    <Check className="w-3.5 h-3.5 mr-1.5" />
                    <span>Copied to Clipboard!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 mr-1.5" />
                    <span>Copy Master Prompt</span>
                  </>
                )}
              </button>
            </div>

            {/* Prompt Textarea Preview */}
            <div className="relative mb-4">
              <textarea
                readOnly
                rows={6}
                value={generatedPrompt}
                className="w-full p-3 rounded-xl text-[11px] font-mono bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 leading-relaxed resize-none focus:outline-hidden"
              />
            </div>

            {/* 1-Click Launchers Suite (Changelog v1.4.4 feature) */}
            <div>
              <span className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
                1-Click Launchers (Copies prompt & opens AI assistant):
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={() => openAILauncher('https://chatgpt.com', 'ChatGPT')}
                  className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 bg-slate-50 dark:bg-slate-800/60 hover:bg-white dark:hover:bg-slate-800 text-left transition flex items-center justify-between group cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-sm">🟢</span>
                    <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">ChatGPT</span>
                  </div>
                  <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-500 transition" />
                </button>

                <button
                  type="button"
                  onClick={() => openAILauncher('https://chat.deepseek.com', 'DeepSeek')}
                  className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 bg-slate-50 dark:bg-slate-800/60 hover:bg-white dark:hover:bg-slate-800 text-left transition flex items-center justify-between group cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-sm">🔵</span>
                    <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">DeepSeek</span>
                  </div>
                  <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-500 transition" />
                </button>

                <button
                  type="button"
                  onClick={() => openAILauncher('https://claude.ai', 'Claude')}
                  className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-amber-500 dark:hover:border-amber-500 bg-slate-50 dark:bg-slate-800/60 hover:bg-white dark:hover:bg-slate-800 text-left transition flex items-center justify-between group cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-sm">🟠</span>
                    <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">Claude</span>
                  </div>
                  <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-500 transition" />
                </button>

                <button
                  type="button"
                  onClick={() => openAILauncher('https://aistudio.google.com', 'AI Studio')}
                  className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-purple-500 dark:hover:border-purple-500 bg-slate-50 dark:bg-slate-800/60 hover:bg-white dark:hover:bg-slate-800 text-left transition flex items-center justify-between group cursor-pointer"
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-sm">🟣</span>
                    <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">AI Studio</span>
                  </div>
                  <ExternalLink className="w-3.5 h-3.5 text-slate-400 group-hover:text-purple-500 transition" />
                </button>
              </div>
            </div>

            {/* Direct Instant Flow Generator Buttons */}
            <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap gap-2.5">
              <button
                type="button"
                onClick={handleGenerateLocalInstantFlow}
                className="flex-1 inline-flex items-center justify-center px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-md transition cursor-pointer"
              >
                <Zap className="w-4 h-4 mr-1.5 text-amber-300" />
                <span>Instant Pre-Built Flow (0s wait)</span>
              </button>

              <button
                type="button"
                onClick={handleGenerateDirectWithAI}
                disabled={isGeneratingAI}
                className="inline-flex items-center justify-center px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-semibold text-xs shadow-md transition cursor-pointer"
              >
                {isGeneratingAI ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-1.5 animate-spin" />
                    <span>Generating with Gemini...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-1.5" />
                    <span>Generate via Gemini AI</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* JSON Flow Importer */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between mb-3 pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center space-x-2">
                <div className="w-7 h-7 rounded-lg bg-amber-100 dark:bg-amber-900/40 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold text-xs">
                  4
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    1-Click JSON Flow Importer
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Paste the AI response or edit the generated JSON flow below
                  </p>
                </div>
              </div>
            </div>

            {/* Status Alert */}
            {importStatus && (
              <div
                className={`mb-3 p-3 rounded-xl text-xs flex items-center space-x-2 ${
                  importStatus.type === 'success'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                    : 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
                }`}
              >
                {importStatus.type === 'success' ? (
                  <Check className="w-4 h-4 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{importStatus.message}</span>
              </div>
            )}

            <div className="relative mb-3">
              <textarea
                rows={8}
                value={jsonInput}
                onChange={(e) => setJsonInput(e.target.value)}
                placeholder='Paste generated JSON flow here (e.g. { "nodes": [...], "keywords": [...] })...'
                className="w-full p-3 rounded-xl text-xs font-mono bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                type="button"
                onClick={onNavigateToSimulator}
                className="w-full sm:w-auto inline-flex items-center justify-center px-3.5 py-2 rounded-xl text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              >
                <Play className="w-3.5 h-3.5 mr-1.5 text-blue-600" />
                <span>Open Simulator to Test</span>
              </button>

              <div className="flex items-center space-x-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => handleImportJson(false)}
                  className="flex-1 sm:flex-initial inline-flex items-center justify-center px-4 py-2.5 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 transition"
                  title="Merge into current bot nodes"
                >
                  <Layers className="w-3.5 h-3.5 mr-1.5" />
                  <span>Merge with Existing</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleImportJson(true)}
                  className="flex-1 sm:flex-initial inline-flex items-center justify-center px-5 py-2.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md transition"
                  title="Replace flow with this new catalog structure"
                >
                  <Upload className="w-3.5 h-3.5 mr-1.5" />
                  <span>Import Flow into Bot</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
