import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Edit3, 
  Check, 
  ArrowRight, 
  FileText
} from 'lucide-react';
import { FlowNode, NodeType, FlowOption } from '../types/chatbot';

interface FlowBuilderProps {
  nodes: FlowNode[];
  onSaveNode: (node: FlowNode) => Promise<void>;
  onDeleteNode: (id: string) => Promise<void>;
  onSetStartNode: (id: string) => Promise<void>;
  onAddNode: (nodeData: Partial<FlowNode>) => Promise<void>;
}

export const FlowBuilder: React.FC<FlowBuilderProps> = ({
  nodes,
  onSaveNode,
  onDeleteNode,
  onSetStartNode,
  onAddNode,
}) => {
  const [editingNode, setEditingNode] = useState<FlowNode | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [filterType, setFilterType] = useState<string>('all');

  const [formName, setFormName] = useState('');
  const [formKey, setFormKey] = useState('');
  const [formType, setFormType] = useState<NodeType>('message');
  const [formText, setFormText] = useState('');
  const [formOptions, setFormOptions] = useState<FlowOption[]>([]);
  const [newOptLabel, setNewOptLabel] = useState('');
  const [newOptDest, setNewOptDest] = useState('');

  const [inlineEditingId, setInlineEditingId] = useState<string | null>(null);
  const [inlineEditText, setInlineEditText] = useState('');
  const [saveAlert, setSaveAlert] = useState<string | null>(null);

  const handleStartInlineEdit = (node: FlowNode) => {
    setInlineEditingId(node.id);
    setInlineEditText(node.responseText);
  };

  const handleSaveInlineEdit = async (node: FlowNode) => {
    if (!inlineEditText.trim()) return;
    await onSaveNode({
      ...node,
      responseText: inlineEditText.trim(),
    });
    setInlineEditingId(null);
    setSaveAlert(`Updated "${node.nodeName}" greeting text successfully!`);
    setTimeout(() => setSaveAlert(null), 3000);
  };

  const openEditModal = (node: FlowNode) => {
    setEditingNode(node);
    setFormName(node.nodeName);
    setFormKey(node.nodeKey);
    setFormType(node.nodeType);
    setFormText(node.responseText);
    setFormOptions([...node.options]);
    setIsCreatingNew(false);
  };

  const openCreateModal = () => {
    setEditingNode(null);
    setFormName('');
    setFormKey('');
    setFormType('message');
    setFormText('');
    setFormOptions([]);
    setIsCreatingNew(true);
  };

  const handleAddOptionToForm = () => {
    if (!newOptLabel.trim()) return;
    const newOpt: FlowOption = {
      id: `opt-${Date.now()}`,
      label: newOptLabel.trim(),
      destinationNodeId: newOptDest || (nodes[0]?.id || ''),
      payload: `PAYLOAD_${newOptLabel.trim().toUpperCase().replace(/[^A-Z0-9]/g, '_')}`,
    };
    setFormOptions([...formOptions, newOpt]);
    setNewOptLabel('');
    setNewOptDest('');
  };

  const handleRemoveOptionFromForm = (optId: string) => {
    setFormOptions(formOptions.filter(o => o.id !== optId));
  };

  const handleSaveForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formKey.trim()) return;

    if (isCreatingNew) {
      await onAddNode({
        nodeName: formName.trim(),
        nodeKey: formKey.trim().toLowerCase().replace(/\s+/g, '_'),
        nodeType: formType,
        responseText: formText,
        options: formOptions,
        isActive: true,
      });
      setIsCreatingNew(false);
      setSaveAlert(`Created new node "${formName.trim()}"!`);
    } else if (editingNode) {
      await onSaveNode({
        ...editingNode,
        nodeName: formName.trim(),
        nodeKey: formKey.trim().toLowerCase().replace(/\s+/g, '_'),
        nodeType: formType,
        responseText: formText,
        options: formOptions,
      });
      setEditingNode(null);
      setSaveAlert(`Saved changes to "${formName.trim()}"!`);
    }
    setTimeout(() => setSaveAlert(null), 3000);
  };

  const filteredNodes = nodes.filter(n => {
    if (filterType === 'all') return true;
    return n.nodeType === filterType;
  });

  const getNodeNameById = (id: string) => {
    const found = nodes.find(n => n.id === id);
    return found ? found.nodeName : 'No destination assigned';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 bg-white dark:bg-[#111827] p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">Visual Decision Tree & Flow Builder</h2>
            <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
              {nodes.length} Nodes
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Design 24/7 automated decision trees, greetings, response cards, and quick reply choices.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Type Filter */}
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="bg-slate-100 dark:bg-slate-800 text-xs text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-blue-500"
          >
            <option value="all">All Node Types</option>
            <option value="start">Start / Greeting</option>
            <option value="message">Standard Message</option>
            <option value="carousel">🖼️ Product &amp; Image Carousel</option>
            <option value="input">Input / Lead Capture</option>
            <option value="agent_handoff">Live Agent Escalation</option>
          </select>

          <button
            onClick={openCreateModal}
            className="inline-flex items-center px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 mr-1" />
            Create Node
          </button>
        </div>
      </div>

      {saveAlert && (
        <div className="mb-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-300 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-600" />
          <span>{saveAlert}</span>
        </div>
      )}

      {/* Tab Purpose & Usage Guide Banner */}
      <div className="mb-6 rounded-xl border-l-4 border-l-blue-600 border border-slate-200 dark:border-slate-800 bg-gradient-to-r from-blue-50/70 via-white to-transparent dark:from-blue-950/20 dark:via-slate-900/40 dark:to-transparent p-5 space-y-3">
        <div className="flex items-start gap-3">
          <span className="text-2xl leading-none">🌿</span>
          <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300 w-full">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Tab Purpose & How to Use Decision Trees
              </h3>
              <p className="leading-relaxed mt-0.5">
                <strong>Purpose:</strong> Build interactive, automated 24/7 conversation paths for Facebook Messenger. When a customer sends a message or clicks "Get Started", your <strong>Start / Greeting Node</strong> answers immediately with self-service quick reply buttons. Customers click choices to explore FAQs, seminar dates, fees, or request human support.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  Step 1: Edit Main Menu Greeting (#start)
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  Click <strong>✏️ Edit Main Menu Greeting</strong> below to customize your welcome message: <em>"Welcome to the MCLE Messenger Assistant! How may we help you?"</em>. Attach quick buttons like <code>🗓️ Schedules</code>, <code>💳 Rates & Fees</code>, or <code>💬 Speak to Live Staff</code>.
                </span>
              </div>

              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  Step 2: Create Sub-Nodes & Answers
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  Enter <strong>Node Title</strong> (e.g., <em>Rates & Fees</em>), <strong>Node Key</strong> (e.g., <code>rates_info</code>), and <strong>Response Text</strong> (e.g., pricing packages, certificate guarantees). Then attach buttons to jump to next steps or back to Main Menu.
                </span>
              </div>

              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  Step 3: Collect Inquiries / Lead Capture
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  Select <strong>Input Node</strong> to ask for Customer Name, Email, or Phone number. Customer responses are automatically captured into the <strong>Captured Leads CRM</strong> table for follow-up!
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Nodes Board Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
        {filteredNodes.map((node) => (
          <div
            key={node.id}
            className={`bg-white dark:bg-[#111827] border rounded-2xl p-5 shadow-xs flex flex-col justify-between transition hover:border-slate-400 dark:hover:border-slate-600 ${
              node.isStart
                ? 'border-blue-500 ring-1 ring-blue-500/20'
                : 'border-slate-200 dark:border-slate-800'
            }`}
          >
            <div>
              {/* Node Card Header */}
              <div className="flex items-start justify-between gap-2 mb-3">
                <div>
                  <div className="flex items-center space-x-1.5 mb-1">
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                      {node.nodeType} node
                    </span>

                    {node.nodeType === 'carousel' && (
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                        🖼️ PHOTO CAROUSEL
                      </span>
                    )}

                    {node.isStart && (
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                        START
                      </span>
                    )}
                  </div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">{node.nodeName}</h3>
                  <span className="text-[11px] font-mono text-slate-400 dark:text-slate-500">#{node.nodeKey}</span>
                </div>

                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => openEditModal(node)}
                    className="p-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg transition cursor-pointer"
                    title="Edit Node"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  {!node.isStart && (
                    <button
                      onClick={() => onDeleteNode(node.id)}
                      className="p-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition cursor-pointer"
                      title="Delete Node"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Bot Message Preview / Inline Editor */}
              {inlineEditingId === node.id ? (
                <div className="bg-blue-50/60 dark:bg-blue-950/30 p-3 rounded-xl border border-blue-300 dark:border-blue-700 mb-3.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-blue-700 dark:text-blue-300 flex items-center gap-1">
                      <Edit3 className="w-3 h-3" /> Quick Edit Greeting / Response:
                    </span>
                    <button
                      type="button"
                      onClick={() => setInlineEditingId(null)}
                      className="text-[10px] text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    >
                      Cancel
                    </button>
                  </div>
                  <textarea
                    rows={4}
                    value={inlineEditText}
                    onChange={(e) => setInlineEditText(e.target.value)}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg p-2.5 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 font-sans"
                    placeholder="Enter message text sent to customer..."
                  />
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setInlineEditingId(null)}
                      className="px-2.5 py-1 text-[11px] font-medium text-slate-600 dark:text-slate-300 rounded hover:bg-slate-200 dark:hover:bg-slate-800"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSaveInlineEdit(node)}
                      className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-[11px] font-semibold transition"
                    >
                      Save Message
                    </button>
                  </div>
                </div>
              ) : (
                <div className={`p-3 rounded-xl border mb-3.5 relative group ${
                  node.isStart 
                    ? 'bg-blue-50/40 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900/60' 
                    : 'bg-slate-50 dark:bg-[#090d16] border-slate-200 dark:border-slate-800'
                }`}>
                  <p className="text-xs text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed line-clamp-4">
                    {node.responseText || 'No message content defined yet.'}
                  </p>
                  <button
                    type="button"
                    onClick={() => handleStartInlineEdit(node)}
                    className="absolute top-2 right-2 opacity-80 group-hover:opacity-100 px-2 py-0.5 rounded text-[10px] font-medium bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-blue-600 dark:text-blue-400 shadow-2xs hover:bg-blue-50 dark:hover:bg-slate-700 transition"
                    title="Quick Edit Text"
                  >
                    Quick Edit
                  </button>
                </div>
              )}

              {/* Input Capture info */}
              {node.nodeType === 'input' && node.inputConfig && (
                <div className="mb-3 p-2.5 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs">
                  <div className="flex items-center space-x-1.5 text-slate-800 dark:text-slate-200 font-semibold mb-1">
                    <FileText className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                    <span>Inquiry Field Capture</span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300">
                    Captures: <strong className="capitalize">{node.inputConfig.fieldToCapture}</strong>
                  </p>
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">
                    Next step on submit: <span className="font-medium text-slate-700 dark:text-slate-300">{getNodeNameById(node.inputConfig.destinationNodeIdOnSuccess)}</span>
                  </p>
                </div>
              )}

              {/* Buttons / Next Step Options */}
              {node.options && node.options.length > 0 && (
                <div className="space-y-1.5 mb-3">
                  <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
                    Quick Reply Buttons ({node.options.length}):
                  </span>
                  <div className="space-y-1">
                    {node.options.map((opt) => (
                      <div
                        key={opt.id}
                        className="flex items-center justify-between text-xs bg-slate-50 dark:bg-slate-800/60 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700"
                      >
                        <span className="font-medium text-slate-800 dark:text-slate-200 truncate max-w-[140px]">
                          {opt.label}
                        </span>
                        <div className="flex items-center space-x-1 text-[11px] text-slate-500 dark:text-slate-400">
                          <ArrowRight className="w-3 h-3 text-slate-400" />
                          <span className="truncate max-w-[110px]">{getNodeNameById(opt.destinationNodeId)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Node Card Actions */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2 flex-wrap">
              {!node.isStart ? (
                <button
                  onClick={() => onSetStartNode(node.id)}
                  className="text-[11px] font-medium text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition flex items-center cursor-pointer"
                >
                  <Check className="w-3 h-3 mr-1" />
                  Set as Start Node
                </button>
              ) : (
                <span className="text-[11px] font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span>
                  Default Greeting Node
                </span>
              )}

              <button
                onClick={() => openEditModal(node)}
                className={`text-xs font-semibold rounded-lg px-3 py-1.5 transition cursor-pointer flex items-center gap-1 ${
                  node.isStart
                    ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-xs font-bold'
                    : 'text-blue-600 dark:text-blue-400 hover:underline'
                }`}
              >
                <Edit3 className="w-3 h-3" />
                {node.isStart ? 'Edit Main Menu Greeting' : 'Configure ➔'}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit / Create Node Modal */}
      {(editingNode || isCreatingNew) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-xl p-6">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-bold text-base text-slate-900 dark:text-slate-100">
                {isCreatingNew ? 'Create New Conversation Node' : `Edit Node: ${editingNode?.nodeName}`}
              </h3>
              <button
                onClick={() => {
                  setEditingNode(null);
                  setIsCreatingNew(false);
                }}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveForm} className="space-y-4 text-xs sm:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Node Name</label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. Course Pricing"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs sm:text-sm"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Unique Node Key</label>
                  <input
                    type="text"
                    required
                    value={formKey}
                    onChange={(e) => setFormKey(e.target.value)}
                    placeholder="e.g. course_pricing"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 font-mono text-xs sm:text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Node Type</label>
                <select
                  value={formType}
                  onChange={(e) => setFormType(e.target.value as NodeType)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs sm:text-sm"
                >
                  <option value="message">Standard Message (Text + Buttons)</option>
                  <option value="carousel">🖼️ Product &amp; Image Carousel (Shows Catalog Photos &amp; Prices)</option>
                  <option value="start">Start / Greeting Node</option>
                  <option value="menu">Menu (Quick replies)</option>
                  <option value="input">Input / Lead Capture Step</option>
                  <option value="agent_handoff">Live Human Agent Escalation</option>
                </select>
                {formType === 'carousel' && (
                  <div className="mt-2 p-2.5 rounded-lg bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-[11px] text-blue-800 dark:text-blue-300">
                    ℹ️ <strong>Carousel Mode Active:</strong> When customers trigger this node, Meta Messenger and the Simulator automatically render an interactive swipeable card carousel featuring the product photos, pricing, descriptions, and 1-click 'Order Now' buttons from your <strong>Products &amp; Services</strong> catalog!
                  </div>
                )}
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                  Automated Messenger Response Text
                </label>
                <textarea
                  rows={4}
                  required
                  value={formText}
                  onChange={(e) => setFormText(e.target.value)}
                  placeholder="The exact message the bot replies with..."
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs sm:text-sm"
                />
              </div>

              {/* Quick Reply Buttons */}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-2 text-xs">
                  Connected Quick Reply Buttons ({formOptions.length})
                </label>

                {formOptions.length > 0 && (
                  <div className="space-y-1.5 mb-3">
                    {formOptions.map((opt) => (
                      <div
                        key={opt.id}
                        className="flex items-center justify-between bg-slate-50 dark:bg-slate-800/80 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs"
                      >
                        <span className="font-semibold text-slate-800 dark:text-slate-200">{opt.label}</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-slate-500 dark:text-slate-400">➔ {getNodeNameById(opt.destinationNodeId)}</span>
                          <button
                            type="button"
                            onClick={() => handleRemoveOptionFromForm(opt.id)}
                            className="text-slate-400 hover:text-red-500 p-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <div className="bg-slate-50 dark:bg-slate-900/60 p-3 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
                  <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block">Add New Button:</span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={newOptLabel}
                      onChange={(e) => setNewOptLabel(e.target.value)}
                      placeholder="Button Label (e.g. View Packages)"
                      className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
                    />
                    <select
                      value={newOptDest}
                      onChange={(e) => setNewOptDest(e.target.value)}
                      className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
                    >
                      <option value="">Select Target Destination Node</option>
                      {nodes.map((target) => (
                        <option key={target.id} value={target.id}>
                          {target.nodeName} ({target.nodeKey})
                        </option>
                      ))}
                    </select>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddOptionToForm}
                    disabled={!newOptLabel.trim()}
                    className="px-3 py-1 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium rounded-md border border-slate-200 dark:border-slate-700 disabled:opacity-40 cursor-pointer"
                  >
                    + Add Button to Node
                  </button>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setEditingNode(null);
                    setIsCreatingNew(false);
                  }}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs cursor-pointer"
                >
                  {isCreatingNew ? 'Create Node' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
