import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  RotateCcw, 
  Menu as MenuIcon, 
  CheckCircle2, 
  Clock, 
  UserCheck, 
  Smartphone, 
  Monitor, 
  Download, 
  Info, 
  Sparkles,
  Sun,
  Moon,
  Bot
} from 'lucide-react';
import { FlowNode, FlowOption, BotSettings, ConversationSession, Lead } from '../types/chatbot';

interface MessengerSimulatorProps {
  session: ConversationSession;
  nodes: FlowNode[];
  settings: BotSettings;
  isOpen: boolean;
  onSendMessage: (text: string, payload?: string) => Promise<void>;
  onResetChat: () => Promise<void>;
  onToggleSimulatedHours?: (forcedOpen: boolean | null) => void;
  forcedHoursState?: boolean | null;
  onSwitchToNode?: (nodeId: string) => void;
  leads: Lead[];
}

export const MessengerSimulator: React.FC<MessengerSimulatorProps> = ({
  session,
  nodes,
  settings,
  isOpen,
  onSendMessage,
  onResetChat,
  onToggleSimulatedHours,
  forcedHoursState,
  leads,
}) => {
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isMobileView, setIsMobileView] = useState(true);
  const [showPersistentMenu, setShowPersistentMenu] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeNode = nodes.find(n => n.id === session.currentNodeId) || nodes[0];
  const lastBotMessage = [...session.messages].reverse().find(m => m.sender === 'bot');

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [session.messages, isTyping]);

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() || isTyping) return;

    const textToSend = inputText;
    setInputText('');
    setIsTyping(true);

    try {
      await onSendMessage(textToSend);
    } finally {
      setTimeout(() => {
        setIsTyping(false);
      }, 350);
    }
  };

  const handleOptionClick = async (option: FlowOption) => {
    if (isTyping) return;
    setIsTyping(true);
    try {
      await onSendMessage(option.label, option.payload || `PAYLOAD_${option.id}`);
    } finally {
      setTimeout(() => {
        setIsTyping(false);
      }, 300);
    }
  };

  const handleIcebreakerClick = async (text: string) => {
    if (isTyping) return;
    setIsTyping(true);
    try {
      await onSendMessage(text);
    } finally {
      setTimeout(() => {
        setIsTyping(false);
      }, 300);
    }
  };

  const exportTranscript = () => {
    const transcript = session.messages
      .map(m => `[${m.timestamp}] ${m.sender.toUpperCase()}: ${m.text}`)
      .join('\n\n');
    const blob = new Blob([transcript], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `messenger-chat-transcript-${session.id}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Top Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 bg-white dark:bg-[#111827] p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600 mr-2"></span>
            Facebook Messenger Interactive Sandbox
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Real customer interaction simulation powered 100% by deterministic decision trees and keyword rules (No AI).
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Day / Night 24/7 Simulator Toggle */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800/80 p-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs">
            <span className="text-slate-500 dark:text-slate-400 px-2 font-medium">Test Time:</span>
            <button
              onClick={() => onToggleSimulatedHours && onToggleSimulatedHours(true)}
              className={`flex items-center px-2.5 py-1 rounded-md transition font-medium cursor-pointer ${
                forcedHoursState === true || (forcedHoursState === null && isOpen)
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
              title="Simulate Normal Business Hours (Live Agent Available)"
            >
              <Sun className="w-3.5 h-3.5 mr-1 text-amber-500" /> Open Hours
            </button>
            <button
              onClick={() => onToggleSimulatedHours && onToggleSimulatedHours(false)}
              className={`flex items-center px-2.5 py-1 rounded-md transition font-medium cursor-pointer ${
                forcedHoursState === false || (forcedHoursState === null && !isOpen)
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
              title="Simulate After-Hours (24/7 Automated Night Bot Responder)"
            >
              <Moon className="w-3.5 h-3.5 mr-1 text-blue-500" /> After-Hours (24/7 Bot)
            </button>
          </div>

          {/* Viewport switch */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800/80 p-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs">
            <button
              onClick={() => setIsMobileView(true)}
              className={`p-1.5 rounded-md transition cursor-pointer ${
                isMobileView ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs' : 'text-slate-500 dark:text-slate-400'
              }`}
              title="Smartphone View"
            >
              <Smartphone className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsMobileView(false)}
              className={`p-1.5 rounded-md transition cursor-pointer ${
                !isMobileView ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs' : 'text-slate-500 dark:text-slate-400'
              }`}
              title="Desktop View"
            >
              <Monitor className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={onResetChat}
            className="flex items-center px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 transition cursor-pointer"
            title="Reset Chat Session"
          >
            <RotateCcw className="w-3.5 h-3.5 mr-1" />
            Reset
          </button>

          <button
            onClick={exportTranscript}
            className="flex items-center px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 transition cursor-pointer"
            title="Download conversation transcript"
          >
            <Download className="w-3.5 h-3.5 mr-1" />
            Transcript
          </button>
        </div>
      </div>

      {/* Tab Purpose & Usage Guide Banner */}
      <div className="mb-6 rounded-xl border-l-4 border-l-blue-600 border border-slate-200 dark:border-slate-800 bg-gradient-to-r from-blue-50/70 via-white to-transparent dark:from-blue-950/20 dark:via-slate-900/40 dark:to-transparent p-5 space-y-3">
        <div className="flex items-start gap-3">
          <span className="text-2xl leading-none">📱</span>
          <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300 w-full">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Tab Purpose & How to Use the Messenger Simulator
              </h3>
              <p className="leading-relaxed mt-0.5">
                <strong>Purpose:</strong> Interactively test your Facebook Page's 24/7 automated decision trees, keyword triggers, and after-hours notices directly in the browser before connecting to Meta. Zero API costs, zero delay.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  1. Test Quick Reply Buttons
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  Click any suggested option pill (e.g. <code>💳 Pricing & Fees</code>, <code>🕒 Business Hours</code>) to verify branching conversation paths.
                </span>
              </div>

              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  2. Test Keyword Triggers
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  Type questions like <em>"how much does it cost?"</em>, <em>"talk to agent"</em>, or <em>"MCLE units"</em> into the chat input. Notice the engine immediately routes to the correct node!
                </span>
              </div>

              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  3. Test Day / Night 24/7 Hours
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  Toggle between <strong>Open Hours</strong> and <strong>After-Hours (24/7 Bot)</strong> in the top bar to verify how the bot informs customers outside office hours.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Simulator + Debug Engine Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Chat Interface Column */}
        <div className={`transition-all duration-300 mx-auto ${
          isMobileView ? 'lg:col-span-7 xl:col-span-6 w-full max-w-[430px]' : 'lg:col-span-8 w-full'
        }`}>
          {/* Mockup Container */}
          <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-3xl shadow-lg overflow-hidden flex flex-col h-[740px]">
            {/* Messenger Header */}
            <div className="bg-blue-600 px-4 py-3.5 text-white flex items-center justify-between shadow-xs">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <div className="w-9 h-9 rounded-full bg-white text-blue-600 font-bold flex items-center justify-center text-xs shadow-xs">
                    {settings.pageName.slice(0, 2).toUpperCase()}
                  </div>
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-400 border-2 border-blue-600 rounded-full"></span>
                </div>
                <div>
                  <div className="flex items-center space-x-1">
                    <h3 className="font-semibold text-sm leading-tight text-white">{settings.pageName}</h3>
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-200 fill-blue-500 inline" />
                  </div>
                  <p className="text-[11px] text-blue-100 flex items-center space-x-1">
                    <Clock className="w-3 h-3 inline mr-0.5" />
                    <span>Replies instantly · 24/7 Automated</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                {session.status === 'human_takeover' ? (
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-white/20 text-white">
                    Human Agent
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-white/20 text-white">
                    24/7 Bot Active
                  </span>
                )}
              </div>
            </div>

            {/* Conversation Messages Scroll Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-50 dark:bg-[#090d16] scrollbar-thin">
              {/* Business Page Greeting Card */}
              <div className="text-center py-2.5 px-4 my-1 bg-white dark:bg-[#111827] rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
                <p className="text-xs font-semibold text-slate-900 dark:text-slate-100">{settings.pageName}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  Facebook Business Page · Automated Customer Support Portal
                </p>
                <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">
                  Instant responses 24/7 via decision tree and verified FAQ rules.
                </p>
              </div>

              {/* Icebreaker Questions (Shown at beginning) */}
              {session.messages.length <= 1 && (
                <div className="space-y-1.5 pt-2">
                  <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400 text-center uppercase tracking-wider">
                    Frequently Asked Questions
                  </p>
                  <div className="grid grid-cols-1 gap-1.5">
                    {settings.icebreakers.map((ib, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleIcebreakerClick(ib)}
                        className="text-left text-xs bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700/80 text-slate-700 dark:text-slate-200 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 transition flex items-center justify-between shadow-xs cursor-pointer"
                      >
                        <span>{ib}</span>
                        <span className="text-slate-400 text-xs">➔</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Message Bubbles */}
              {session.messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div className="flex items-end gap-2 max-w-[85%]">
                    {msg.sender !== 'user' && (
                      <div className="w-6 h-6 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex-shrink-0 flex items-center justify-center text-[10px] font-bold">
                        {msg.sender === 'agent' ? '👤' : '🤖'}
                      </div>
                    )}
                    <div
                      className={`rounded-2xl px-3.5 py-2.5 text-xs sm:text-sm whitespace-pre-wrap leading-relaxed shadow-xs ${
                        msg.sender === 'user'
                          ? 'bg-blue-600 text-white rounded-br-none'
                          : msg.sender === 'agent'
                          ? 'bg-slate-800 dark:bg-slate-700 text-white rounded-bl-none'
                          : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-bl-none border border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {msg.text}
                    </div>
                  </div>

                  {/* Carousel Cards (e.g. Products / Offerings) */}
                  {msg.carouselCards && msg.carouselCards.length > 0 && (
                    <div className="w-full flex space-x-2.5 overflow-x-auto pb-2 pt-2.5 scrollbar-thin max-w-full pl-8">
                      {msg.carouselCards.map((card) => (
                        <div
                          key={card.id}
                          className="w-52 shrink-0 bg-white dark:bg-slate-850 dark:bg-slate-800 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-xs flex flex-col"
                        >
                          {card.imageUrl ? (
                            <img
                              src={card.imageUrl}
                              alt={card.title}
                              className="w-full h-24 object-cover"
                            />
                          ) : (
                            <div className="w-full h-20 bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-400 text-xs">
                              🛍 Product Item
                            </div>
                          )}
                          <div className="p-2.5 flex-1 flex flex-col justify-between">
                            <div>
                              <h5 className="font-bold text-xs text-slate-900 dark:text-slate-100 line-clamp-1">
                                {card.title}
                              </h5>
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-0.5">
                                {card.subtitle}
                              </p>
                            </div>
                            <div className="mt-2 space-y-1 pt-2 border-t border-slate-100 dark:border-slate-700/60">
                              {card.buttons.map((btn, bIdx) => (
                                <button
                                  key={bIdx}
                                  type="button"
                                  onClick={() =>
                                    onSendMessage(
                                      btn.label,
                                      btn.payload ||
                                        (btn.destinationNodeId
                                          ? `PAYLOAD_${btn.destinationNodeId}`
                                          : `PAYLOAD_CARD_${card.id}`)
                                    )
                                  }
                                  className="w-full py-1.5 px-2 rounded-lg bg-blue-50 dark:bg-blue-900/40 hover:bg-blue-600 hover:text-white dark:hover:bg-blue-600 text-blue-700 dark:text-blue-300 text-[11px] font-semibold text-center transition cursor-pointer"
                                >
                                  {btn.label}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  <span className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 px-1">
                    {msg.timestamp}
                    {msg.matchedTrigger && (
                      <span className="ml-1 text-slate-500 dark:text-slate-400">· {msg.matchedTrigger}</span>
                    )}
                  </span>
                </div>
              ))}

              {/* Typing Indicator */}
              {isTyping && (
                <div className="flex items-center space-x-2 text-slate-400">
                  <div className="w-6 h-6 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center text-[10px]">
                    🤖
                  </div>
                  <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 py-2 rounded-2xl rounded-bl-none flex items-center space-x-1.5 shadow-xs">
                    <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce"></span>
                    <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                    <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                  </div>
                </div>
              )}

              {/* Quick Reply Pills */}
              {!isTyping && lastBotMessage?.options && lastBotMessage.options.length > 0 && (
                <div className="pt-2">
                  <div className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-semibold tracking-wider mb-1.5 ml-1">
                    Suggested Options:
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {lastBotMessage.options.map((opt) => (
                      <button
                        key={opt.id}
                        onClick={() => handleOptionClick(opt)}
                        className="text-xs px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-blue-600 hover:text-white dark:hover:bg-blue-600 text-slate-700 dark:text-slate-200 rounded-full border border-slate-200 dark:border-slate-700 transition shadow-xs font-medium cursor-pointer"
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Persistent Menu Drawer */}
            {showPersistentMenu && (
              <div className="bg-white dark:bg-[#111827] border-t border-slate-200 dark:border-slate-800 p-3 space-y-1.5 text-xs">
                <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 pb-1 border-b border-slate-100 dark:border-slate-800">
                  <span className="font-semibold text-[11px] uppercase tracking-wider">Persistent Menu</span>
                  <button onClick={() => setShowPersistentMenu(false)} className="text-slate-400 hover:text-slate-700 dark:hover:text-white cursor-pointer">✕</button>
                </div>
                {settings.persistentMenuItems.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setShowPersistentMenu(false);
                      if (item.destinationNodeId) {
                        const target = nodes.find(n => n.id === item.destinationNodeId);
                        if (target) onSendMessage(item.label, `PAYLOAD_${item.destinationNodeId}`);
                      }
                    }}
                    className="w-full text-left px-3 py-1.5 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition flex items-center justify-between cursor-pointer"
                  >
                    <span>{item.label}</span>
                    <span className="text-slate-400 text-xs">➔</span>
                  </button>
                ))}
              </div>
            )}

            {/* Input Bar */}
            <form onSubmit={handleSend} className="p-3 bg-white dark:bg-[#111827] border-t border-slate-200 dark:border-slate-800 flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowPersistentMenu(!showPersistentMenu)}
                className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition cursor-pointer"
                title="Open Persistent Hamburger Menu"
              >
                <MenuIcon className="w-5 h-5" />
              </button>

              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Type a message or question..."
                className="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 placeholder-slate-400 text-xs sm:text-sm px-3.5 py-2.5 rounded-full border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-blue-500"
              />

              <button
                type="submit"
                disabled={!inputText.trim() || isTyping}
                className="p-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white rounded-full transition shadow-xs flex-shrink-0 cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>

        {/* Live Rule Execution Inspector Sidebar */}
        <div className={`transition-all duration-300 ${
          isMobileView ? 'lg:col-span-5 xl:col-span-6' : 'lg:col-span-4'
        } space-y-4`}>
          {/* Active Flow Node Inspector */}
          <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center space-x-2">
                <Bot className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <h4 className="font-semibold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Execution State Inspector
                </h4>
              </div>
              <span className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded font-mono border border-slate-200 dark:border-slate-700">
                {activeNode.nodeType.toUpperCase()}
              </span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div>
                <span className="text-slate-500 dark:text-slate-400 block text-[11px]">Active Node:</span>
                <span className="font-bold text-slate-900 dark:text-slate-100 text-sm">{activeNode.nodeName}</span>
                <span className="text-slate-400 dark:text-slate-500 block font-mono text-[11px]">#{activeNode.nodeKey}</span>
              </div>

              <div>
                <span className="text-slate-500 dark:text-slate-400 block text-[11px]">Status:</span>
                {session.status === 'human_takeover' ? (
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">
                    <UserCheck className="w-3.5 h-3.5 mr-1 text-amber-500" /> Human Agent Escalation
                  </span>
                ) : (
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">
                    <Sparkles className="w-3.5 h-3.5 mr-1 text-blue-500" /> 24/7 Automated Decision Tree
                  </span>
                )}
              </div>

              {/* Data Collected */}
              {Object.keys(session.collectedData).length > 0 && (
                <div className="bg-slate-50 dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-slate-700 dark:text-slate-300 block text-[11px] font-semibold mb-1">
                    Captured Inquirer Data:
                  </span>
                  <div className="space-y-1 text-[11px]">
                    {Object.entries(session.collectedData).map(([k, v]) => (
                      <div key={k} className="flex justify-between">
                        <span className="text-slate-500 dark:text-slate-400 capitalize">{k}:</span>
                        <span className="text-slate-800 dark:text-slate-200 font-medium font-mono">{v}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Quick suggestions to test */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 dark:text-slate-400 block text-[11px] font-semibold mb-1.5">
                  Try Typing These Inquiries:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {['pricing', 'office hours', 'human agent', 'register', 'where are you located'].map((q, idx) => (
                    <button
                      key={idx}
                      onClick={() => onSendMessage(q)}
                      className="px-2 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-[11px] rounded border border-slate-200 dark:border-slate-700 transition cursor-pointer"
                    >
                      "{q}"
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Production & 24/7 Architecture Note */}
          <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs text-xs">
            <h4 className="font-semibold text-xs uppercase tracking-wider text-slate-800 dark:text-slate-200 mb-2 flex items-center">
              <Info className="w-3.5 h-3.5 mr-1.5 text-blue-600 dark:text-blue-400" />
              Production Single-Host Architecture
            </h4>
            <ul className="space-y-2 text-slate-600 dark:text-slate-400 leading-relaxed">
              <li className="flex items-start gap-2">
                <span className="text-blue-600 dark:text-blue-400 font-bold">✓</span>
                <span><strong>No AI Dependencies:</strong> Runs entirely on standard PHP 7.4 - 8.3 with PDO MySQL. Zero external AI API keys or tokens required.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 dark:text-blue-400 font-bold">✓</span>
                <span><strong>Clean CSS & JS:</strong> Includes standalone <code className="text-slate-800 dark:text-slate-200 font-mono">app.css</code> and <code className="text-slate-800 dark:text-slate-200 font-mono">admin.js</code> with dark/light mode toggle.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 dark:text-blue-400 font-bold">✓</span>
                <span><strong>Official Meta Format:</strong> Generates standard Graph Send API cURL payloads compatible with Meta Messenger business rules.</span>
              </li>
            </ul>
          </div>

          {/* Recent Leads Preview */}
          {leads.length > 0 && (
            <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs text-xs">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-slate-800 dark:text-slate-200">Latest Captured Inquiry</h4>
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 uppercase">
                  {leads[0].status}
                </span>
              </div>
              <p className="font-semibold text-slate-900 dark:text-slate-100">{leads[0].fullName}</p>
              <p className="text-slate-500 dark:text-slate-400 text-[11px]">{leads[0].email || 'No email'} · {leads[0].phone || 'No phone'}</p>
              <p className="text-slate-600 dark:text-slate-400 italic text-[11px] mt-1 line-clamp-2">"{leads[0].inquiry}"</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
