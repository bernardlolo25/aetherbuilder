import React, { useState } from 'react';
import { 
  GitBranch, 
  RefreshCw, 
  CheckCircle2, 
  AlertTriangle, 
  Download, 
  ShieldCheck, 
  Zap, 
  Sparkles,
  Lock,
  RotateCcw
} from 'lucide-react';

export const SystemUpdates: React.FC = () => {
  const [currentVersion, setCurrentVersion] = useState('1.5.7');
  const [isChecking, setIsChecking] = useState(false);
  const [simulatedUpdateAvailable, setSimulatedUpdateAvailable] = useState(false);
  const [simulatedVersion, setSimulatedVersion] = useState('1.5.8');
  const [isUpdating, setIsUpdating] = useState(false);
  const [updateStep, setUpdateStep] = useState(0);
  const [updateSuccess, setUpdateSuccess] = useState(false);

  const changelog = [
    'Added Products & Services Catalog management with pricing, SKUs, and stock availability',
    'HTML5 live camera capture with lens switcher and automatic image compression',
    'Instant Flow Prompt Builder integration: seamlessly connect catalog items to AI prompts',
    'Dedicated 1-Click Launchers for ChatGPT, DeepSeek, Claude, and Google AI Studio',
    'Protected configuration vault shielding database passwords and verify tokens from overwrite'
  ];

  const handleCheckNow = () => {
    setIsChecking(true);
    setTimeout(() => {
      setIsChecking(false);
    }, 800);
  };

  const handleSimulateUpdate = () => {
    setIsUpdating(true);
    setUpdateStep(1);

    setTimeout(() => {
      setUpdateStep(2);
    }, 900);

    setTimeout(() => {
      setUpdateStep(3);
    }, 1800);

    setTimeout(() => {
      setUpdateStep(4);
      setUpdateSuccess(true);
    }, 2700);

    setTimeout(() => {
      setIsUpdating(false);
      setCurrentVersion(simulatedVersion);
      setSimulatedUpdateAvailable(false);
    }, 4200);
  };

  const handleResetDemo = () => {
    setCurrentVersion('1.2.0');
    setSimulatedVersion('1.3.0');
    setSimulatedUpdateAvailable(true);
    setUpdateSuccess(false);
    setUpdateStep(0);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-700 dark:bg-blue-900/60 dark:text-blue-300">
              Automated Lifecycle Engine
            </span>
            <span className="text-xs text-slate-400 dark:text-slate-500">•</span>
            <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
              v{currentVersion}
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
            System Updates & Versioning
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Keep your Facebook Messenger Bot always up-to-date with 1-click cloud updates, zero database data loss, and automatic dashboard reload.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleCheckNow}
            disabled={isChecking}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition shadow-xs cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin text-blue-600' : ''}`} />
            {isChecking ? 'Checking for Updates...' : 'Check for Updates'}
          </button>

          <a
            href="/messenger_infinityfree_ready.zip"
            download="messenger_bot_production_ready.zip"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white transition shadow-xs cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Download Production ZIP
          </a>
        </div>
      </div>

      {/* Tab Purpose & Usage Guide */}
      <div className="rounded-xl border-l-4 border-l-blue-600 border border-slate-200 dark:border-slate-800 bg-gradient-to-r from-blue-50/70 via-white to-transparent dark:from-blue-950/20 dark:via-slate-900/40 dark:to-transparent p-5 space-y-3">
        <div className="flex items-start gap-3">
          <span className="text-2xl leading-none">🚀</span>
          <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Tab Purpose & How to Use System Updates
            </h3>
            <p className="leading-relaxed">
              <strong>Purpose:</strong> Maintain your production chatbot with seamless, zero-downtime version upgrades. Whenever new enhancements, security patches, or Meta API updates are published, this engine pulls the new code, extracts updated assets, preserves your database and configuration passwords, and refreshes the browser automatically.
            </p>
            <div className="pt-1">
              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-0.5">How Updates Work:</span>
                <span className="text-slate-500 dark:text-slate-400">Click <strong>Check for Updates</strong> at any time. If a newer build exists, the amber alert banner appears. Click <strong>Install Update Now</strong> to download and auto-refresh the browser.</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Live Notification Preview Banner */}
      {simulatedUpdateAvailable && (
        <div className="relative overflow-hidden rounded-xl border border-amber-300 dark:border-amber-500/40 bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent p-5 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start sm:items-center gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0 text-xl font-bold">
                🚀
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 dark:text-white text-base">
                    Important Update Available: Version {simulatedVersion}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500/20 text-amber-700 dark:text-amber-300">
                    New Release Ready
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                  Your dashboard is on <code>v{currentVersion}</code>. Upgrading will install the latest features and automatically refresh your dashboard.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <button
                onClick={handleSimulateUpdate}
                disabled={isUpdating}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-600 text-slate-950 transition shadow-sm cursor-pointer disabled:opacity-50"
              >
                <Zap className="w-3.5 h-3.5 fill-current" />
                {isUpdating ? 'Installing Update...' : 'Install Update Now (Test Mode)'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Post-update banner if successfully updated */}
      {updateSuccess && !simulatedUpdateAvailable && (
        <div className="rounded-xl border border-emerald-300 dark:border-emerald-500/40 bg-emerald-50 dark:bg-emerald-950/20 p-5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
            <div>
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                Dashboard Successfully Updated to v{currentVersion}!
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                All system files refreshed from release package. Configuration and database records were completely protected.
              </p>
            </div>
          </div>

          <button
            onClick={handleResetDemo}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Simulator
          </button>
        </div>
      )}

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 shadow-xs">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Current Installed Version</div>
          <div className="text-xl font-bold text-slate-900 dark:text-white mt-1 flex items-baseline gap-2">
            <span>v{currentVersion}</span>
            <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300">
              Active
            </span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Single-Host PHP 8.x</div>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 shadow-xs">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Latest Available Release</div>
          <div className="text-xl font-bold text-slate-900 dark:text-white mt-1 flex items-baseline gap-2">
            <span>v{simulatedVersion}</span>
            {simulatedUpdateAvailable ? (
              <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300">
                Ready to Deploy
              </span>
            ) : (
              <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300">
                Synced ✓
              </span>
            )}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Production Stable</div>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 shadow-xs">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Update Mode</div>
          <div className="text-base font-bold text-slate-900 dark:text-white mt-1 truncate">
            1-Click Zero Downtime
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Automatic browser reload</div>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 shadow-xs">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Safety Shield</div>
          <div className="text-base font-bold text-emerald-600 dark:text-emerald-400 mt-1 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4" /> Locked Vault
          </div>
          <div className="text-[11px] text-slate-400 mt-1">DB Passwords Protected</div>
        </div>
      </div>

      {/* Two Column Layout: Changelog & Architecture */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: What's New & Release Highlights */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-500" />
                What's New in Version {simulatedVersion}
              </h3>
              <span className="text-xs font-mono text-slate-400">Release: 2026-11-03</span>
            </div>

            <div className="space-y-2.5">
              {changelog.map((item, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-600 dark:text-slate-300">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-blue-400 mt-1.5 shrink-0" />
                  <span>{item}</span>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-700/80 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1">
                <Lock className="w-3.5 h-3.5 text-emerald-500" />
                Zero config overwrite guarantee
              </span>
              <span>Refreshes browser automatically</span>
            </div>
          </div>

          {/* How the Auto-Updater Works */}
          <div className="p-6 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 shadow-xs space-y-4">
            <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-blue-600" />
              How the Automated Update Pipeline Operates
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-3.5 rounded-lg bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700/60 space-y-1.5">
                <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px]">1</span>
                  Publish Release
                </div>
                <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                  When a new release package is published to the release stream, <code>version.json</code> is automatically detected.
                </p>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700/60 space-y-1.5">
                <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px]">2</span>
                  Admin Notification
                </div>
                <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                  The dashboard checks the secure release mirror and displays the amber alert banner with the "Install Update" button.
                </p>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700/60 space-y-1.5">
                <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px]">3</span>
                  Extract & Auto-Reload
                </div>
                <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                  Clicking "Install Update" extracts the updated files, strictly preserves your database credentials, and reloads the dashboard!
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Update Stream Status & Quick Actions */}
        <div className="space-y-6">
          <div className="p-6 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 shadow-xs space-y-4">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              Verified Release Stream
            </h3>

            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Updates are managed from the developer's release distribution channel. Client installations receive verified builds with cryptographic checksum validation.
            </p>

            <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500 dark:text-slate-400">Channel:</span>
                <span className="font-bold text-blue-600 dark:text-blue-400">Production Stable</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 dark:text-slate-400">Auto-Refresh:</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-semibold">Enabled</span>
              </div>
            </div>

            <button
              onClick={handleCheckNow}
              disabled={isChecking}
              className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white transition shadow-xs cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin' : ''}`} />
              <span>Check for Updates Now</span>
            </button>
          </div>

          {/* Files Updated by the Engine */}
          <div className="p-6 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/80 shadow-xs space-y-3 text-xs">
            <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider">
              Installed Updater Files
            </h4>
            <div className="font-mono text-[11px] text-slate-600 dark:text-slate-400 space-y-1">
              <div>✓ <code>version.json</code> (Version tracking)</div>
              <div>✓ <code>includes/updater.php</code> (Release engine)</div>
              <div>✓ <code>admin/updates.php</code> (Update manager UI)</div>
              <div>✓ <code>admin/updater-api.php</code> (1-Click upgrade API)</div>
              <div>✓ <code>includes/header.php</code> (Global alert banner)</div>
            </div>
          </div>
        </div>
      </div>

      {/* Simulation Modal (Active during test update) */}
      {isUpdating && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                <RefreshCw className="w-5 h-5 animate-spin" />
              </div>
              <div>
                <h4 className="font-bold text-base text-slate-900 dark:text-white">
                  Upgrading to Version {simulatedVersion}...
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Downloading release package from update mirror
                </p>
              </div>
            </div>

            {/* Progress bar */}
            <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-blue-600 transition-all duration-500 rounded-full"
                style={{ width: `${(updateStep / 4) * 100}%` }}
              />
            </div>

            {/* Step statuses */}
            <div className="space-y-2 text-xs">
              <div className={`flex items-center gap-2 ${updateStep >= 1 ? 'text-slate-800 dark:text-slate-200 font-medium' : 'text-slate-400'}`}>
                {updateStep > 1 ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : <div className="w-4 h-4 rounded-full border-2 border-blue-600 border-t-transparent animate-spin" />}
                <span>Verifying release package signature & hash</span>
              </div>
              <div className={`flex items-center gap-2 ${updateStep >= 2 ? 'text-slate-800 dark:text-slate-200 font-medium' : 'text-slate-400'}`}>
                {updateStep > 2 ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : updateStep === 2 ? <div className="w-4 h-4 rounded-full border-2 border-blue-600 border-t-transparent animate-spin" /> : <div className="w-4 h-4" />}
                <span>Safeguarding database credentials (config/config.php)</span>
              </div>
              <div className={`flex items-center gap-2 ${updateStep >= 3 ? 'text-slate-800 dark:text-slate-200 font-medium' : 'text-slate-400'}`}>
                {updateStep > 3 ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : updateStep === 3 ? <div className="w-4 h-4 rounded-full border-2 border-blue-600 border-t-transparent animate-spin" /> : <div className="w-4 h-4" />}
                <span>Extracting updated application files & clearing cache</span>
              </div>
              <div className={`flex items-center gap-2 ${updateStep >= 4 ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-slate-400'}`}>
                {updateStep >= 4 ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : <div className="w-4 h-4" />}
                <span>Update complete! Auto-refreshing dashboard...</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
