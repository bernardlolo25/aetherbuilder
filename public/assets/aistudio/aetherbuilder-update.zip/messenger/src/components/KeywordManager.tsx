import React, { useState } from 'react';
import { 
  Key, 
  Plus, 
  Trash2, 
  Edit2, 
  Search, 
  Sparkles, 
  CheckCircle, 
  AlertCircle, 
  ArrowRight
} from 'lucide-react';
import { KeywordTrigger, FlowNode, KeywordMatchType } from '../types/chatbot';
import { evaluateKeywordMatch } from '../services/ruleEngine';

interface KeywordManagerProps {
  keywords: KeywordTrigger[];
  nodes: FlowNode[];
  onAddKeyword: (kw: Partial<KeywordTrigger>) => Promise<void>;
  onUpdateKeyword: (id: string, kw: Partial<KeywordTrigger>) => Promise<void>;
  onDeleteKeyword: (id: string) => Promise<void>;
}

export const KeywordManager: React.FC<KeywordManagerProps> = ({
  keywords,
  nodes,
  onAddKeyword,
  onUpdateKeyword,
  onDeleteKeyword,
}) => {
  const [testQuery, setTestQuery] = useState('how much does it cost?');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [formKeyword, setFormKeyword] = useState('');
  const [formMatchType, setFormMatchType] = useState<KeywordMatchType>('contains');
  const [formPriority, setFormPriority] = useState<number>(80);
  const [formDestNode, setFormDestNode] = useState<string>(nodes[0]?.id || '');
  const [formCategory, setFormCategory] = useState<KeywordTrigger['category']>('general');
  const [formNotes, setFormNotes] = useState('');

  const sortedKeywords = [...keywords].sort((a, b) => b.priority - a.priority);
  let matchedTrigger: KeywordTrigger | null = null;
  let matchedKeywordText = '';

  for (const kw of sortedKeywords) {
    const res = evaluateKeywordMatch(testQuery, kw);
    if (res.matched) {
      matchedTrigger = kw;
      matchedKeywordText = res.matchedKeyword;
      break;
    }
  }

  const openAddModal = () => {
    setEditingId(null);
    setFormKeyword('');
    setFormMatchType('contains');
    setFormPriority(80);
    setFormDestNode(nodes[0]?.id || '');
    setFormCategory('general');
    setFormNotes('');
    setIsModalOpen(true);
  };

  const openEditModal = (kw: KeywordTrigger) => {
    setEditingId(kw.id);
    setFormKeyword(kw.keyword);
    setFormMatchType(kw.matchType);
    setFormPriority(kw.priority);
    setFormDestNode(kw.destinationNodeId);
    setFormCategory(kw.category);
    setFormNotes(kw.notes || '');
    setIsModalOpen(true);
  };

  const handleSaveForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formKeyword.trim()) return;

    if (editingId) {
      await onUpdateKeyword(editingId, {
        keyword: formKeyword.trim(),
        matchType: formMatchType,
        priority: Number(formPriority),
        destinationNodeId: formDestNode,
        category: formCategory,
        notes: formNotes,
      });
    } else {
      await onAddKeyword({
        keyword: formKeyword.trim(),
        matchType: formMatchType,
        priority: Number(formPriority),
        destinationNodeId: formDestNode,
        category: formCategory,
        notes: formNotes,
        isEnabled: true,
      });
    }
    setIsModalOpen(false);
  };

  const getNodeNameById = (id: string) => {
    const found = nodes.find(n => n.id === id);
    return found ? found.nodeName : 'No node assigned';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 bg-white dark:bg-[#111827] p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">Keyword & Automated Triggers Engine</h2>
            <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
              {keywords.length} Triggers Active
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Rule-based trigger matching (100% Non-AI). Evaluates exact phrases, substring matches, and keyword jumps.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="inline-flex items-center px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5 mr-1" />
          Add Trigger Rule
        </button>
      </div>

      {/* Tab Purpose & Usage Guide Banner */}
      <div className="mb-6 rounded-xl border-l-4 border-l-amber-500 border border-slate-200 dark:border-slate-800 bg-gradient-to-r from-amber-50/70 via-white to-transparent dark:from-amber-950/20 dark:via-slate-900/40 dark:to-transparent p-5 space-y-3">
        <div className="flex items-start gap-3">
          <span className="text-2xl leading-none">🔑</span>
          <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300 w-full">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Tab Purpose & How to Use Keyword Triggers
              </h3>
              <p className="leading-relaxed mt-0.5">
                <strong>Purpose:</strong> Automatically intercept freeform customer messages sent to your Facebook Page without forcing users to navigate buttons. When a customer types a message, the rule engine checks for matching keywords according to priority and immediately delivers the target answer node.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  1. Contains (Substring Matching)
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  <strong>What to enter:</strong> <code>price, fee, cost, rates, tuition</code><br />
                  <strong>Target Node:</strong> <code>Pricing & Service Packages</code><br />
                  <strong>Trigger Example:</strong> Customer asks <em>"How much are the seminar fees?"</em> — matches <code>fee</code> and answers instantly!
                </span>
              </div>

              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  2. Support & Agent Escalation
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  <strong>What to enter:</strong> <code>agent, human, staff, operator, talk to someone</code><br />
                  <strong>Target Node:</strong> <code>Human Agent Escalation</code><br />
                  <strong>Trigger Example:</strong> Customer types <em>"I need to speak to staff"</em> — alerts your desk and pauses the automated bot.
                </span>
              </div>

              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  3. Topic Inquiries & Menu Reset
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  <strong>What to enter:</strong> <code>mcle, compliance, certificate, credits</code> or <code>menu, restart, start</code><br />
                  <strong>Target Node:</strong> <code>MCLE Compliance Info</code> or <code>Main Menu (#start)</code><br />
                  <strong>Trigger Example:</strong> Resets user back to main options anytime.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Live Sandbox / Interactive Rule Tester */}
      <div className="mb-6 bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
              Rule Engine Sandbox Tester
            </h3>
          </div>
          <span className="text-[11px] text-slate-500 dark:text-slate-400">Type any customer question to see which trigger fires</span>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 items-center">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={testQuery}
              onChange={(e) => setTestQuery(e.target.value)}
              placeholder="e.g. Can I get the price list?"
              className="w-full bg-slate-50 dark:bg-[#090d16] border border-slate-200 dark:border-slate-700 rounded-xl pl-9 pr-4 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex-shrink-0 w-full sm:w-auto">
            {matchedTrigger ? (
              <div className="flex items-center space-x-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 py-2 rounded-xl text-xs text-slate-800 dark:text-slate-200">
                <CheckCircle className="w-4 h-4 text-blue-600 dark:text-blue-400 flex-shrink-0" />
                <div>
                  <span className="font-semibold">Rule Match:</span> "{matchedKeywordText}" (Priority {matchedTrigger.priority})
                  <span className="block text-[11px] text-slate-500 dark:text-slate-400">
                    ➔ Routes to: <strong className="text-slate-800 dark:text-slate-200">{getNodeNameById(matchedTrigger.destinationNodeId)}</strong>
                  </span>
                </div>
              </div>
            ) : (
              <div className="flex items-center space-x-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 py-2 rounded-xl text-xs text-slate-600 dark:text-slate-400">
                <AlertCircle className="w-4 h-4 text-slate-400 flex-shrink-0" />
                <div>
                  <span className="font-semibold">No keyword match.</span>
                  <span className="block text-[11px] text-slate-500 dark:text-slate-400">Routes to Default Fallback Response</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Keywords Table */}
      <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-4">Priority</th>
                <th className="py-3 px-4">Trigger Phrases</th>
                <th className="py-3 px-4">Match Mode</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Destination Flow Node</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {sortedKeywords.map((kw) => (
                <tr key={kw.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                  <td className="py-3 px-4 font-mono font-bold text-blue-600 dark:text-blue-400">
                    {kw.priority}
                  </td>

                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-900 dark:text-slate-100">{kw.keyword}</div>
                    {kw.notes && <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">{kw.notes}</div>}
                  </td>

                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                      {kw.matchType}
                    </span>
                  </td>

                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-medium uppercase bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                      {kw.category}
                    </span>
                  </td>

                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-1 font-medium text-slate-800 dark:text-slate-200">
                      <ArrowRight className="w-3 h-3 text-slate-400" />
                      <span>{getNodeNameById(kw.destinationNodeId)}</span>
                    </div>
                  </td>

                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <button
                        onClick={() => openEditModal(kw)}
                        className="p-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg transition cursor-pointer"
                        title="Edit Trigger"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteKeyword(kw.id)}
                        className="p-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 hover:text-red-500 rounded-lg transition cursor-pointer"
                        title="Delete Trigger"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal for Add / Edit */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-xl p-6">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-bold text-base text-slate-900 dark:text-slate-100">
                {editingId ? 'Edit Keyword Trigger' : 'Add New Keyword Trigger'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer">✕</button>
            </div>

            <form onSubmit={handleSaveForm} className="space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                  Keywords / Phrases (Comma-separated)
                </label>
                <input
                  type="text"
                  required
                  value={formKeyword}
                  onChange={(e) => setFormKeyword(e.target.value)}
                  placeholder="e.g. cost, pricing, how much, fee"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs sm:text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Match Mode</label>
                  <select
                    value={formMatchType}
                    onChange={(e) => setFormMatchType(e.target.value as KeywordMatchType)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs"
                  >
                    <option value="contains">Contains (Phrase / Substring)</option>
                    <option value="exact">Exact Match</option>
                    <option value="starts_with">Starts With</option>
                    <option value="regex">Regular Expression (Regex)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Priority (Higher runs first)</label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={formPriority}
                    onChange={(e) => setFormPriority(Number(e.target.value))}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 font-mono text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Destination Flow Node</label>
                  <select
                    value={formDestNode}
                    onChange={(e) => setFormDestNode(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs"
                  >
                    {nodes.map((n) => (
                      <option key={n.id} value={n.id}>
                        {n.nodeName} ({n.nodeKey})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Category</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as KeywordTrigger['category'])}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs"
                  >
                    <option value="general">General</option>
                    <option value="pricing">Pricing & Fees</option>
                    <option value="hours">Hours & Office</option>
                    <option value="support">Agent & Support</option>
                    <option value="leads">Lead Inquiries</option>
                    <option value="custom">Custom</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Description / Internal Notes</label>
                <input
                  type="text"
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="e.g. Triggers pricing overview"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs cursor-pointer"
                >
                  Save Trigger Rule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
