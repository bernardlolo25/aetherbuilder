import React, { useState } from 'react';
import { 
  Package, 
  Plus, 
  Search, 
  Camera, 
  Trash2, 
  Edit3, 
  Sparkles, 
  Check, 
  ExternalLink, 
  DollarSign, 
  Tag, 
  Copy, 
  CheckSquare, 
  Square, 
  Image as ImageIcon,
  RotateCcw,
  Upload,
  ArrowRight
} from 'lucide-react';
import { ProductItem } from '../types/chatbot';
import { CameraCaptureModal } from './CameraCaptureModal';

interface ProductsManagerProps {
  products: ProductItem[];
  onAddProduct: (product: Omit<ProductItem, 'id' | 'createdAt'>) => void;
  onUpdateProduct: (id: string, product: Partial<ProductItem>) => void;
  onDeleteProduct: (id: string) => void;
  onSeedSampleProducts?: () => void;
  onOpenAIPromptBuilderWithProducts?: (selectedProductIds: string[]) => void;
}

export const ProductsManager: React.FC<ProductsManagerProps> = ({
  products,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onSeedSampleProducts,
  onOpenAIPromptBuilderWithProducts,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<ProductItem | null>(null);

  // Selection for AI Flow Builder
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>(() =>
    products.map((p) => p.id)
  );

  // Form State
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState('');
  const [formPrice, setFormPrice] = useState<number>(49);
  const [formCurrency, setFormCurrency] = useState('USD');
  const [formDescription, setFormDescription] = useState('');
  const [formSku, setFormSku] = useState('');
  const [formStockStatus, setFormStockStatus] = useState<ProductItem['stockStatus']>('available');
  const [formImageUrl, setFormImageUrl] = useState('');
  const [formFeatures, setFormFeatures] = useState<string[]>(['']);
  const [formActionLabel, setFormActionLabel] = useState('Order Now');
  const [formActionType, setFormActionType] = useState<ProductItem['actionType']>('node_handoff');

  // Categories list
  const categories = ['all', ...Array.from(new Set(products.map((p) => p.category).filter(Boolean)))];

  const filteredProducts = products.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.sku && p.sku.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const openAddModal = () => {
    setEditingProduct(null);
    setFormName('');
    setFormCategory('Services');
    setFormPrice(49);
    setFormCurrency('USD');
    setFormDescription('');
    setFormSku(`PROD-${Math.floor(1000 + Math.random() * 9000)}`);
    setFormStockStatus('available');
    setFormImageUrl('');
    setFormFeatures(['']);
    setFormActionLabel('Order Now');
    setFormActionType('node_handoff');
    setIsModalOpen(true);
  };

  const openEditModal = (product: ProductItem) => {
    setEditingProduct(product);
    setFormName(product.name);
    setFormCategory(product.category);
    setFormPrice(product.price);
    setFormCurrency(product.currency || 'USD');
    setFormDescription(product.description);
    setFormSku(product.sku || '');
    setFormStockStatus(product.stockStatus || 'available');
    setFormImageUrl(product.imageUrl || '');
    setFormFeatures(product.features && product.features.length > 0 ? product.features : ['']);
    setFormActionLabel(product.actionButtonLabel || 'Order Now');
    setFormActionType(product.actionType || 'node_handoff');
    setIsModalOpen(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    const cleanedFeatures = formFeatures.map((f) => f.trim()).filter(Boolean);

    if (editingProduct) {
      onUpdateProduct(editingProduct.id, {
        name: formName.trim(),
        category: formCategory.trim() || 'General',
        price: Number(formPrice) || 0,
        currency: formCurrency,
        description: formDescription.trim(),
        sku: formSku.trim(),
        stockStatus: formStockStatus,
        imageUrl: formImageUrl.trim(),
        features: cleanedFeatures,
        actionButtonLabel: formActionLabel.trim() || 'Inquire Now',
        actionType: formActionType,
      });
    } else {
      onAddProduct({
        name: formName.trim(),
        category: formCategory.trim() || 'General',
        price: Number(formPrice) || 0,
        currency: formCurrency,
        description: formDescription.trim(),
        sku: formSku.trim(),
        stockStatus: formStockStatus,
        imageUrl: formImageUrl.trim(),
        features: cleanedFeatures,
        actionButtonLabel: formActionLabel.trim() || 'Inquire Now',
        actionType: formActionType,
      });
    }

    setIsModalOpen(false);
  };

  // Toggle selection for AI flow builder
  const toggleSelectProduct = (id: string) => {
    setSelectedProductIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedProductIds.length === filteredProducts.length) {
      setSelectedProductIds([]);
    } else {
      setSelectedProductIds(filteredProducts.map((p) => p.id));
    }
  };

  const handleSendToAIPromptBuilder = () => {
    if (onOpenAIPromptBuilderWithProducts) {
      onOpenAIPromptBuilderWithProducts(selectedProductIds);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-150">
      {/* Top Banner / Announcement */}
      <div className="mb-6 p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="px-2 py-0.5 rounded-md bg-white/20 text-[11px] font-semibold tracking-wide uppercase">
              Product & Service Catalog
            </span>
            <span className="text-xs text-blue-100 flex items-center">
              <Camera className="w-3.5 h-3.5 mr-1" /> Built-in Camera & Photo Upload
            </span>
          </div>
          <h2 className="text-xl font-bold tracking-tight">
            Manage What You Sell & Generate AI Bot Flows Instantly
          </h2>
          <p className="text-xs sm:text-sm text-blue-100 max-w-2xl">
            Add your services or physical products with pricing and photos. Select items to generate ready-to-run Messenger carousel flows with automated order inquiries!
          </p>
        </div>

        <div className="flex items-center space-x-2.5 w-full md:w-auto shrink-0">
          <button
            type="button"
            onClick={handleSendToAIPromptBuilder}
            className="flex-1 md:flex-initial inline-flex items-center justify-center px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-semibold text-xs shadow-md transition cursor-pointer"
          >
            <Sparkles className="w-4 h-4 mr-1.5 text-slate-950" />
            <span>Generate Flow from {selectedProductIds.length} Selected</span>
            <ArrowRight className="w-3.5 h-3.5 ml-1.5" />
          </button>
          <button
            type="button"
            onClick={openAddModal}
            className="inline-flex items-center justify-center px-4 py-2.5 rounded-xl bg-white hover:bg-slate-100 text-blue-700 font-semibold text-xs shadow-md transition cursor-pointer"
          >
            <Plus className="w-4 h-4 mr-1.5" />
            <span>Add Item</span>
          </button>
        </div>
      </div>

      {/* Action Bar & Filtering */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs mb-6 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search products, services, SKU or description..."
            className="w-full pl-10 pr-4 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500 transition"
          />
        </div>

        {/* Categories Pills */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {cat === 'all' ? 'All Items' : cat}
            </button>
          ))}
        </div>

        {/* Selection Tools & Seed button */}
        <div className="flex items-center space-x-2 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={toggleSelectAll}
            className="inline-flex items-center px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition"
            title="Select or deselect all items for AI prompt builder"
          >
            {selectedProductIds.length === filteredProducts.length && filteredProducts.length > 0 ? (
              <CheckSquare className="w-3.5 h-3.5 mr-1.5 text-blue-600" />
            ) : (
              <Square className="w-3.5 h-3.5 mr-1.5 text-slate-400" />
            )}
            <span>Select All ({selectedProductIds.length}/{filteredProducts.length})</span>
          </button>

          {onSeedSampleProducts && products.length === 0 && (
            <button
              type="button"
              onClick={onSeedSampleProducts}
              className="inline-flex items-center px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 transition"
            >
              <RotateCcw className="w-3.5 h-3.5 mr-1.5" />
              <span>Load Samples</span>
            </button>
          )}
        </div>
      </div>

      {/* Products Grid */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-12 text-center border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 flex items-center justify-center">
            <Package className="w-8 h-8" />
          </div>
          <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100 mb-1">
            No Products or Services Found
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mb-6">
            Add your offerings so your Facebook Messenger chatbot can display carousel cards and answer price inquiries 24/7!
          </p>
          <div className="flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={openAddModal}
              className="inline-flex items-center px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-md transition"
            >
              <Plus className="w-4 h-4 mr-1.5" />
              <span>Add Your First Item</span>
            </button>
            {onSeedSampleProducts && (
              <button
                type="button"
                onClick={onSeedSampleProducts}
                className="inline-flex items-center px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold text-xs hover:bg-slate-200 dark:hover:bg-slate-700 transition"
              >
                <RotateCcw className="w-4 h-4 mr-1.5" />
                <span>Load Sample Legal/Service Catalog</span>
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {filteredProducts.map((product) => {
            const isSelected = selectedProductIds.includes(product.id);
            return (
              <div
                key={product.id}
                className={`group relative bg-white dark:bg-slate-900 rounded-2xl border transition-all duration-200 shadow-xs hover:shadow-md flex flex-col overflow-hidden ${
                  isSelected
                    ? 'border-blue-500 dark:border-blue-500 ring-2 ring-blue-500/20'
                    : 'border-slate-200 dark:border-slate-800'
                }`}
              >
                {/* Image Section */}
                <div className="relative aspect-16/10 bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  {product.imageUrl ? (
                    <img
                      src={product.imageUrl}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-500">
                      <ImageIcon className="w-8 h-8 mb-1 opacity-60" />
                      <span className="text-[11px]">No Photo Added</span>
                    </div>
                  )}

                  {/* Top Badges */}
                  <div className="absolute top-2.5 left-2.5 flex items-center space-x-1.5">
                    <button
                      type="button"
                      onClick={() => toggleSelectProduct(product.id)}
                      className={`p-1.5 rounded-lg backdrop-blur-md transition shadow-xs cursor-pointer ${
                        isSelected
                          ? 'bg-blue-600 text-white'
                          : 'bg-black/50 hover:bg-black/70 text-white'
                      }`}
                      title={isSelected ? 'Included in AI Prompt' : 'Click to include in AI Prompt'}
                    >
                      {isSelected ? (
                        <Check className="w-3.5 h-3.5" />
                      ) : (
                        <Square className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <span className="px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-white text-[11px] font-medium">
                      {product.category}
                    </span>
                  </div>

                  {/* Price Tag Badge */}
                  <div className="absolute bottom-2.5 right-2.5 px-2.5 py-1 rounded-lg bg-blue-600 text-white text-xs font-bold shadow-md">
                    {product.currency === 'USD' ? '$' : product.currency === 'PHP' ? '₱' : `${product.currency} `}
                    {product.price.toLocaleString()}
                  </div>
                </div>

                {/* Content Section */}
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 line-clamp-1">
                        {product.name}
                      </h4>
                    </div>

                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mb-3 leading-relaxed">
                      {product.description || 'No description provided.'}
                    </p>

                    {/* Features Bullets */}
                    {product.features && product.features.length > 0 && (
                      <div className="space-y-1 mb-3">
                        {product.features.slice(0, 2).map((feat, idx) => (
                          <div
                            key={idx}
                            className="flex items-center text-[11px] text-slate-600 dark:text-slate-300"
                          >
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-2 shrink-0"></span>
                            <span className="line-clamp-1">{feat}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Bottom Action & Footer */}
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between gap-2">
                    <span className="text-[11px] font-mono text-slate-400">
                      {product.sku || 'NO-SKU'}
                    </span>

                    <div className="flex items-center space-x-1">
                      <button
                        type="button"
                        onClick={() => openEditModal(product)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                        title="Edit product details"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteProduct(product.id)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 dark:text-slate-400 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                        title="Delete product"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-5">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                  <Package className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    {editingProduct ? 'Edit Product / Service' : 'Add New Product or Service'}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Will be linked to your Facebook Messenger bot flows and catalog
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4">
              {/* Product Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Product / Service Name *
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Legal Consultation, 36-Unit MCLE Bundle, Custom Package"
                  className="w-full px-3.5 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Category & SKU */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Category
                  </label>
                  <input
                    type="text"
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    placeholder="e.g. Courses, Retainers, Merchandise"
                    className="w-full px-3.5 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Item Code / SKU
                  </label>
                  <input
                    type="text"
                    value={formSku}
                    onChange={(e) => setFormSku(e.target.value)}
                    placeholder="e.g. SRV-001"
                    className="w-full px-3.5 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              {/* Price & Currency */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Price Amount *
                  </label>
                  <div className="relative">
                    <DollarSign className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="number"
                      min="0"
                      step="any"
                      required
                      value={formPrice}
                      onChange={(e) => setFormPrice(parseFloat(e.target.value) || 0)}
                      className="w-full pl-8 pr-3.5 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Currency
                  </label>
                  <select
                    value={formCurrency}
                    onChange={(e) => setFormCurrency(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="PHP">PHP (₱)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="CAD">CAD ($)</option>
                    <option value="AUD">AUD ($)</option>
                  </select>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Brief summary of what the customer receives..."
                  className="w-full px-3.5 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                />
              </div>

              {/* Photo & Camera Section */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Product Image (Camera Snapshot or URL)
                </label>
                <div className="flex flex-col sm:flex-row gap-3 items-start">
                  {formImageUrl ? (
                    <div className="relative w-24 h-20 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 shrink-0 bg-slate-100">
                      <img
                        src={formImageUrl}
                        alt="Product Preview"
                        className="w-full h-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={() => setFormImageUrl('')}
                        className="absolute top-1 right-1 p-1 rounded-full bg-black/60 text-white hover:bg-black/80"
                        title="Remove photo"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ) : null}

                  <div className="flex-1 w-full space-y-2">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setIsCameraOpen(true)}
                        className="flex-1 inline-flex items-center justify-center px-3 py-2 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-xs font-semibold transition cursor-pointer"
                      >
                        <Camera className="w-3.5 h-3.5 mr-1.5" />
                        <span>Snap with Device Camera</span>
                      </button>
                    </div>
                    <input
                      type="text"
                      value={formImageUrl}
                      onChange={(e) => setFormImageUrl(e.target.value)}
                      placeholder="Or paste external image URL / photo link..."
                      className="w-full px-3 py-1.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400"
                    />
                  </div>
                </div>
              </div>

              {/* Key Features Bullets */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Key Highlights / Bullet Points
                  </label>
                  <button
                    type="button"
                    onClick={() => setFormFeatures([...formFeatures, ''])}
                    className="text-[11px] text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    + Add Bullet
                  </button>
                </div>
                <div className="space-y-1.5">
                  {formFeatures.map((feat, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={feat}
                        onChange={(e) => {
                          const updated = [...formFeatures];
                          updated[idx] = e.target.value;
                          setFormFeatures(updated);
                        }}
                        placeholder={`Feature highlight #${idx + 1}...`}
                        className="flex-1 px-3 py-1.5 rounded-lg text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                      />
                      {formFeatures.length > 1 && (
                        <button
                          type="button"
                          onClick={() => setFormFeatures(formFeatures.filter((_, i) => i !== idx))}
                          className="p-1.5 text-slate-400 hover:text-rose-500"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Button Label */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Messenger Card Button Label
                  </label>
                  <input
                    type="text"
                    value={formActionLabel}
                    onChange={(e) => setFormActionLabel(e.target.value)}
                    placeholder="e.g. Order Now, Inquire, Book Appointment"
                    className="w-full px-3.5 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Stock / Availability
                  </label>
                  <select
                    value={formStockStatus}
                    onChange={(e) =>
                      setFormStockStatus(e.target.value as ProductItem['stockStatus'])
                    }
                    className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100"
                  >
                    <option value="available">Available / Always In Stock</option>
                    <option value="in_stock">In Stock (Physical)</option>
                    <option value="preorder">Pre-Order</option>
                    <option value="out_of_stock">Out of Stock</option>
                  </select>
                </div>
              </div>

              {/* Form Buttons */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end space-x-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white shadow-md transition"
                >
                  {editingProduct ? 'Save Changes' : 'Add to Catalog'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Camera Capture Modal */}
      <CameraCaptureModal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        onCapture={(imgData) => setFormImageUrl(imgData)}
      />
    </div>
  );
};
