import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Copy, 
  Check, 
  Tag, 
  Search
} from 'lucide-react';
import { CannedResponse } from '../types/chatbot';

interface CannedResponsesProps {
  cannedResponses: CannedResponse[];
  onAddCannedResponse: (data: Partial<CannedResponse>) => Promise<void>;
  onDeleteCannedResponse: (id: string) => Promise<void>;
}

export const CannedResponses: React.FC<CannedResponsesProps> = ({
  cannedResponses,
  onAddCannedResponse,
  onDeleteCannedResponse,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [formTitle, setFormTitle] = useState('');
  const [formCategory, setFormCategory] = useState('Support Policy');
  const [formText, setFormText] = useState('');
  const [formTags, setFormTags] = useState('');
  const [formQuickReplies, setFormQuickReplies] = useState('');

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formText.trim()) return;

    await onAddCannedResponse({
      title: formTitle.trim(),
      category: formCategory.trim(),
      text: formText.trim(),
      tags: formTags.split(',').map(t => t.trim()).filter(Boolean),
      quickReplies: formQuickReplies.split(',').map(q => q.trim()).filter(Boolean),
    });

    setIsModalOpen(false);
    setFormTitle('');
    setFormText('');
    setFormTags('');
    setFormQuickReplies('');
  };

  const filtered = cannedResponses.filter(c =>
    c.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.text.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.tags.some(t => t.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 bg-white dark:bg-[#111827] p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">Approved 24/7 FAQ Responses & Knowledge Base</h2>
            <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
              {cannedResponses.length} Approved Answers
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Pre-approved answers to common customer inquiries, service policies, and registration guidelines.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5 mr-1" />
          Add FAQ Answer
        </button>
      </div>

      {/* Tab Purpose & Usage Guide Banner */}
      <div className="mb-6 rounded-xl border-l-4 border-l-emerald-500 border border-slate-200 dark:border-slate-800 bg-gradient-to-r from-emerald-50/70 via-white to-transparent dark:from-emerald-950/20 dark:via-slate-900/40 dark:to-transparent p-5 space-y-3">
        <div className="flex items-start gap-3">
          <span className="text-2xl leading-none">📖</span>
          <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300 w-full">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Tab Purpose & How to Use FAQ Knowledge Base
              </h3>
              <p className="leading-relaxed mt-0.5">
                <strong>Purpose:</strong> Maintain standard, lawyer-approved or business-vetted responses to customer questions. Human agents can insert these pre-written answers in 1 click during live chat takeover, ensuring 100% policy compliance, zero factual errors, and rapid reply speed.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  1. Title & Category
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  <strong>What to enter:</strong> Clear descriptive headline like <em>"Certificate & Receipt Issuance"</em>, categorized under <em>Billing & Compliance</em> or <em>MCLE Attendance</em>.
                </span>
              </div>

              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  2. Full Response Text
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  <strong>What to enter:</strong> The exact approved answer sent to the customer: <em>"All official certificates of attendance and compliance verification receipts are emailed within 24 hours of session completion."</em>
                </span>
              </div>

              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  3. Quick Reply Chips & Tags
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  <strong>What to enter:</strong> Attach interactive follow-up buttons (e.g. <code>View Schedule</code>, <code>Submit Inquiry</code>) and search tags (e.g. <code>certificate, receipt, delivery</code>).
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="mb-6 relative max-w-md">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search by topic, tag, or inquiry keyword..."
          className="w-full bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
        />
      </div>

      {/* Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map((item) => (
          <div
            key={item.id}
            className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between hover:border-slate-400 dark:hover:border-slate-700 transition"
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-medium uppercase tracking-wider bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                  {item.category}
                </span>

                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => handleCopy(item.id, item.text)}
                    className="p-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg transition cursor-pointer"
                    title="Copy Answer Text"
                  >
                    {copiedId === item.id ? (
                      <Check className="w-3.5 h-3.5 text-blue-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                  <button
                    onClick={() => onDeleteCannedResponse(item.id)}
                    className="p-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 hover:text-red-500 rounded-lg transition cursor-pointer"
                    title="Delete Answer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 mb-2">{item.title}</h3>

              <div className="bg-slate-50 dark:bg-[#090d16] p-3 rounded-xl border border-slate-200 dark:border-slate-800 mb-3 text-xs text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">
                {item.text}
              </div>

              {/* Quick Replies */}
              {item.quickReplies && item.quickReplies.length > 0 && (
                <div className="mb-3">
                  <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-1">
                    Quick Replies Attached:
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {item.quickReplies.map((qr, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 font-medium"
                      >
                        {qr}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Tags */}
            {item.tags.length > 0 && (
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-wrap gap-1">
                {item.tags.map((t, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center text-[10px] text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/50 px-2 py-0.5 rounded border border-slate-100 dark:border-slate-700/60"
                  >
                    <Tag className="w-2.5 h-2.5 mr-1 text-slate-400" />
                    {t}
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Modal for Add Approved FAQ */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-xl p-6">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-bold text-base text-slate-900 dark:text-slate-100">Add Pre-Approved FAQ Response</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer">✕</button>
            </div>

            <form onSubmit={handleAdd} className="space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Response Title / Topic</label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. Turnaround Time & Certificate Delivery"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs sm:text-sm"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Category</label>
                <input
                  type="text"
                  required
                  value={formCategory}
                  onChange={(e) => setFormCategory(e.target.value)}
                  placeholder="e.g. Delivery, Billing, Registration, MCLE"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs sm:text-sm"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Full Response Text</label>
                <textarea
                  rows={4}
                  required
                  value={formText}
                  onChange={(e) => setFormText(e.target.value)}
                  placeholder="The exact message sent to customer..."
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs sm:text-sm"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
                  Quick Reply Options (Comma-separated)
                </label>
                <input
                  type="text"
                  value={formQuickReplies}
                  onChange={(e) => setFormQuickReplies(e.target.value)}
                  placeholder="e.g. View Pricing, Speak with Agent, Main Menu"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs sm:text-sm"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Tags (Comma-separated)</label>
                <input
                  type="text"
                  value={formTags}
                  onChange={(e) => setFormTags(e.target.value)}
                  placeholder="e.g. certificate, delivery, timeline"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs sm:text-sm"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs cursor-pointer"
                >
                  Save Answer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
