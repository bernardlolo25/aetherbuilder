import React, { useState } from 'react';
import { 
  Send, 
  UserCheck, 
  Bot, 
  CheckCircle, 
  Search
} from 'lucide-react';
import { ConversationSession, CannedResponse } from '../types/chatbot';

interface LiveInboxProps {
  sessions: ConversationSession[];
  cannedResponses: CannedResponse[];
  onAgentReply: (sessionId: string, text: string) => Promise<void>;
  onUpdateStatus: (sessionId: string, status: ConversationSession['status']) => Promise<void>;
}

export const LiveInbox: React.FC<LiveInboxProps> = ({
  sessions,
  cannedResponses,
  onAgentReply,
  onUpdateStatus,
}) => {
  const [selectedSessionId, setSelectedSessionId] = useState<string>(sessions[0]?.id || '');
  const [replyText, setReplyText] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const currentSession = sessions.find(s => s.id === selectedSessionId) || sessions[0];

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !currentSession) return;

    await onAgentReply(currentSession.id, replyText.trim());
    setReplyText('');
  };

  const handleInsertCanned = (text: string) => {
    setReplyText(text);
  };

  const filteredSessions = sessions.filter(s => {
    if (filterStatus !== 'all' && s.status !== filterStatus) return false;
    if (searchQuery) {
      return s.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
             s.messages.some(m => m.text.toLowerCase().includes(searchQuery.toLowerCase()));
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 bg-white dark:bg-[#111827] p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">Live Customer Conversations & Agent Takeover</h2>
            <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
              {sessions.length} Active Threads
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Monitor real-time customer sessions. Pause the automated bot anytime to manually intervene and reply.
          </p>
        </div>

        {/* Filter */}
        <div className="flex items-center gap-2">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-100 dark:bg-slate-800 text-xs text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-blue-500"
          >
            <option value="all">All Conversations</option>
            <option value="active_bot">Bot Active</option>
            <option value="human_takeover">Escalated to Human</option>
            <option value="resolved">Resolved</option>
          </select>
        </div>
      </div>

      {/* Tab Purpose & Usage Guide Banner */}
      <div className="mb-6 rounded-xl border-l-4 border-l-purple-600 border border-slate-200 dark:border-slate-800 bg-gradient-to-r from-purple-50/70 via-white to-transparent dark:from-purple-950/20 dark:via-slate-900/40 dark:to-transparent p-5 space-y-3">
        <div className="flex items-start gap-3">
          <span className="text-2xl leading-none">💬</span>
          <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300 w-full">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Tab Purpose & How to Use Live Conversations & Agent Takeover
              </h3>
              <p className="leading-relaxed mt-0.5">
                <strong>Purpose:</strong> Live monitoring and manual customer support desk. When a customer reaches out on Facebook Messenger, you can watch their messages in real time. If a customer has a complex request or asks to speak with staff, click <strong>Take Over Chat (Pause Bot)</strong> to pause bot automation and reply directly as a human agent.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  1. Select & Review Thread
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  Click any conversation in the left pane to view message history, user ID, current decision tree step, and inquirer information.
                </span>
              </div>

              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  2. 1-Click Takeover / Pause Bot
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  Click <strong>Take Over Chat</strong> at top right. This pauses the automated bot for that specific customer so your human conversation is never interrupted.
                </span>
              </div>

              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">
                  3. Send Reply & Resume 24/7 Bot
                </span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  Click pre-approved <strong>Quick Answers</strong> or type custom text. Once support is completed, click <strong>Resume 24/7 Bot</strong> to reactivate automation!
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Inbox Two-Pane Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs min-h-[640px]">
        {/* Left Pane: Conversations List */}
        <div className="lg:col-span-4 border-r border-slate-200 dark:border-slate-800 flex flex-col bg-slate-50 dark:bg-[#090d16]">
          <div className="p-3 border-b border-slate-200 dark:border-slate-800">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search conversations..."
                className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
            {filteredSessions.map((s) => {
              const lastMsg = s.messages[s.messages.length - 1];
              const isSelected = s.id === currentSession?.id;

              return (
                <button
                  key={s.id}
                  onClick={() => setSelectedSessionId(s.id)}
                  className={`w-full text-left p-3.5 transition flex items-start space-x-3 cursor-pointer ${
                    isSelected ? 'bg-white dark:bg-slate-800/80 border-l-3 border-blue-600' : 'hover:bg-white/60 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <div className="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-200 font-bold text-xs flex-shrink-0">
                    {s.userName.slice(0, 2).toUpperCase()}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="font-semibold text-xs text-slate-900 dark:text-slate-100 truncate">{s.userName}</span>
                      <span className="text-[10px] text-slate-400">{lastMsg?.timestamp || ''}</span>
                    </div>

                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mb-1">
                      {lastMsg ? `${lastMsg.sender === 'user' ? '👤 ' : '🤖 '}${lastMsg.text}` : 'No messages yet'}
                    </p>

                    <div>
                      {s.status === 'human_takeover' ? (
                        <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[10px] font-semibold bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200">
                          Human Agent
                        </span>
                      ) : s.status === 'resolved' ? (
                        <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                          Resolved
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[10px] font-medium bg-blue-50 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300">
                          24/7 Bot Active
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Pane: Selected Conversation Details */}
        {currentSession ? (
          <div className="lg:col-span-8 flex flex-col justify-between bg-white dark:bg-[#111827]">
            {/* Thread Header */}
            <div className="px-5 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold flex items-center justify-center text-xs">
                  {currentSession.userName.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">{currentSession.userName}</h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                    ID: {currentSession.userId} · Active step: {currentSession.currentNodeId}
                  </p>
                </div>
              </div>

              {/* Status Action Buttons */}
              <div className="flex items-center space-x-2">
                {currentSession.status === 'human_takeover' ? (
                  <button
                    onClick={() => onUpdateStatus(currentSession.id, 'active_bot')}
                    className="inline-flex items-center px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs transition cursor-pointer"
                  >
                    <Bot className="w-3.5 h-3.5 mr-1.5" />
                    Resume 24/7 Bot
                  </button>
                ) : (
                  <button
                    onClick={() => onUpdateStatus(currentSession.id, 'human_takeover')}
                    className="inline-flex items-center px-3 py-1.5 bg-slate-800 hover:bg-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600 text-white rounded-lg text-xs font-semibold shadow-xs transition cursor-pointer"
                  >
                    <UserCheck className="w-3.5 h-3.5 mr-1.5" />
                    Take Over Chat (Pause Bot)
                  </button>
                )}

                {currentSession.status !== 'resolved' ? (
                  <button
                    onClick={() => onUpdateStatus(currentSession.id, 'resolved')}
                    className="inline-flex items-center px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-medium border border-slate-200 dark:border-slate-700 transition cursor-pointer"
                  >
                    <CheckCircle className="w-3.5 h-3.5 mr-1" />
                    Mark Resolved
                  </button>
                ) : (
                  <button
                    onClick={() => onUpdateStatus(currentSession.id, 'active_bot')}
                    className="inline-flex items-center px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-medium border border-slate-200 dark:border-slate-700 transition cursor-pointer"
                  >
                    Reopen Chat
                  </button>
                )}
              </div>
            </div>

            {/* Messages Scroll View */}
            <div className="flex-1 overflow-y-auto p-5 space-y-3 bg-slate-50 dark:bg-[#090d16] max-h-[440px]">
              {currentSession.messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex flex-col ${m.sender === 'user' ? 'items-start' : 'items-end'}`}
                >
                  <div className="flex items-end gap-2 max-w-[80%]">
                    {m.sender === 'user' && (
                      <div className="w-6 h-6 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center text-[10px] font-bold">
                        👤
                      </div>
                    )}
                    <div
                      className={`rounded-2xl px-4 py-2.5 text-xs sm:text-sm whitespace-pre-wrap leading-relaxed shadow-xs ${
                        m.sender === 'user'
                          ? 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-bl-none border border-slate-200 dark:border-slate-700'
                          : m.sender === 'agent'
                          ? 'bg-slate-800 dark:bg-slate-700 text-white rounded-br-none'
                          : 'bg-blue-600 text-white rounded-br-none'
                      }`}
                    >
                      {m.text}
                    </div>
                    {m.sender !== 'user' && (
                      <div className="w-6 h-6 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center text-[10px] font-bold">
                        {m.sender === 'agent' ? '👨‍💼' : '🤖'}
                      </div>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 px-1">
                    {m.sender === 'agent' ? 'Live Agent' : m.sender === 'bot' ? '24/7 Bot' : 'Customer'} · {m.timestamp}
                  </span>
                </div>
              ))}
            </div>

            {/* Quick Canned Inserter Bar */}
            {cannedResponses.length > 0 && (
              <div className="px-4 py-2 bg-slate-50 dark:bg-[#090d16] border-t border-slate-200 dark:border-slate-800 flex items-center space-x-2 overflow-x-auto scrollbar-none">
                <span className="text-[11px] text-slate-500 dark:text-slate-400 font-semibold whitespace-nowrap">
                  Quick Answers:
                </span>
                {cannedResponses.map((cr) => (
                  <button
                    key={cr.id}
                    onClick={() => handleInsertCanned(cr.text)}
                    className="px-2.5 py-1 rounded bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-[11px] whitespace-nowrap border border-slate-200 dark:border-slate-700 transition cursor-pointer"
                  >
                    {cr.title}
                  </button>
                ))}
              </div>
            )}

            {/* Agent Reply Box */}
            <form onSubmit={handleSendReply} className="p-4 bg-white dark:bg-[#111827] border-t border-slate-200 dark:border-slate-800 flex items-center gap-2">
              <input
                type="text"
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="Type reply as human support agent (pauses automated bot)..."
                className="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 placeholder-slate-400 text-xs sm:text-sm px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-blue-500"
              />
              <button
                type="submit"
                disabled={!replyText.trim()}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white rounded-xl text-xs font-semibold shadow-xs transition flex items-center cursor-pointer"
              >
                <Send className="w-4 h-4 mr-1.5" />
                Send as Agent
              </button>
            </form>
          </div>
        ) : (
          <div className="lg:col-span-8 flex items-center justify-center p-8 text-slate-400 text-xs">
            Select a conversation on the left to monitor or take over.
          </div>
        )}
      </div>
    </div>
  );
};
