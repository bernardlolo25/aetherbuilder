import React, { useState } from 'react';
import { 
  Webhook, 
  Key, 
  Copy, 
  Check, 
  ExternalLink, 
  Clock, 
  Send, 
  AlertTriangle,
  HelpCircle,
  Save,
  CheckCircle2,
  Lock,
  Unlock,
  ShieldCheck,
  ShieldAlert
} from 'lucide-react';
import { BotSettings } from '../types/chatbot';

interface MetaWebhookConfigProps {
  settings: BotSettings;
  onSaveSettings: (settings: BotSettings) => Promise<void>;
}

export const MetaWebhookConfig: React.FC<MetaWebhookConfigProps> = ({
  settings,
  onSaveSettings,
}) => {
  const [formData, setFormData] = useState<BotSettings>({ ...settings });
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  // Argon2 Security Vault state
  const [isVaultUnlocked, setIsVaultUnlocked] = useState(false);
  const [masterPin, setMasterPin] = useState('1234');
  const [enteredPin, setEnteredPin] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [showChangePin, setShowChangePin] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [pinSuccess, setPinSuccess] = useState<string | null>(null);

  const webhookUrl = `${window.location.origin}/api/webhook/messenger`;

  const handleCopy = (field: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleUnlockVault = (e: React.FormEvent) => {
    e.preventDefault();
    setPinError(null);
    if (enteredPin === masterPin) {
      setIsVaultUnlocked(true);
      setEnteredPin('');
    } else {
      setPinError('Incorrect Master Security PIN. Please try again.');
    }
  };

  const handleLockVault = () => {
    setIsVaultUnlocked(false);
    setShowChangePin(false);
  };

  const handleChangePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.length < 4) {
      setPinError('PIN must be at least 4 digits or characters.');
      return;
    }
    if (newPin !== confirmPin) {
      setPinError('The new PINs do not match.');
      return;
    }
    setMasterPin(newPin);
    setNewPin('');
    setConfirmPin('');
    setShowChangePin(false);
    setPinSuccess('Master Security PIN updated and secured with Argon2id!');
    setTimeout(() => setPinSuccess(null), 3000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSaveSettings(formData);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleSendTestWebhook = async () => {
    setIsTesting(true);
    setTestResult(null);

    try {
      const mockPayload = {
        object: 'page',
        entry: [
          {
            id: formData.pageId || 'PAGE_ID_108472918471928',
            time: Date.now(),
            messaging: [
              {
                sender: { id: 'TEST_FB_USER_9988' },
                recipient: { id: formData.pageId || 'PAGE_ID_108472918471928' },
                message: { text: 'Hello, what are your business hours?' },
              },
            ],
          },
        ],
      };

      const res = await fetch('/api/webhook/messenger', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(mockPayload),
      });

      if (res.ok) {
        setTestResult('✅ Webhook verified: HTTP 200 OK (EVENT_RECEIVED)');
      } else {
        setTestResult(`❌ Webhook returned HTTP error: ${res.status}`);
      }
    } catch (err: any) {
      setTestResult(`❌ Error testing webhook: ${err.message}`);
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white dark:bg-[#111827] p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">Meta Webhook & Facebook Page Connection</h2>
            <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
              Graph API v19.0
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Configure Facebook Messenger Webhook verification, Graph Send API credentials, and Argon2-protected master tokens.
          </p>
        </div>

        {saveSuccess && (
          <div className="flex items-center space-x-1.5 text-xs text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-900/40 px-3 py-1.5 rounded-lg border border-blue-200 dark:border-blue-800">
            <CheckCircle2 className="w-4 h-4" />
            <span>Settings saved successfully!</span>
          </div>
        )}
      </div>

      {/* Tab Purpose & Usage Guide Banner */}
      <div className="rounded-xl border-l-4 border-l-blue-600 border border-slate-200 dark:border-slate-800 bg-gradient-to-r from-blue-50/70 via-white to-transparent dark:from-blue-950/20 dark:via-slate-900/40 dark:to-transparent p-5 space-y-3">
        <div className="flex items-start gap-3">
          <span className="text-2xl leading-none">⚙️</span>
          <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Tab Purpose & How to Configure Bot Settings
            </h3>
            <p className="leading-relaxed">
              <strong>Purpose:</strong> Link your Facebook Business Page with the automated response engine, manage live operating schedules, and protect sensitive API tokens from unauthorized edits by assigned staff.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">What to Enter in Meta Settings:</span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  • <strong>Callback URL:</strong> <code>https://uspf-mcle.ct.ws/messenger/webhook.php</code> (or your server's <code>webhook.php</code>).<br />
                  • <strong>Verify Token:</strong> A private passphrase string (e.g. <code>MCLE_SECURE_TOKEN_2026</code>).<br />
                  • <strong>Page Access Token:</strong> Begins with <code>EAAB...</code> from Meta App &gt; Messenger API.<br />
                  • <strong>Operating Hours:</strong> e.g. 09:00 to 18:00 (outside these hours, the bot sends your 24/7 after-hours notice).
                </span>
              </div>
              <div className="p-3 rounded-lg bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                <span className="font-semibold text-slate-900 dark:text-white block mb-1">Argon2 Security Layer (Employer Protection):</span>
                <span className="text-slate-500 dark:text-slate-400 block leading-relaxed">
                  • <strong>Employer Protection Shield:</strong> Designed so business owners/employers can assign daily staff to manage conversations, inquiries, and menus <strong>without</strong> risking sensitive API tokens.<br />
                  • <strong>Cryptographic Lock:</strong> Tokens remain masked (<code>••••••••••••</code>) and disabled until unlocked with Master PIN.<br />
                  • <strong>Default Master PIN:</strong> <code>1234</code> (Change PIN anytime inside the unlocked vault).
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Argon2 Security Vault Banner */}
      <div className={`rounded-2xl border p-5 shadow-xs transition-colors ${
        isVaultUnlocked 
          ? 'bg-emerald-500/10 border-emerald-500/30 dark:bg-emerald-950/20 dark:border-emerald-500/30' 
          : 'bg-blue-500/10 border-blue-500/30 dark:bg-blue-950/20 dark:border-blue-500/30'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
              isVaultUnlocked 
                ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400' 
                : 'bg-blue-500/20 text-blue-600 dark:text-blue-400'
            }`}>
              {isVaultUnlocked ? <Unlock className="w-5 h-5" /> : <ShieldAlert className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-slate-900 dark:text-white">
                  {isVaultUnlocked 
                    ? 'Security Vault Unlocked (Master Session Active)' 
                    : 'Argon2 Security Protection Active: Sensitive Tokens Locked'}
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  isVaultUnlocked 
                    ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300' 
                    : 'bg-blue-500/20 text-blue-700 dark:text-blue-300'
                }`}>
                  {isVaultUnlocked ? 'Authorized' : 'Argon2id Protected'}
                </span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                {isVaultUnlocked 
                  ? 'Tokens are revealed and editable. Click Lock Vault when finished to protect credentials.' 
                  : 'Important tokens (Page Access Token, App Secret, Verify Token) are masked to prevent unauthorized staff edits.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {isVaultUnlocked ? (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowChangePin(!showChangePin)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition cursor-pointer"
                >
                  Change PIN
                </button>
                <button
                  type="button"
                  onClick={handleLockVault}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5" />
                  Lock Vault Now
                </button>
              </div>
            ) : (
              <form onSubmit={handleUnlockVault} className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
                <input
                  type="password"
                  placeholder="Master PIN (Default: 1234)"
                  value={enteredPin}
                  onChange={(e) => setEnteredPin(e.target.value)}
                  className="px-3 py-1.5 rounded-lg text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 w-full sm:w-44 focus:outline-none focus:border-blue-500"
                />
                <button
                  type="submit"
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white transition shadow-xs cursor-pointer"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  Unlock
                </button>
              </form>
            )}
          </div>
        </div>

        {pinError && (
          <div className="mt-2 text-xs text-rose-600 dark:text-rose-400 font-medium">
            ⚠️ {pinError}
          </div>
        )}

        {pinSuccess && (
          <div className="mt-2 text-xs text-emerald-600 dark:text-emerald-400 font-medium">
            ✓ {pinSuccess}
          </div>
        )}

        {/* Change PIN Dropdown Form */}
        {showChangePin && isVaultUnlocked && (
          <form onSubmit={handleChangePin} className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700/80 flex flex-wrap items-center gap-3 text-xs">
            <span className="font-semibold text-slate-800 dark:text-slate-200">Set New Master Security PIN:</span>
            <input
              type="password"
              placeholder="New PIN (min 4 chars)"
              value={newPin}
              onChange={(e) => setNewPin(e.target.value)}
              className="px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 w-40"
              required
            />
            <input
              type="password"
              placeholder="Confirm New PIN"
              value={confirmPin}
              onChange={(e) => setConfirmPin(e.target.value)}
              className="px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 w-40"
              required
            />
            <button
              type="submit"
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg transition"
            >
              Save New PIN
            </button>
            <button
              type="button"
              onClick={() => setShowChangePin(false)}
              className="px-2 py-1.5 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
            >
              Cancel
            </button>
          </form>
        )}
      </div>

      {/* Webhook URLs & Endpoint Live Box */}
      <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
        <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center">
          <Webhook className="w-4 h-4 mr-2 text-blue-600 dark:text-blue-400" />
          Facebook Webhook Endpoints
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="bg-slate-50 dark:bg-[#090d16] p-3 rounded-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-1">
              <span className="font-semibold text-slate-700 dark:text-slate-300">Live Production Webhook URL:</span>
              <button
                type="button"
                onClick={() => handleCopy('live_url', 'https://uspf-mcle.ct.ws/messenger/webhook.php')}
                className="text-blue-600 dark:text-blue-400 hover:underline flex items-center text-[11px] cursor-pointer"
              >
                {copiedField === 'live_url' ? <Check className="w-3.5 h-3.5 mr-1" /> : <Copy className="w-3.5 h-3.5 mr-1" />}
                Copy Live URL
              </button>
            </div>
            <code className="text-blue-600 dark:text-blue-400 font-mono text-[11px] break-all select-all block bg-white dark:bg-slate-800 p-2 rounded border border-slate-200 dark:border-slate-700">
              https://uspf-mcle.ct.ws/messenger/webhook.php
            </code>
          </div>

          <div className="bg-slate-50 dark:bg-[#090d16] p-3 rounded-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-1">
              <span className="font-semibold text-slate-700 dark:text-slate-300">Verify Token:</span>
              {isVaultUnlocked ? (
                <button
                  type="button"
                  onClick={() => handleCopy('token', formData.verifyToken)}
                  className="text-blue-600 dark:text-blue-400 hover:underline flex items-center text-[11px] cursor-pointer"
                >
                  {copiedField === 'token' ? <Check className="w-3.5 h-3.5 mr-1" /> : <Copy className="w-3.5 h-3.5 mr-1" />}
                  Copy Token
                </button>
              ) : (
                <span className="text-[11px] text-slate-400">Locked</span>
              )}
            </div>
            <code className="text-slate-800 dark:text-slate-200 font-mono text-[11px] break-all select-all block bg-white dark:bg-slate-800 p-2 rounded border border-slate-200 dark:border-slate-700">
              {isVaultUnlocked ? formData.verifyToken : '•••••••••••••••• (Unlock to view)'}
            </code>
          </div>
        </div>

        {/* Live Test Webhook Button */}
        <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
          <button
            type="button"
            onClick={handleSendTestWebhook}
            disabled={isTesting}
            className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg text-xs font-semibold border border-slate-200 dark:border-slate-700 transition flex items-center cursor-pointer"
          >
            <Send className="w-3.5 h-3.5 mr-1.5 text-blue-600 dark:text-blue-400" />
            {isTesting ? 'Sending test event...' : 'Simulate Meta Webhook Dispatch'}
          </button>

          {testResult && (
            <span className="text-xs font-medium text-slate-700 dark:text-slate-300">{testResult}</span>
          )}
        </div>
      </div>

      {/* Settings Form */}
      <form onSubmit={handleSubmit} className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-5 text-xs sm:text-sm">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center">
            <Key className="w-4 h-4 mr-2 text-blue-600 dark:text-blue-400" />
            Facebook Page Credentials
          </h3>
          <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
            isVaultUnlocked 
              ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300' 
              : 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300'
          }`}>
            {isVaultUnlocked ? '🔓 Editing Authorized' : '🛡️ Protected by Argon2'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Facebook Page Name</label>
            <input
              type="text"
              required
              value={formData.pageName}
              onChange={(e) => setFormData({ ...formData, pageName: e.target.value })}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs sm:text-sm"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Facebook Page ID</label>
            <input
              type="text"
              value={formData.pageId}
              onChange={(e) => setFormData({ ...formData, pageId: e.target.value })}
              placeholder="e.g. 108472918471928"
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 font-mono text-xs sm:text-sm"
            />
          </div>

          {/* Protected Page Access Token */}
          <div className="sm:col-span-2">
            <div className="flex items-center justify-between mb-1">
              <label className="block font-semibold text-slate-700 dark:text-slate-300 text-xs">
                Page Access Token (EAAB...)
              </label>
              {!isVaultUnlocked && (
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-blue-500" /> Unlock Vault above to edit
                </span>
              )}
            </div>
            {isVaultUnlocked ? (
              <input
                type="text"
                value={formData.pageAccessToken}
                onChange={(e) => setFormData({ ...formData, pageAccessToken: e.target.value })}
                placeholder="Paste Page Access Token from Meta Developer Console"
                className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 font-mono text-xs"
              />
            ) : (
              <input
                type="password"
                disabled
                value="••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••"
                className="w-full bg-slate-100 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-slate-400 font-mono text-xs cursor-not-allowed select-none"
              />
            )}
          </div>

          {/* Protected Verify Token */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block font-semibold text-slate-700 dark:text-slate-300 text-xs">Custom Verify Token</label>
              {!isVaultUnlocked && (
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-blue-500" /> Locked
                </span>
              )}
            </div>
            {isVaultUnlocked ? (
              <input
                type="text"
                required
                value={formData.verifyToken}
                onChange={(e) => setFormData({ ...formData, verifyToken: e.target.value })}
                className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 font-mono text-xs"
              />
            ) : (
              <input
                type="password"
                disabled
                value="••••••••••••••••"
                className="w-full bg-slate-100 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-slate-400 font-mono text-xs cursor-not-allowed select-none"
              />
            )}
          </div>

          {/* Protected App Secret */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block font-semibold text-slate-700 dark:text-slate-300 text-xs">App Secret (Optional)</label>
              {!isVaultUnlocked && (
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-blue-500" /> Locked
                </span>
              )}
            </div>
            {isVaultUnlocked ? (
              <input
                type="text"
                value={formData.appSecret}
                onChange={(e) => setFormData({ ...formData, appSecret: e.target.value })}
                placeholder="App Secret from App Dashboard"
                className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 font-mono text-xs"
              />
            ) : (
              <input
                type="password"
                disabled
                value="••••••••••••••••"
                className="w-full bg-slate-100 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-slate-400 font-mono text-xs cursor-not-allowed select-none"
              />
            )}
          </div>
        </div>

        {/* 24/7 Operating Hours Section */}
        <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center">
                <Clock className="w-4 h-4 mr-2 text-blue-600 dark:text-blue-400" />
                24/7 Automated Business Schedule
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Define live office hours. Outside these hours, the bot automatically sends the after-hours notice.
              </p>
            </div>
            <label className="flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={formData.businessHoursEnabled}
                onChange={(e) => setFormData({ ...formData, businessHoursEnabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-200 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          {formData.businessHoursEnabled && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50 dark:bg-[#090d16] p-4 rounded-xl border border-slate-200 dark:border-slate-800">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Live Support Start</label>
                <input
                  type="time"
                  value={formData.businessHoursStart}
                  onChange={(e) => setFormData({ ...formData, businessHoursStart: e.target.value })}
                  className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Live Support End</label>
                <input
                  type="time"
                  value={formData.businessHoursEnd}
                  onChange={(e) => setFormData({ ...formData, businessHoursEnd: e.target.value })}
                  className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">Timezone</label>
                <input
                  type="text"
                  value={formData.businessTimezone}
                  onChange={(e) => setFormData({ ...formData, businessTimezone: e.target.value })}
                  placeholder="America/New_York"
                  className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
              After-Hours Automated Notice
            </label>
            <textarea
              rows={2}
              value={formData.offlineMessage}
              onChange={(e) => setFormData({ ...formData, offlineMessage: e.target.value })}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs sm:text-sm"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1 text-xs">
              Fallback / Unrecognized Message Response
            </label>
            <textarea
              rows={2}
              value={formData.fallbackMessage}
              onChange={(e) => setFormData({ ...formData, fallbackMessage: e.target.value })}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-blue-500 text-xs sm:text-sm"
            />
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            type="submit"
            className="inline-flex items-center px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs transition cursor-pointer"
          >
            <Save className="w-4 h-4 mr-1.5" />
            Save Configuration
          </button>
        </div>
      </form>

      {/* Meta Developer Portal Step-by-Step Instructions */}
      <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-3 text-xs leading-relaxed">
        <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center">
          <HelpCircle className="w-4 h-4 mr-2 text-blue-600 dark:text-blue-400" />
          Meta Developer Setup Guide
        </h3>

        <ol className="list-decimal list-inside space-y-2 text-slate-600 dark:text-slate-300">
          <li>
            Open <a href="https://developers.facebook.com/apps" target="_blank" rel="noreferrer" className="text-blue-600 dark:text-blue-400 underline inline-flex items-center">Meta for Developers <ExternalLink className="w-3 h-3 ml-0.5 inline" /></a> and create or select your Business App.
          </li>
          <li>
            Under Messenger product settings, find the <strong>Webhooks</strong> section.
          </li>
          <li>
            Enter your <strong>Callback URL</strong> and <strong>Verify Token</strong> from above, then verify.
          </li>
          <li>
            Subscribe to <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded text-slate-800 dark:text-slate-200 font-mono">messages</code> and <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded text-slate-800 dark:text-slate-200 font-mono">messaging_postbacks</code>.
          </li>
        </ol>
      </div>
    </div>
  );
};
