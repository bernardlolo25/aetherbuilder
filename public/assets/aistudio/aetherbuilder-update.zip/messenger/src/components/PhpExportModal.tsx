import React, { useState } from 'react';
import { 
  Download, 
  Copy, 
  Check, 
  Database, 
  FileCode, 
  Send, 
  CheckCircle2, 
  FolderArchive,
  Palette,
  FileText
} from 'lucide-react';
import { FlowNode, KeywordTrigger, BotSettings } from '../types/chatbot';
import { 
  generateSchemaSql, 
  generateWebhookPhp, 
  generateSendApiPhp,
  generateAppCss,
  generateAdminJs,
  generateConfigPhp
} from '../services/phpExportGenerator';

interface PhpExportModalProps {
  nodes: FlowNode[];
  keywords: KeywordTrigger[];
  settings: BotSettings;
}

export const PhpExportModal: React.FC<PhpExportModalProps> = ({
  nodes,
  keywords,
  settings,
}) => {
  const [selectedFile, setSelectedFile] = useState<'config' | 'sql' | 'webhook' | 'send' | 'css' | 'js'>('config');
  const [copied, setCopied] = useState(false);

  const configContent = generateConfigPhp();
  const sqlContent = generateSchemaSql(nodes, keywords, settings);
  const webhookContent = generateWebhookPhp();
  const sendApiContent = generateSendApiPhp();
  const cssContent = generateAppCss();
  const jsContent = generateAdminJs();

  const getActiveContent = () => {
    switch (selectedFile) {
      case 'config':
        return { filename: 'config.php', content: configContent, lang: 'php' };
      case 'sql':
        return { filename: 'schema.sql', content: sqlContent, lang: 'sql' };
      case 'webhook':
        return { filename: 'webhook.php', content: webhookContent, lang: 'php' };
      case 'send':
        return { filename: 'send_api.php', content: sendApiContent, lang: 'php' };
      case 'css':
        return { filename: 'app.css', content: cssContent, lang: 'css' };
      case 'js':
        return { filename: 'admin.js', content: jsContent, lang: 'javascript' };
    }
  };

  const active = getActiveContent();

  const handleCopy = () => {
    navigator.clipboard.writeText(active.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white dark:bg-[#111827] p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Production Web Deployment Bundle (PHP + MySQL)
            </h2>
            <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
              PHP + CSS + Vanilla JS
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Self-contained files ready to upload to your <code className="font-mono">htdocs/</code> or <code className="font-mono">public_html/</code> folder on your web hosting server.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <a
            href="/messenger_bot_production_ready.zip"
            download="messenger_bot_production_ready.zip"
            className="w-full sm:w-auto justify-center inline-flex items-center px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm transition cursor-pointer"
          >
            <FolderArchive className="w-4 h-4 mr-1.5" />
            Download Complete Production ZIP
          </a>
          <button
            onClick={() => handleDownload('config.php', configContent)}
            className="inline-flex items-center px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg shadow-xs transition cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5 mr-1" />
            config.php
          </button>
          <button
            onClick={() => handleDownload('app.css', cssContent)}
            className="inline-flex items-center px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 transition cursor-pointer"
          >
            <Palette className="w-3.5 h-3.5 mr-1 text-blue-600 dark:text-blue-400" />
            app.css
          </button>
          <button
            onClick={() => handleDownload('admin.js', jsContent)}
            className="inline-flex items-center px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 transition cursor-pointer"
          >
            <FileCode className="w-3.5 h-3.5 mr-1 text-blue-600 dark:text-blue-400" />
            admin.js
          </button>
          <button
            onClick={() => handleDownload('schema.sql', sqlContent)}
            className="inline-flex items-center px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 transition cursor-pointer"
          >
            <Database className="w-3.5 h-3.5 mr-1 text-blue-600 dark:text-blue-400" />
            schema.sql
          </button>
          <button
            onClick={() => handleDownload('webhook.php', webhookContent)}
            className="inline-flex items-center px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 transition cursor-pointer"
          >
            <Send className="w-3.5 h-3.5 mr-1" />
            webhook.php
          </button>
        </div>
      </div>

      {/* Package Components Overview */}
      <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs text-xs">
        <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100 mb-2 flex items-center">
          <FolderArchive className="w-4 h-4 mr-2 text-blue-600 dark:text-blue-400" />
          Single-Host Production Architecture
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3">
          <div className="bg-slate-50 dark:bg-[#090d16] p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center text-slate-900 dark:text-slate-100 font-bold mb-1">
              <CheckCircle2 className="w-4 h-4 mr-1.5 text-blue-600 dark:text-blue-400" />
              1. config/config.php
            </div>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-[11px]">
              Pre-configured with your database connection parameters and protected by the Argon2 security vault.
            </p>
          </div>

          <div className="bg-slate-50 dark:bg-[#090d16] p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center text-slate-900 dark:text-slate-100 font-bold mb-1">
              <CheckCircle2 className="w-4 h-4 mr-1.5 text-blue-600 dark:text-blue-400" />
              2. assets/css/app.css & admin.js
            </div>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-[11px]">
              Modern CSS variables with dark & light theme presets, clean typography, responsive layouts, and vanilla JS toggler.
            </p>
          </div>

          <div className="bg-slate-50 dark:bg-[#090d16] p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center text-slate-900 dark:text-slate-100 font-bold mb-1">
              <CheckCircle2 className="w-4 h-4 mr-1.5 text-blue-600 dark:text-blue-400" />
              3. webhook.php & schema.sql
            </div>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-[11px]">
              Fully mapped to your exact table structure: <code className="font-mono">keyword_triggers</code>, <code className="font-mono">flow_nodes</code>, <code className="font-mono">conversations</code>, and <code className="font-mono">leads</code>.
            </p>
          </div>
        </div>
      </div>

      {/* Code Viewer */}
      <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs">
        {/* Code Tabs */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-200 dark:border-slate-800 p-3 bg-slate-50 dark:bg-[#090d16] gap-3">
          <div className="flex flex-wrap gap-1">
            <button
              onClick={() => setSelectedFile('config')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                selectedFile === 'config'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              config/config.php
            </button>
            <button
              onClick={() => setSelectedFile('css')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                selectedFile === 'css'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              assets/css/app.css
            </button>
            <button
              onClick={() => setSelectedFile('js')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                selectedFile === 'js'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              assets/js/admin.js
            </button>
            <button
              onClick={() => setSelectedFile('sql')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                selectedFile === 'sql'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              schema.sql (MySQL)
            </button>
            <button
              onClick={() => setSelectedFile('webhook')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                selectedFile === 'webhook'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              webhook.php
            </button>
            <button
              onClick={() => setSelectedFile('send')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                selectedFile === 'send'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              send_api.php
            </button>
          </div>

          <div className="flex items-center space-x-2 shrink-0">
            <button
              onClick={handleCopy}
              className="inline-flex items-center px-3 py-1 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium border border-slate-200 dark:border-slate-700 transition cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 mr-1 text-blue-600" /> : <Copy className="w-3.5 h-3.5 mr-1" />}
              {copied ? 'Copied!' : 'Copy Code'}
            </button>
            <button
              onClick={() => handleDownload(active.filename, active.content)}
              className="inline-flex items-center px-3 py-1 rounded-md bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium transition shadow-xs cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 mr-1" />
              Download {active.filename}
            </button>
          </div>
        </div>

        {/* Code Content Area */}
        <pre className="p-4 bg-slate-50 dark:bg-[#070b12] font-mono text-xs text-slate-800 dark:text-slate-200 overflow-x-auto max-h-[480px] leading-relaxed scrollbar-thin max-w-full break-all whitespace-pre-wrap">
          {active.content}
        </pre>
      </div>

      {/* Production Step-by-Step Testing Guide */}
      <div className="bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs text-xs leading-relaxed space-y-3">
        <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">
          How to Test and Deploy on Production Web Hosting
        </h3>
        <ol className="list-decimal list-inside space-y-2 text-slate-600 dark:text-slate-300">
          <li>
            <strong>Create MySQL Database:</strong> In your hosting control panel (cPanel or PHP manager), open <em>MySQL Databases</em>. Create a new database and note the MySQL Hostname, Database Name, Username, and Account Password.
          </li>
          <li>
            <strong>Import schema.sql:</strong> Click <em>phpMyAdmin</em> next to your database, go to the <strong>Import</strong> tab, select <code>schema.sql</code>, and click <strong>Go</strong>. This creates all 10 tables.
          </li>
          <li>
            <strong>Upload Files to htdocs:</strong> Using FileZilla or your Online File Manager, upload your files into <code>htdocs/</code> or <code>public_html/</code>:
            <ul className="list-disc list-inside ml-4 mt-1 space-y-0.5 text-slate-500 dark:text-slate-400">
              <li><code>assets/css/app.css</code> (Updated theme stylesheet)</li>
              <li><code>assets/js/admin.js</code> (Theme toggle & CSV export script)</li>
              <li><code>webhook.php</code> & <code>send_api.php</code> (In the root of htdocs)</li>
              <li><code>config/config.php</code> (Enter your database credentials)</li>
            </ul>
          </li>
          <li>
            <strong>Run Initial Setup:</strong> Visit <code>https://your-domain/setup.php</code> in your browser to create the superadmin login. Once complete, delete <code>setup.php</code> as recommended.
          </li>
          <li>
            <strong>Connect Messenger Webhook:</strong> In your Meta Developer app, enter <code>https://your-domain/webhook.php</code> and your verify token to activate 24/7 automated support!
          </li>
        </ol>
      </div>
    </div>
  );
};
