export type NodeType = 'start' | 'message' | 'menu' | 'input' | 'carousel' | 'agent_handoff' | 'end';

export interface FlowOption {
  id: string;
  label: string;
  destinationNodeId: string;
  payload?: string;
  type?: 'postback' | 'url' | 'phone';
  url?: string;
  phoneNumber?: string;
}

export interface CarouselCard {
  id: string;
  title: string;
  subtitle: string;
  imageUrl?: string;
  defaultActionUrl?: string;
  buttons: {
    label: string;
    type: 'postback' | 'url' | 'phone';
    payload?: string;
    url?: string;
    destinationNodeId?: string;
  }[];
}

export interface FlowNode {
  id: string;
  nodeKey: string;
  nodeName: string;
  nodeType: NodeType;
  responseText: string;
  isStart?: boolean;
  isActive: boolean;
  options: FlowOption[];
  carouselCards?: CarouselCard[];
  inputConfig?: {
    fieldToCapture: 'name' | 'email' | 'phone' | 'inquiry' | 'ticket_id' | 'custom';
    customFieldName?: string;
    validationRegex?: string;
    validationErrorMessage?: string;
    destinationNodeIdOnSuccess: string;
  };
}

export interface FlowVersion {
  id: string;
  versionName: string;
  status: 'draft' | 'published';
  publishedAt?: string;
  nodes: FlowNode[];
}

export type KeywordMatchType = 'exact' | 'contains' | 'starts_with' | 'regex';

export interface KeywordTrigger {
  id: string;
  keyword: string; // comma separated or single
  matchType: KeywordMatchType;
  priority: number;
  destinationNodeId: string;
  customResponseText?: string;
  category: 'general' | 'pricing' | 'hours' | 'support' | 'leads' | 'custom';
  isEnabled: boolean;
  notes?: string;
}

export interface CannedResponse {
  id: string;
  title: string;
  category: string;
  text: string;
  quickReplies?: string[];
  tags: string[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot' | 'agent';
  text: string;
  timestamp: string;
  options?: FlowOption[];
  carouselCards?: CarouselCard[];
  nodeKey?: string;
  matchedTrigger?: string;
}

export interface ConversationSession {
  id: string;
  userId: string;
  userName: string;
  avatarUrl?: string;
  currentNodeId: string;
  currentInputStep?: string;
  collectedData: Record<string, string>;
  status: 'active_bot' | 'human_takeover' | 'resolved';
  lastActivity: string;
  messages: ChatMessage[];
  unreadCount?: number;
}

export interface Lead {
  id: string;
  sessionId: string;
  fullName: string;
  email: string;
  phone: string;
  inquiry: string;
  capturedAt: string;
  status: 'new' | 'contacted' | 'resolved' | 'archived';
  notes?: string;
}

export interface BotSettings {
  pageName: string;
  pageId: string;
  pageAccessToken: string;
  verifyToken: string;
  appSecret: string;
  businessHoursEnabled: boolean;
  businessHoursStart: string; // e.g. "09:00"
  businessHoursEnd: string; // e.g. "18:00"
  businessDays: number[]; // 1 = Monday, 7 = Sunday
  businessTimezone: string;
  offlineMessage: string;
  fallbackMessage: string;
  persistentMenuEnabled: boolean;
  persistentMenuItems: {
    label: string;
    destinationNodeId?: string;
    url?: string;
    type: 'postback' | 'url';
  }[];
  icebreakers: string[];
}

export interface ProductItem {
  id: string;
  name: string;
  category: string;
  price: number;
  currency: string;
  description: string;
  imageUrl?: string;
  sku?: string;
  stockStatus: 'in_stock' | 'out_of_stock' | 'preorder' | 'available';
  features: string[];
  actionButtonLabel: string;
  actionType: 'node_handoff' | 'lead_capture' | 'url';
  actionPayloadOrUrl?: string;
  createdAt: string;
}

export interface AIPromptConfig {
  businessType: string;
  businessTone: 'professional' | 'friendly' | 'persuasive' | 'concise';
  botGoal: 'sales_and_orders' | 'lead_generation' | 'support_and_faq' | 'appointment_booking';
  includeWelcome: boolean;
  includeKeywords: boolean;
  selectedProductIds: string[];
  customInstructions?: string;
}
