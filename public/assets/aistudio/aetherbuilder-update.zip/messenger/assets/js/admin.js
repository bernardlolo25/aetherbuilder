/**
 * Client-side script for Production Single Host PHP Admin Dashboard
 * Manages Dark/Light theme presets, copy-to-clipboard, and CSV exports
 */

(function () {
  'use strict';

  function initTheme() {
    const savedTheme = localStorage.getItem('fb_admin_theme') || 
      (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    applyTheme(savedTheme);

    // Bind to all theme-toggle elements
    document.querySelectorAll('.theme-toggle, .btn-theme-toggle').forEach(btn => {
      btn.addEventListener('click', function () {
        const current = document.documentElement.getAttribute('data-theme') || 'light';
        const next = current === 'dark' ? 'light' : 'dark';
        applyTheme(next);
      });
    });
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    document.body.setAttribute('data-theme', theme);
    localStorage.setItem('fb_admin_theme', theme);

    document.querySelectorAll('.theme-toggle, .btn-theme-toggle').forEach(btn => {
      btn.innerHTML = theme === 'dark' ? '☀️ Light Mode' : '🌙 Dark Mode';
    });
  }

  // Copy to clipboard helper
  window.copyToClipboard = function (text, btnElement) {
    if (!navigator.clipboard) {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      showCopiedFeedback(btnElement);
      return;
    }

    navigator.clipboard.writeText(text).then(function () {
      showCopiedFeedback(btnElement);
    }).catch(function () {
      showCopiedFeedback(btnElement);
    });
  };

  function showCopiedFeedback(btn) {
    if (!btn) return;
    const origText = btn.innerText;
    btn.innerText = '✓ Copied!';
    btn.style.backgroundColor = '#10b981';
    setTimeout(function () {
      btn.innerText = origText;
      btn.style.backgroundColor = '';
    }, 2000);
  }

  window.exportTableToCSV = function (tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;

    let csv = [];
    const rows = table.querySelectorAll('tr');

    for (let i = 0; i < rows.length; i++) {
      let row = [], cols = rows[i].querySelectorAll('td, th');
      for (let j = 0; j < cols.length; j++) {
        if (cols[j].classList.contains('no-export')) continue;
        let text = cols[j].innerText.replace(/"/g, '""').trim();
        row.push('"' + text + '"');
      }
      if (row.length > 0) csv.push(row.join(','));
    }

    const csvBlob = new Blob([csv.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(csvBlob);
    link.download = filename || 'leads-export.csv';
    link.click();
  };

  // 1-CLICK DUAL-MODE AUTO-UPDATER (Client Download Proxy + Safety Backup)
  // 1-CLICK DUAL-MODE AUTO-UPDATER (Client Download Proxy + Safety Backup + Local Archive Scan)
  // =========================================================================================
  window.startQuickUpdate = async function (targetVersion, downloadUrl, token) {
    const modal = document.getElementById('quick-update-modal');
    const progressBar = document.getElementById('quick-update-progress-bar');
    const statusText = document.getElementById('quick-update-status-text');

    if (modal) {
      modal.style.display = 'flex';
    }

    function setProgress(pct, msg, isError) {
      if (progressBar) {
        progressBar.style.width = pct + '%';
        if (isError) {
          progressBar.style.background = '#ef4444';
        } else if (pct >= 100) {
          progressBar.style.background = 'linear-gradient(90deg, #10b981, #34d399)';
        } else {
          progressBar.style.background = 'linear-gradient(90deg, #2563eb, #3b82f6)';
        }
      }
      if (statusText) {
        statusText.innerHTML = msg;
      }
    }

    async function safeParseJson(res) {
      const text = await res.text();
      try {
        return JSON.parse(text);
      } catch (e) {
        const clean = text.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
        const snippet = clean.length > 250 ? clean.substring(0, 250) + '...' : clean;
        return {
          success: false,
          error: (res.status && res.status !== 200 ? `[HTTP ${res.status}] ` : '') + (snippet || 'Server returned invalid non-JSON output.')
        };
      }
    }

    function showManualUploadOption(notice) {
      setProgress(100, `<span style="color:#ef4444; font-weight:bold;">Notice:</span> ${notice}`, true);
      if (modal && !document.getElementById('manual-upload-fallback-btn')) {
        const fallbackDiv = document.createElement('div');
        fallbackDiv.id = 'manual-upload-fallback-btn';
        fallbackDiv.style.marginTop = '14px';
        fallbackDiv.style.textAlign = 'center';
        fallbackDiv.innerHTML = `
          <p style="font-size:12px; color:var(--text-muted); margin-bottom:8px;">
            Firewall bypass: Select your <code>update.zip</code> or release package to extract with 100% database preservation:
          </p>
          <label class="btn btn-primary btn-sm" style="cursor:pointer; display:inline-flex; align-items:center; gap:6px;">
            📁 Select Update ZIP from Device
            <input type="file" accept=".zip" style="display:none;" id="modal-file-input">
          </label>
          <a href="updates.php" class="btn btn-outline btn-sm" style="margin-left:8px;">View Updates Page</a>
        `;
        const modalBody = modal.querySelector('.modal-body') || modal.querySelector('.update-modal-body') || modal;
        modalBody.appendChild(fallbackDiv);

        const fileInput = document.getElementById('modal-file-input');
        if (fileInput) {
          fileInput.addEventListener('change', async function (e) {
            const file = e.target.files[0];
            if (!file) return;
            window.applyUpdateZipFile(file, targetVersion);
          });
        }
      }
    }

    setProgress(15, '<span class="status-pulse" style="background:#3b82f6;"></span> Step 1/3: Verifying system environment & local archives...');

    try {
      // 1. Check if a local update zip already exists on server (Fastest & Zero outbound network)
      try {
        const scanForm = new FormData();
        scanForm.append('action', 'install');
        scanForm.append('version', targetVersion || '');
        scanForm.append('download_url', ''); // empty download_url instructs server to only scan local archives

        const scanRes = await fetch('updater-api.php', { method: 'POST', body: scanForm });
        const scanData = await safeParseJson(scanRes);
        if (scanData && scanData.success && scanData.mode === 'local_archive') {
          setProgress(100, `🎉 <strong>Update Succeeded!</strong> Extracted ${scanData.source || 'local archive'} with zero data loss. Reloading in 1.8s...`);
          setTimeout(function () {
            window.location.href = scanData.redirect || ('dashboard.php?updated=1&v=' + encodeURIComponent(targetVersion || ''));
          }, 1800);
          return;
        }
      } catch (scanErr) {
        console.warn('Local scan notice:', scanErr);
      }

      // 2. Dual Install Pipeline: Try Mode A (Client Download Proxy)
      let zipBlob = null;
      if (downloadUrl) {
        setProgress(35, '<span class="status-pulse" style="background:#3b82f6;"></span> Step 2/3: Client downloading update package (bypassing host firewall)...');
        try {
          const fetchHeaders = { 'Accept': 'application/octet-stream' };
          if (token) fetchHeaders['Authorization'] = 'token ' + token;

          const blobRes = await fetch(downloadUrl, { headers: fetchHeaders, mode: 'cors' });
          if (blobRes.ok) {
            zipBlob = await blobRes.blob();
          }
        } catch (fetchErr) {
          console.warn('Client direct fetch note (CORS or network):', fetchErr);
        }
      }

      // Mode A: Upload downloaded blob to updater-api.php
      if (zipBlob && zipBlob.size > 1000) {
        setProgress(70, '<span class="status-pulse" style="background:#10b981;"></span> Step 3/3: Uploading package, creating safety backup & preserving credentials...');
        const uploadForm = new FormData();
        uploadForm.append('action', 'upload_update_zip');
        uploadForm.append('version', targetVersion || '');
        uploadForm.append('update_zip', zipBlob, 'update_' + (targetVersion || 'pkg') + '.zip');

        const uploadRes = await fetch('updater-api.php', {
          method: 'POST',
          body: uploadForm
        });
        const data = await safeParseJson(uploadRes);

        if (data && data.success) {
          setProgress(100, '🎉 <strong>Update Complete!</strong> Preserved credentials safely. Reloading in 1.8s...');
          setTimeout(function () {
            window.location.href = data.redirect || ('dashboard.php?updated=1&v=' + encodeURIComponent(data.new_version || targetVersion));
          }, 1800);
          return;
        } else {
          showManualUploadOption(data ? (data.error || 'Extraction failed') : 'Upload failed');
          return;
        }
      }

      // Mode B: If client direct download was blocked by browser CORS / network, prompt file upload immediately
      showManualUploadOption('Outbound download blocked by web host firewall or CORS. Please select or upload the update ZIP file directly to proceed with zero downtime.');

    } catch (err) {
      showManualUploadOption('Network issue: ' + (err.message || 'Connection lost'));
    }
  };

  // Dedicated helper to stream any selected ZIP file directly to updater-api.php
  window.applyUpdateZipFile = async function (file, targetVersion) {
    const modal = document.getElementById('quick-update-modal');
    const progressBar = document.getElementById('quick-update-progress-bar');
    const statusText = document.getElementById('quick-update-status-text');

    if (modal) {
      modal.style.display = 'flex';
    }

    function setProgress(pct, msg, isError) {
      if (progressBar) {
        progressBar.style.width = pct + '%';
        if (isError) {
          progressBar.style.background = '#ef4444';
        } else if (pct >= 100) {
          progressBar.style.background = 'linear-gradient(90deg, #10b981, #34d399)';
        } else {
          progressBar.style.background = 'linear-gradient(90deg, #2563eb, #3b82f6)';
        }
      }
      if (statusText) statusText.innerHTML = msg;
    }

    async function safeParseJson(res) {
      const text = await res.text();
      try {
        return JSON.parse(text);
      } catch (e) {
        const clean = text.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
        return { success: false, error: clean || 'Server returned invalid response.' };
      }
    }

    setProgress(35, `<span class="status-pulse" style="background:#3b82f6;"></span> Uploading ${file.name} (${Math.round(file.size / 1024)} KB)...`);

    const form = new FormData();
    form.append('action', 'upload_update_zip');
    form.append('version', targetVersion || '1.5.7');
    form.append('update_zip', file, file.name);

    try {
      setProgress(65, '<span class="status-pulse" style="background:#10b981;"></span> Creating safety backup & preserving config/config.php credentials...');
      const res = await fetch('updater-api.php', { method: 'POST', body: form });
      const data = await safeParseJson(res);

      if (data && data.success) {
        setProgress(100, `🎉 <strong>Update Succeeded!</strong> Upgraded to v${data.new_version || targetVersion}. Reloading in 1.8s...`);
        setTimeout(function () {
          window.location.href = data.redirect || 'dashboard.php?updated=1';
        }, 1800);
      } else {
        setProgress(100, '<span style="color:#ef4444; font-weight:bold;">Extraction Error:</span> ' + (data ? data.error : 'Unknown server error'), true);
      }
    } catch (e) {
      setProgress(100, '<span style="color:#ef4444; font-weight:bold;">Upload Error:</span> ' + e.message, true);
    }
  };

  // Bind page-level ZIP upload and scan triggers
  function initPageUpdateTools() {
    const pageFileInput = document.getElementById('page-zip-upload-input');
    const dropZone = document.getElementById('zip-drop-zone');
    const scanBtn = document.getElementById('btn-scan-server-archive');

    if (pageFileInput) {
      pageFileInput.addEventListener('change', function (e) {
        const file = e.target.files[0];
        if (file) {
          window.applyUpdateZipFile(file, pageFileInput.getAttribute('data-version') || '1.5.7');
        }
      });
    }

    if (dropZone) {
      ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
          e.preventDefault();
          dropZone.style.borderColor = '#2563eb';
          dropZone.style.background = 'rgba(37, 99, 235, 0.08)';
        }, false);
      });

      ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, (e) => {
          e.preventDefault();
          dropZone.style.borderColor = '';
          dropZone.style.background = '';
        }, false);
      });

      dropZone.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        const files = dt.files;
        if (files && files.length > 0) {
          window.applyUpdateZipFile(files[0], '1.5.7');
        }
      });
    }

    if (scanBtn) {
      scanBtn.addEventListener('click', async function () {
        const scanStatus = document.getElementById('scan-archive-status');
        if (scanStatus) scanStatus.innerHTML = '🔍 Scanning server root for update.zip...';
        try {
          const scanForm = new FormData();
          scanForm.append('action', 'install');
          scanForm.append('version', scanBtn.getAttribute('data-version') || '1.5.7');
          scanForm.append('download_url', '');

          const res = await fetch('updater-api.php', { method: 'POST', body: scanForm });
          const text = await res.text();
          let data = null;
          try { data = JSON.parse(text); } catch (e) { data = { success: false, error: text }; }

          if (data && data.success) {
            if (scanStatus) scanStatus.innerHTML = '🎉 <strong>Found and extracted ' + (data.source || 'update.zip') + '!</strong> Reloading in 1.8s...';
            setTimeout(() => window.location.href = data.redirect || 'dashboard.php?updated=1', 1800);
          } else {
            if (scanStatus) scanStatus.innerHTML = '<span style="color:#ef4444;">No local archive found.</span> Upload <code>update.zip</code> to your root folder via FTP or use the file picker above.';
          }
        } catch (err) {
          if (scanStatus) scanStatus.innerHTML = '<span style="color:#ef4444;">Scan error:</span> ' + err.message;
        }
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      initTheme();
      initPageUpdateTools();
    });
  } else {
    initTheme();
    initPageUpdateTools();
  }

})();
