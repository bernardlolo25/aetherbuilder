<?php
/**
 * Facebook Messenger 24/7 Automated Webhook
 * Configured for: https://uspf-mcle.ct.ws/messenger/webhook.php
 * Database: if0_43065915_messenger_bot @ sql309.infinityfree.com
 * 100% Rule-based: No AI integration.
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/send_api.php';

header('Content-Type: text/plain; charset=utf-8');

$pdo = db();

// Fetch verify token from bot_settings or fallback to ADMIN_SETUP_KEY
$tokenStmt = $pdo->prepare("SELECT setting_value FROM bot_settings WHERE setting_key = 'verify_token' LIMIT 1");
$tokenStmt->execute();
$dbToken = $tokenStmt->fetchColumn();

$verifyToken = $dbToken ?: (defined('ADMIN_SETUP_KEY') ? ADMIN_SETUP_KEY : 'AetherBuilder_Messenger_Verify_8K3mN5pQ7rT1vX9zC4wL2hF6dJ8sB0');

// Fetch Page Access Token
$pageStmt = $pdo->prepare("SELECT setting_value FROM bot_settings WHERE setting_key = 'page_access_token' LIMIT 1");
$pageStmt->execute();
$pageAccessToken = $pageStmt->fetchColumn() ?: '';

function logWebhookTraffic($pdo, $direction, $eventType, $senderId, $payload, $statusCode = 200, $summary = '') {
    try {
        $stmt = $pdo->prepare("INSERT INTO webhook_traffic_logs (direction, event_type, sender_id, payload_snippet, status_code, response_summary) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$direction, $eventType, $senderId, substr((string)$payload, 0, 500), $statusCode, substr((string)$summary, 0, 250)]);
    } catch (Throwable $e) {}
}

// ==============================================================
// 1. META WEBHOOK VERIFICATION (GET)
// ==============================================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $hubMode = $_GET['hub_mode'] ?? '';
    $hubVerifyToken = $_GET['hub_verify_token'] ?? '';
    $hubChallenge = $_GET['hub_challenge'] ?? '';

    if ($hubMode === 'subscribe' && $hubVerifyToken === $verifyToken) {
        logWebhookTraffic($pdo, 'incoming', 'verification', 'Meta_Webhook_Probe', "hub.mode=subscribe&token={$hubVerifyToken}", 200, 'HTTP 200 OK — Verified');
        http_response_code(200);
        echo $hubChallenge;
        exit;
    }

    logWebhookTraffic($pdo, 'incoming', 'verification', 'Unknown_Probe', "Invalid token: {$hubVerifyToken}", 403, 'HTTP 403 Forbidden: Invalid Token');
    http_response_code(403);
    echo 'Forbidden: Invalid verify token.';
    exit;
}

// ==============================================================
// 2. INCOMING MESSENGER WEBHOOK EVENTS (POST)
// ==============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true);

    if (empty($data['object']) || $data['object'] !== 'page' || empty($data['entry'])) {
        http_response_code(400);
        exit('Invalid webhook payload format.');
    }

    http_response_code(200);
    echo 'EVENT_RECEIVED';

    foreach ($data['entry'] as $entry) {
        if (empty($entry['messaging'])) continue;

        foreach ($entry['messaging'] as $event) {
            $senderId = $event['sender']['id'] ?? null;
            if (!$senderId) continue;

            $messageText = '';
            $payload = null;

            if (!empty($event['message']['text'])) {
                $messageText = trim($event['message']['text']);
            }
            if (!empty($event['message']['quick_reply']['payload'])) {
                $payload = $event['message']['quick_reply']['payload'];
            }
            if (!empty($event['postback']['payload'])) {
                $payload = $event['postback']['payload'];
            }

            if ($messageText === '' && empty($payload)) continue;

            logWebhookTraffic($pdo, 'incoming', $payload ? 'postback' : 'message', $senderId, $messageText ?: ($payload ? "Payload: {$payload}" : ''));
            handleIncomingCustomerMessage($pdo, $senderId, $messageText, $payload, $pageAccessToken);
        }
    }

    exit;
}

/**
 * Core Rule Engine for incoming Messenger conversations
 * Uses: conversations, flow_nodes, flow_options, keyword_triggers, messages, leads
 */
/**
 * Dynamically replace customer placeholders: {first_name}, {name}, {last_name}
 */
function replace_message_placeholders(string $text, array $profile = []): string {
    $firstName = !empty($profile['first_name']) ? $profile['first_name'] : (!empty($profile['name']) ? explode(' ', $profile['name'])[0] : 'there');
    $fullName  = !empty($profile['name']) ? $profile['name'] : (!empty($profile['first_name']) ? $profile['first_name'] : 'there');
    $lastName  = !empty($profile['last_name']) ? $profile['last_name'] : '';

    $map = [
        '{first_name}'   => $firstName,
        '{{first_name}}' => $firstName,
        '{name}'         => $fullName,
        '{{name}}'       => $fullName,
        '{last_name}'    => $lastName,
        '{{last_name}}'  => $lastName,
    ];

    return str_ireplace(array_keys($map), array_values($map), $text);
}

function handleIncomingCustomerMessage(PDO $pdo, string $senderId, string $userText, ?string $payload, string $pageAccessToken): void {
    // 1. Find or create conversation session
    $stmt = $pdo->prepare("SELECT * FROM conversations WHERE page_scoped_id = ? LIMIT 1");
    $stmt->execute([$senderId]);
    $conv = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$conv) {
        $startNode = $pdo->query("SELECT id FROM flow_nodes WHERE is_start = 1 AND is_active = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);
        $startId = $startNode ? (int)$startNode['id'] : 1;

        $ins = $pdo->prepare("INSERT INTO conversations (page_scoped_id, current_node_id, flow_version_id, conversation_status, human_takeover, last_interaction) VALUES (?, ?, 1, 'active', 0, NOW())");
        $ins->execute([$senderId, $startId]);
        $convId = (int)$pdo->lastInsertId();
        $humanTakeover = 0;
    } else {
        $convId = (int)$conv['id'];
        $humanTakeover = (int)$conv['human_takeover'];
    }

    // 2. Log incoming message
    $logStmt = $pdo->prepare("INSERT INTO messages (conversation_id, direction, message_text, message_type) VALUES (?, 'incoming', ?, 'text')");
    $logStmt->execute([$convId, $userText ?: ($payload ? "Selected: {$payload}" : '')]);

    // 2. Profile Cache & Personalization ({first_name}, {name})
    $context = [];
    if (!empty($conv['context_data'])) {
        $context = json_decode((string)$conv['context_data'], true) ?: [];
    }
    if ((empty($context['first_name']) && empty($context['name'])) && !empty($pageAccessToken)) {
        $profile = fb_get_user_profile($pageAccessToken, $senderId);
        if (!empty($profile['first_name']) || !empty($profile['name'])) {
            $context = array_merge($context, $profile);
            try {
                $pdo->prepare("UPDATE conversations SET context_data = ? WHERE id = ?")->execute([json_encode($context), $convId]);
            } catch (\Throwable $e) {}
        }
    }
    $customerName = !empty($context['name']) ? $context['name'] : (!empty($context['first_name']) ? $context['first_name'] : 'Messenger Customer');

    // 2b. Opt-out / Compliance Guard: Handle STOP, PAUSE, START
    $lowerText = strtolower(trim($userText));
    if (in_array($lowerText, ['stop', 'unsubscribe', 'pause', 'mute'], true)) {
        try {
            $pdo->prepare("UPDATE conversations SET human_takeover = 1, last_interaction = NOW() WHERE id = ?")->execute([$convId]);
            $stopMsg = "Bot automation has been paused for this conversation. A human representative will assist you if needed.\n\nType 'START' or 'MENU' anytime to resume automated assistance.";
            $pdo->prepare("INSERT INTO messages (conversation_id, direction, message_text, message_type) VALUES (?, 'outgoing', ?, 'text')")->execute([$convId, $stopMsg]);
            if (!empty($pageAccessToken)) {
                fb_send_message($pageAccessToken, $senderId, $stopMsg);
            }
        } catch (\Throwable $e) {}
        return;
    }
    if (in_array($lowerText, ['start', 'restart', 'resume', 'unpause'], true)) {
        $humanTakeover = 0;
        try {
            $pdo->prepare("UPDATE conversations SET human_takeover = 0, last_interaction = NOW() WHERE id = ?")->execute([$convId]);
        } catch (\Throwable $e) {}
    }


    // If human agent has taken over and user didn't ask to reset
    if ($humanTakeover === 1 && empty($payload) && !in_array(strtolower($userText), ['restart', 'menu', 'reset'], true)) {
        return;
    }

    // 3. Show typing indicator
    if (!empty($pageAccessToken)) {
        fb_send_action($pageAccessToken, $senderId, 'typing_on');
    }

    $targetNodeId = null;

    // A. Special: Check if customer clicked an "Order Now" button on a product card
    if (!empty($payload) && strpos($payload, 'PAYLOAD_ORDER_') === 0) {
        $orderedProdId = (int)str_replace('PAYLOAD_ORDER_', '', $payload);
        $prodStmt = $pdo->prepare("SELECT * FROM products WHERE id = ? LIMIT 1");
        $prodStmt->execute([$orderedProdId]);
        $orderedProd = $prodStmt->fetch(PDO::FETCH_ASSOC);

        $prodName = $orderedProd ? $orderedProd['name'] : 'Product #' . $orderedProdId;
        $prodPrice = $orderedProd ? ($orderedProd['currency'] . ' ' . number_format((float)$orderedProd['price'], 2)) : '';

        // Find lead input node or fallback to current
        $inputNode = $pdo->query("SELECT id FROM flow_nodes WHERE node_type = 'input' LIMIT 1")->fetch(PDO::FETCH_ASSOC);
        $nextId = $inputNode ? (int)$inputNode['id'] : (int)$conv['current_node_id'];

        // Automatically record lead inquiry with product details
        try {
            $insLead = $pdo->prepare("INSERT INTO leads (conversation_id, page_scoped_id, full_name, notes, lead_status) VALUES (?, ?, ?, ?, 'new')");
            $insLead->execute([$convId, $senderId, $customerName, "Inquired / Clicked Order for: {$prodName} ({$prodPrice})"]);
        } catch (Throwable $e) {}

        $orderGreeting = !empty($context['first_name']) ? "Thank you, {$context['first_name']}!" : "🎉 Excellent choice!";
        $orderReplyText = "{$orderGreeting} We received your inquiry for \"{$prodName}\" ({$prodPrice}).\n\nPlease type your Full Name, Email, or Phone below so our team can confirm your order:";

        $pdo->prepare("UPDATE conversations SET current_node_id = ?, last_interaction = NOW() WHERE id = ?")->execute([$nextId, $convId]);
        $pdo->prepare("INSERT INTO messages (conversation_id, direction, message_text, message_type) VALUES (?, 'outgoing', ?, 'text')")->execute([$convId, $orderReplyText]);

        if (!empty($pageAccessToken)) {
            $quickReps = [
                ['content_type' => 'text', 'title' => '🏠 Main Menu', 'payload' => 'PAYLOAD_MENU'],
                ['content_type' => 'text', 'title' => '💬 Talk to Agent', 'payload' => 'PAYLOAD_AGENT']
            ];
            fb_send_message($pageAccessToken, $senderId, $orderReplyText, $quickReps);
        }
        return;
    }

    // B. Standard Payload / Quick reply matching
    if (!empty($payload)) {
        $optStmt = $pdo->prepare("SELECT destination_node_id FROM flow_options WHERE option_payload = ? LIMIT 1");
        $optStmt->execute([$payload]);
        $targetOpt = $optStmt->fetch(PDO::FETCH_ASSOC);
        if ($targetOpt && !empty($targetOpt['destination_node_id'])) {
            $targetNodeId = (int)$targetOpt['destination_node_id'];
        }
    }

    // B. Keyword triggers evaluation (highest priority first)
    if (!$targetNodeId && $userText !== '') {
        $kwStmt = $pdo->query("SELECT * FROM keyword_triggers WHERE is_active = 1 ORDER BY priority DESC");
        $keywords = $kwStmt->fetchAll(PDO::FETCH_ASSOC);

        $cleanText = mb_strtolower(trim($userText));

        foreach ($keywords as $kwRow) {
            $matchType = $kwRow['match_type'];
            $rawKws = array_map('trim', explode(',', mb_strtolower($kwRow['keyword'])));

            foreach ($rawKws as $singleKw) {
                if ($singleKw === '') continue;
                $isMatch = false;

                if ($matchType === 'exact') {
                    $isMatch = ($cleanText === $singleKw);
                } elseif ($matchType === 'contains' || $matchType === 'phrase') {
                    $isMatch = (mb_strpos($cleanText, $singleKw) !== false);
                }

                if ($isMatch) {
                    $targetNodeId = (int)$kwRow['node_id'];
                    break 2;
                }
            }
        }
    }

    // C. Default Fallback or Start Node
    if (!$targetNodeId) {
        $startNode = $pdo->query("SELECT id FROM flow_nodes WHERE is_start = 1 AND is_active = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);
        $targetNodeId = $startNode ? (int)$startNode['id'] : 1;

        // Record into unmatched_queries for Analytics Learning Queue
        if (!empty($userText)) {
            try {
                $stmtUnmatched = $pdo->prepare("INSERT INTO unmatched_queries (query, hit_count, last_sender_psid, last_occurred_at) 
                    VALUES (?, 1, ?, NOW()) 
                    ON DUPLICATE KEY UPDATE hit_count = hit_count + 1, last_occurred_at = NOW()");
                $stmtUnmatched->execute([mb_substr($userText, 0, 250), $senderId]);
            } catch (Throwable $e) {}
        }
    }

    // 4. Fetch the target node details
    $nodeStmt = $pdo->prepare("SELECT * FROM flow_nodes WHERE id = ? LIMIT 1");
    $nodeStmt->execute([$targetNodeId]);
    $node = $nodeStmt->fetch(PDO::FETCH_ASSOC);

    if (!$node) return;

    // Fetch options / buttons
    $optsStmt = $pdo->prepare("SELECT * FROM flow_options WHERE node_id = ? ORDER BY sort_order ASC");
    $optsStmt->execute([$node['id']]);
    $nodeOptions = $optsStmt->fetchAll(PDO::FETCH_ASSOC);

    $replyText = replace_message_placeholders($node['response_text'] ?? '', $context);

    // If node is an inquiry/lead capture node, automatically record in leads table
    if ($node['node_type'] === 'input' && $userText !== '') {
        $leadCheck = $pdo->prepare("SELECT id FROM leads WHERE page_scoped_id = ? LIMIT 1");
        $leadCheck->execute([$senderId]);
        if (!$leadCheck->fetchColumn()) {
            $insLead = $pdo->prepare("INSERT INTO leads (conversation_id, page_scoped_id, full_name, notes, lead_status) VALUES (?, ?, ?, ?, 'new')");
            $insLead->execute([$convId, $senderId, $customerName, $userText]);
        }
    }

    // Update conversation record
    $upd = $pdo->prepare("UPDATE conversations SET current_node_id = ?, last_interaction = NOW() WHERE id = ?");
    $upd->execute([$node['id'], $convId]);

    // Log outgoing message
    $logBot = $pdo->prepare("INSERT INTO messages (conversation_id, direction, message_text, message_type) VALUES (?, 'outgoing', ?, 'text')");
    $logBot->execute([$convId, $replyText]);

    // Send reply via Meta Send API
    if (!empty($pageAccessToken)) {
        // ── Web URL Button: options whose payload is an http(s) URL
        // These become native Messenger web_url buttons (opens site in-app immediately).
        // Remaining options become standard quick replies.
        $quickReplies  = [];
        $urlButtons    = [];
        foreach ($nodeOptions as $opt) {
            $optPayload = $opt['option_payload'] ?? '';
            if (preg_match('#^https?://#i', $optPayload)) {
                // This option is a direct URL — build a web_url button
                $urlButtons[] = [
                    'type'    => 'web_url',
                    'url'     => $optPayload,
                    'title'   => mb_substr($opt['option_label'], 0, 20),
                    'webview_height_ratio' => 'full',
                ];
            } else {
                $quickReplies[] = [
                    'content_type' => 'text',
                    'title'   => mb_substr($opt['option_label'], 0, 20),
                    'payload' => $optPayload ?: ('PAYLOAD_' . $opt['id']),
                ];
            }
        }

        // Check if customer requested Product Catalog / Carousel
        $isCatalogRequest = (
            $node['node_type'] === 'carousel' ||
            $payload === 'PAYLOAD_CATALOG' ||
            in_array($node['node_key'], ['catalog', 'ecom_catalog', 'product_showcase', 'products_menu'], true) ||
            preg_match('/\b(catalog|products|services|packages|courses|shop|store|buy)\b/i', $userText)
        );

        if ($isCatalogRequest) {
            $catalogItems = [];
            try {
                $catalogItems = $pdo->query("SELECT * FROM products WHERE is_active = 1 ORDER BY sort_order ASC, id ASC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
                if (empty($catalogItems)) {
                    $catalogItems = $pdo->query("SELECT * FROM products ORDER BY id ASC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
                }
            } catch (Throwable $e) {}

            if (!empty($catalogItems)) {
                $elements = [];
                foreach ($catalogItems as $item) {
                    $imgUrl = get_product_public_image_url($item);
                    $currSym = $item['currency'] === 'USD' ? '$' : ($item['currency'] === 'PHP' ? '₱' : $item['currency'] . ' ');
                    $priceStr = $currSym . number_format((float)$item['price'], 2);
                    $descStr = !empty($item['description']) ? mb_substr($item['description'], 0, 65) : 'Available now';
                    $subTitle = "{$priceStr} • {$descStr}";

                    $btnLabel = !empty($item['action_label']) ? mb_substr($item['action_label'], 0, 20) : 'Order Now';

                    $elem = [
                        'title' => mb_substr($item['name'], 0, 80),
                        'subtitle' => mb_substr($subTitle, 0, 80),
                        'buttons' => [
                            [
                                'type' => 'postback',
                                'title' => "🛒 {$btnLabel}",
                                'payload' => 'PAYLOAD_ORDER_' . $item['id']
                            ]
                        ]
                    ];

                    if (!empty($imgUrl)) {
                        $elem['image_url'] = $imgUrl;
                    }
                    $elements[] = $elem;
                }

                if (!empty($elements)) {
                    // Send optional introductory text
                    fb_send_message($pageAccessToken, $senderId, "🛍️ Here are our featured products and services. Swipe to view photos, prices, and tap to order:");
                    // Send Generic Template Carousel with product photos
                    fb_send_generic_template($pageAccessToken, $senderId, $elements, $quickReplies);
                    return;
                }
            }
        }

        // Standard text reply — with web_url buttons OR quick replies
        if (!empty($urlButtons)) {
            // Send as button template: tapping opens the URL directly in Messenger in-app browser
            fb_send_button_template($pageAccessToken, $senderId, $replyText, $urlButtons);
            // If there are ALSO quick replies, send a follow-up with them
            if (!empty($quickReplies)) {
                fb_send_message($pageAccessToken, $senderId, '📌 Or choose an option:', $quickReplies);
            }
        } else {
            // Standard text reply with quick reply chips
            fb_send_message($pageAccessToken, $senderId, $replyText, $quickReplies);
        }
    }
}
