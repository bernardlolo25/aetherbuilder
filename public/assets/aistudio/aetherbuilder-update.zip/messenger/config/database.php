<?php
require_once __DIR__ . '/config.php';

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    try {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 10,
        ]);
        return $pdo;
    } catch (PDOException $e) {
        http_response_code(500);
        die('<div style="font-family:system-ui,-apple-system,sans-serif;max-width:620px;margin:50px auto;padding:24px;border:1px solid #fecaca;border-radius:12px;background:#fff1f2;color:#991b1b;box-shadow:0 4px 12px rgba(0,0,0,0.06);">' .
            '<h2 style="margin-top:0;font-size:18px;">⚠️ Database Connection Notice</h2>' .
            '<p style="font-size:14px;line-height:1.5;">Could not connect to MySQL database: <strong>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</strong></p>' .
            '<div style="font-size:13px;background:white;padding:12px;border-radius:6px;border:1px solid #fee2e2;color:#374151;margin-top:12px;">' .
            '<strong>Host:</strong> ' . htmlspecialchars(DB_HOST, ENT_QUOTES, 'UTF-8') . '<br>' .
            '<strong>Database:</strong> ' . htmlspecialchars(DB_NAME, ENT_QUOTES, 'UTF-8') . '<br>' .
            '<strong>User:</strong> ' . htmlspecialchars(DB_USER, ENT_QUOTES, 'UTF-8') . '<br>' .
            '</div>' .
            '<p style="font-size:12px;color:#6b7280;margin-top:12px;">Check your credentials in <code>config/config.php</code> or ensure MySQL database is activated in your hosting control panel.</p>' .
            '</div>');
    }
}
