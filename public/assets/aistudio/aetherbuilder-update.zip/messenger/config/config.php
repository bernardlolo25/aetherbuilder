<?php
/**
 * Single-Host Database & App Configuration
 * Generated for: https://uspf-mcle.ct.ws/messenger
 */

// Error reporting — suppress output on production (errors go to server log only)
@ini_set('display_errors', '0');
@ini_set('log_errors', '1');
@error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);

// MySQL Hostname & Credentials for Production Database
define('DB_HOST', 'sql309.infinityfree.com');
define('DB_NAME', 'if0_43065915_messenger_bot');
define('DB_USER', 'if0_43065915');
define('DB_PASS', 'peRlm46G9qB');

// Admin Setup Secret & Facebook Messenger Verify Token
define('ADMIN_SETUP_KEY', 'AetherBuilder_Messenger_Verify_8K3mN5pQ7rT1vX9zC4wL2hF6dJ8sB0');

// Application Details
define('APP_NAME', 'Chat Assistant Bot');
define('APP_BASE_URL', 'https://uspf-mcle.ct.ws/messenger');
define('APP_VERSION', '1.6.0');
define('GITHUB_REPO', 'bernardlolo25/Chat-Asistant-Bot');
define('GITHUB_BRANCH', 'main');
define('GITHUB_TOKEN', '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');

