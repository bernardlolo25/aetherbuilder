<?php
/**
 * Bot Analytics, Insights & Unmatched Query Learning
 * Single-Host Architecture Compatible
 * Analyzes conversation metrics, lead conversion rates, and unanswered customer queries
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';
requireLogin();

$pdo = db();
$msg = '';
$error = '';

// Ensure unmatched_queries table exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS unmatched_queries (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        query VARCHAR(255) NOT NULL UNIQUE,
        hit_count INT NOT NULL DEFAULT 1,
        last_sender_psid VARCHAR(100) DEFAULT NULL,
        last_occurred_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
} catch (Throwable $e) {}

// Handle creating rule from unmatched query
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create_rule') {
        $queryText = trim($_POST['query_text'] ?? '');
        $nodeId = (int)($_POST['node_id'] ?? 0);
        $priority = (int)($_POST['priority'] ?? 12);
        $matchType = $_POST['match_type'] ?? 'contains';

        if ($queryText && $nodeId > 0) {
            try {
                $stmt = $pdo->prepare("INSERT INTO keyword_triggers (keyword, match_type, node_id, priority, is_active) VALUES (?, ?, ?, ?, 1)");
                $stmt->execute([$queryText, $matchType, $nodeId, $priority]);

                // Remove from unmatched
                $del = $pdo->prepare("DELETE FROM unmatched_queries WHERE query = ?");
                $del->execute([$queryText]);

                $msg = "🎉 Created new keyword trigger for '{$queryText}'! The bot will now automatically route this inquiry.";
            } catch (Throwable $e) {
                $error = "Failed to create trigger: " . $e->getMessage();
            }
        } else {
            $error = "Please specify a query and target destination node.";
        }
    } elseif ($action === 'dismiss_query') {
        $queryText = trim($_POST['query_text'] ?? '');
        if ($queryText) {
            $del = $pdo->prepare("DELETE FROM unmatched_queries WHERE query = ?");
            $del->execute([$queryText]);
            $msg = "Dismissed query from learning queue.";
        }
    } elseif ($action === 'seed_sample_analytics') {
        // Helpful button to populate demo queries if empty
        $samples = [
            ['query' => 'do you accept dental insurance', 'hits' => 14],
            ['query' => 'how much is international shipping', 'hits' => 9],
            ['query' => 'can i return items after 30 days', 'hits' => 7],
            ['query' => 'parking directions near your clinic', 'hits' => 5],
            ['query' => 'are pets allowed in your office', 'hits' => 3],
        ];
        foreach ($samples as $s) {
            $ins = $pdo->prepare("INSERT INTO unmatched_queries (query, hit_count, last_occurred_at) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE hit_count = ?");
            $ins->execute([$s['query'], $s['hits'], $s['hits']]);
        }
        $msg = "Populated learning queue with sample customer questions.";
    }
}

// Fetch Core KPIs
$totalConversations = 0;
$totalMessages = 0;
$incomingMessages = 0;
$outgoingMessages = 0;
$totalLeads = 0;
$humanTakeovers = 0;
$totalNodes = 0;
$totalKeywords = 0;

try {
    $totalConversations = (int)$pdo->query("SELECT COUNT(*) FROM conversations")->fetchColumn();
    $totalMessages = (int)$pdo->query("SELECT COUNT(*) FROM messages")->fetchColumn();
    $incomingMessages = (int)$pdo->query("SELECT COUNT(*) FROM messages WHERE direction = 'incoming'")->fetchColumn();
    $outgoingMessages = (int)$pdo->query("SELECT COUNT(*) FROM messages WHERE direction = 'outgoing'")->fetchColumn();
    $totalLeads = (int)$pdo->query("SELECT COUNT(*) FROM leads")->fetchColumn();
    $humanTakeovers = (int)$pdo->query("SELECT COUNT(*) FROM conversations WHERE human_takeover = 1")->fetchColumn();
    $totalNodes = (int)$pdo->query("SELECT COUNT(*) FROM flow_nodes")->fetchColumn();
    $totalKeywords = (int)$pdo->query("SELECT COUNT(*) FROM keyword_triggers WHERE is_active = 1")->fetchColumn();
} catch (Throwable $e) {}

// Conversion Rates
$leadConversionRate = $totalConversations > 0 ? round(($totalLeads / $totalConversations) * 100, 1) : 0;
$automatedResolutionRate = $totalConversations > 0 ? round((($totalConversations - $humanTakeovers) / $totalConversations) * 100, 1) : 100;

// Fetch Unmatched Queries
$unmatchedQueries = [];
try {
    $unmatchedQueries = $pdo->query("SELECT * FROM unmatched_queries ORDER BY hit_count DESC LIMIT 20")->fetchAll();
} catch (Throwable $e) {}

// Fetch Top Flow Nodes
$topNodes = [];
try {
    $topNodes = $pdo->query("SELECT n.id, n.node_name, n.node_key, n.node_type, COUNT(c.id) as visit_count 
        FROM flow_nodes n 
        LEFT JOIN conversations c ON c.current_node_id = n.id 
        GROUP BY n.id, n.node_name, n.node_key, n.node_type 
        ORDER BY visit_count DESC LIMIT 6")->fetchAll();
} catch (Throwable $e) {}

// Fetch All Flow Nodes for the dropdown selector
$allNodes = [];
try {
    $allNodes = $pdo->query("SELECT id, node_name, node_key FROM flow_nodes ORDER BY is_start DESC, node_name ASC")->fetchAll();
} catch (Throwable $e) {}

// Fetch Active Keyword Trigger hit performance
$activeKeywords = [];
try {
    $activeKeywords = $pdo->query("SELECT k.*, n.node_name FROM keyword_triggers k LEFT JOIN flow_nodes n ON k.node_id = n.id ORDER BY k.priority DESC LIMIT 10")->fetchAll();
} catch (Throwable $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bot Analytics &amp; Insights - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/app.css?v=1.4.3">
  <script src="../assets/js/admin.js?v=1.4.3" defer></script>
</head>
<body class="app-page">
  <?php renderAdminHeader('analytics'); ?>

  <main class="main-content">
    <header class="topbar">
      <div class="topbar-left">
        <span class="eyebrow">METRICS &amp; BOT LEARNING</span>
        <h1 class="page-title">Bot Analytics &amp; Conversion Insights</h1>
        <p class="page-subtitle">Track conversation volume, automated resolution rates, lead capture performance, and unanswered user questions.</p>
      </div>

      <div class="topbar-right">
        <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
          🌙 Dark Mode
        </button>
        <?php if (empty($unmatchedQueries)): ?>
          <form method="POST" action="analytics.php" style="margin: 0;">
            <input type="hidden" name="action" value="seed_sample_analytics">
            <button type="submit" class="btn btn-outline btn-sm">
              💡 Load Sample Inquiries
            </button>
          </form>
        <?php endif; ?>
        <a href="simulator.php" class="btn btn-primary btn-sm">
          📱 Test Simulator
        </a>
      </div>
    </header>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <!-- High-Level KPI Stat Grid -->
    <section class="stat-grid" style="margin-bottom: 1.5rem;">
      <div class="stat-card">
        <div class="stat-label">Total Conversations</div>
        <div class="stat-value"><?php echo $totalConversations; ?></div>
        <div class="stat-desc">Facebook customer threads</div>
      </div>

      <div class="stat-card stat-success">
        <div class="stat-label">Lead Conversion Rate</div>
        <div class="stat-value" style="color: #10b981;"><?php echo $leadConversionRate; ?>%</div>
        <div class="stat-desc"><?php echo $totalLeads; ?> verified leads captured</div>
      </div>

      <div class="stat-card">
        <div class="stat-label">Automated Resolution</div>
        <div class="stat-value" style="color: #2563eb;"><?php echo $automatedResolutionRate; ?>%</div>
        <div class="stat-desc"><?php echo $totalConversations - $humanTakeovers; ?> solved with 0 human effort</div>
      </div>

      <div class="stat-card stat-warning">
        <div class="stat-label">Unmatched Queries</div>
        <div class="stat-value" style="color: #f59e0b;"><?php echo count($unmatchedQueries); ?></div>
        <div class="stat-desc">Awaiting keyword rules</div>
      </div>
    </section>

    <!-- Two-Column Layout -->
    <div class="dashboard-grid" style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
      
      <!-- Left Column: Unmatched Queries / Bot Self-Learning Table -->
      <div style="display: flex; flex-direction: column; gap: 1.5rem;">
        
        <div class="card">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; flex-wrap: wrap; gap: 8px;">
            <div>
              <h3 class="card-title" style="margin: 0; display: flex; align-items: center; gap: 8px;">
                <span>🧠 Unmatched Inquiries &amp; Learning Queue</span>
                <span class="badge badge-amber"><?php echo count($unmatchedQueries); ?> Pending</span>
              </h3>
              <p style="font-size: 0.8rem; color: var(--text-muted); margin-top: 2px;">
                Questions asked by customers that hit the fallback response. 1-click assign them to any decision node to teach your bot.
              </p>
            </div>
          </div>

          <?php if (empty($unmatchedQueries)): ?>
            <div style="padding: 2.5rem 1rem; text-align: center; color: var(--text-muted);">
              <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">🎯</div>
              <strong style="color: var(--text); font-size: 0.95rem; display: block;">Learning Queue is Clear!</strong>
              <p style="font-size: 0.825rem; margin-top: 0.25rem;">
                All customer inquiries are currently matching your decision tree nodes and keyword triggers.
              </p>
            </div>
          <?php else: ?>
            <div style="overflow-x: auto;">
              <table class="data-table" style="width: 100%; border-collapse: collapse; font-size: 0.825rem;">
                <thead>
                  <tr style="border-bottom: 1px solid var(--border); text-align: left; color: var(--text-muted);">
                    <th style="padding: 10px;">Customer Query Phrase</th>
                    <th style="padding: 10px;">Frequency</th>
                    <th style="padding: 10px;">1-Click Route to Decision Node</th>
                    <th style="padding: 10px; text-align: right;">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($unmatchedQueries as $uq): ?>
                    <tr style="border-bottom: 1px solid var(--border);">
                      <td style="padding: 10px; font-weight: 600; color: var(--text);">
                        "<?php echo htmlspecialchars($uq['query']); ?>"
                      </td>
                      <td style="padding: 10px; white-space: nowrap;">
                        <span class="badge badge-primary"><?php echo (int)$uq['hit_count']; ?> times</span>
                      </td>
                      <td style="padding: 10px;">
                        <form method="POST" action="analytics.php" style="display: flex; gap: 6px; align-items: center; margin: 0;">
                          <input type="hidden" name="action" value="create_rule">
                          <input type="hidden" name="query_text" value="<?php echo htmlspecialchars($uq['query']); ?>">
                          <select name="node_id" class="form-input" style="padding: 4px 8px; font-size: 0.775rem; max-width: 180px;" required>
                            <option value="">— Select Target Node —</option>
                            <?php foreach ($allNodes as $an): ?>
                              <option value="<?php echo $an['id']; ?>">
                                <?php echo htmlspecialchars($an['node_name']); ?> (#<?php echo htmlspecialchars($an['node_key']); ?>)
                              </option>
                            <?php endforeach; ?>
                          </select>
                          <button type="submit" class="btn btn-primary btn-sm" style="padding: 4px 10px; font-size: 0.75rem; white-space: nowrap;">
                            + Add Rule
                          </button>
                        </form>
                      </td>
                      <td style="padding: 10px; text-align: right;">
                        <form method="POST" action="analytics.php" style="margin: 0; display: inline;">
                          <input type="hidden" name="action" value="dismiss_query">
                          <input type="hidden" name="query_text" value="<?php echo htmlspecialchars($uq['query']); ?>">
                          <button type="submit" class="btn btn-outline btn-sm" style="padding: 3px 7px; font-size: 0.7rem; color: var(--text-muted);" title="Dismiss from learning list">
                            ✕
                          </button>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>

        <!-- Message Direction Ratio & Traffic Summary -->
        <div class="card">
          <h3 class="card-title" style="margin-bottom: 0.75rem;">Message Traffic Volume Breakdown</h3>
          <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin-top: 1rem;">
            <div style="padding: 1rem; border-radius: var(--radius-sm); background: var(--bg-card-subtle); border: 1px solid var(--border);">
              <span style="font-size: 0.75rem; font-weight: 600; text-transform: uppercase; color: var(--text-muted);">Total Exchanged</span>
              <div style="font-size: 1.5rem; font-weight: 700; margin-top: 4px;"><?php echo $totalMessages; ?></div>
              <span style="font-size: 0.75rem; color: var(--text-muted);">Incoming &amp; Bot replies</span>
            </div>
            <div style="padding: 1rem; border-radius: var(--radius-sm); background: rgba(37, 99, 235, 0.05); border: 1px solid rgba(37, 99, 235, 0.2);">
              <span style="font-size: 0.75rem; font-weight: 600; text-transform: uppercase; color: #3b82f6;">Incoming Customer</span>
              <div style="font-size: 1.5rem; font-weight: 700; color: #3b82f6; margin-top: 4px;"><?php echo $incomingMessages; ?></div>
              <span style="font-size: 0.75rem; color: var(--text-muted);">Questions &amp; clicks</span>
            </div>
            <div style="padding: 1rem; border-radius: var(--radius-sm); background: rgba(16, 185, 129, 0.05); border: 1px solid rgba(16, 185, 129, 0.2);">
              <span style="font-size: 0.75rem; font-weight: 600; text-transform: uppercase; color: #10b981;">Automated Replies</span>
              <div style="font-size: 1.5rem; font-weight: 700; color: #10b981; margin-top: 4px;"><?php echo $outgoingMessages; ?></div>
              <span style="font-size: 0.75rem; color: var(--text-muted);">Instant responses</span>
            </div>
          </div>
        </div>

      </div>

      <!-- Right Column: Top Nodes & Keyword Rules Health -->
      <div style="display: flex; flex-direction: column; gap: 1.5rem;">
        
        <!-- Popular Flow Nodes -->
        <div class="card">
          <h3 class="card-title" style="margin-bottom: 0.5rem;">Most Visited Flow Nodes</h3>
          <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 1rem;">
            Customer engagement across decision tree branches.
          </p>

          <div style="display: flex; flex-direction: column; gap: 8px;">
            <?php foreach ($topNodes as $tn): ?>
              <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px 12px; background: var(--bg-card-subtle); border-radius: var(--radius-sm); border: 1px solid var(--border);">
                <div>
                  <strong style="font-size: 0.825rem; display: block; color: var(--text);">
                    <?php echo htmlspecialchars($tn['node_name']); ?>
                  </strong>
                  <span style="font-size: 0.725rem; font-family: monospace; color: var(--text-muted);">
                    #<?php echo htmlspecialchars($tn['node_key']); ?> • <?php echo ucfirst($tn['node_type']); ?>
                  </span>
                </div>
                <span class="badge badge-emerald" style="font-size: 0.75rem;">
                  <?php echo (int)$tn['visit_count']; ?> visits
                </span>
              </div>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Top Priority Keyword Rules -->
        <div class="card">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem;">
            <h3 class="card-title" style="margin: 0;">Active Keyword Triggers</h3>
            <a href="keywords.php" class="btn btn-outline btn-sm" style="font-size: 0.75rem; padding: 2px 8px;">
              Manage All →
            </a>
          </div>

          <div style="display: flex; flex-direction: column; gap: 8px;">
            <?php if (empty($activeKeywords)): ?>
              <span style="font-size: 0.8rem; color: var(--text-muted);">No active keyword triggers configured yet.</span>
            <?php else: ?>
              <?php foreach ($activeKeywords as $ak): ?>
                <div style="padding: 8px 12px; background: var(--bg-card-subtle); border-radius: var(--radius-sm); border: 1px solid var(--border); font-size: 0.8rem;">
                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2px;">
                    <strong style="color: var(--primary); font-family: monospace;">"<?php echo htmlspecialchars($ak['keyword']); ?>"</strong>
                    <span class="badge badge-amber" style="font-size: 0.675rem;">Prio: <?php echo (int)$ak['priority']; ?></span>
                  </div>
                  <div style="font-size: 0.725rem; color: var(--text-muted);">
                    Routes to: <strong><?php echo htmlspecialchars($ak['node_name'] ?? 'Node #' . $ak['node_id']); ?></strong> (<?php echo $ak['match_type']; ?>)
                  </div>
                </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>

      </div>

    </div>
  </main>
</body>
</html>
