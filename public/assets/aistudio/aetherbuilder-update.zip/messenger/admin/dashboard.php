<?php
/**
 * Main Overview Dashboard
 * Production Single-Host Architecture
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/updater.php';
requireLogin();

$pdo = db();

// Fetch statistics safely
$stats = [
    'nodes' => 0,
    'keywords' => 0,
    'conversations' => 0,
    'leads' => 0,
    'products' => 0,
];

try {
    $stats['nodes'] = (int)$pdo->query("SELECT COUNT(*) FROM flow_nodes")->fetchColumn();
    $stats['keywords'] = (int)$pdo->query("SELECT COUNT(*) FROM keyword_triggers WHERE is_active = 1")->fetchColumn();
    $stats['conversations'] = (int)$pdo->query("SELECT COUNT(*) FROM conversations")->fetchColumn();
    $stats['leads'] = (int)$pdo->query("SELECT COUNT(*) FROM leads")->fetchColumn();

    // Auto-verify and ensure products table exists on MySQL database
    try {
        $stats['products'] = (int)$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    } catch (Throwable $pe) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS products (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            category VARCHAR(100) DEFAULT 'Services',
            price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            currency VARCHAR(10) NOT NULL DEFAULT 'USD',
            description TEXT,
            sku VARCHAR(100) DEFAULT NULL,
            stock_status ENUM('available','in_stock','preorder','out_of_stock') NOT NULL DEFAULT 'available',
            features TEXT,
            image_url LONGTEXT,
            action_label VARCHAR(100) DEFAULT 'Order Now',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
        $stats['products'] = (int)$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    }

    $recentMessages = $pdo->query("SELECT m.*, c.page_scoped_id FROM messages m JOIN conversations c ON m.conversation_id = c.id ORDER BY m.created_at DESC LIMIT 6")->fetchAll();
    $unmatchedCount = (int)$pdo->query("SELECT COUNT(*) FROM unmatched_queries")->fetchColumn();
} catch (Throwable $e) {
    $recentMessages = [];
    $unmatchedCount = 0;
}

$currentVersion = AppUpdater::getCurrentVersion();
$activeToken = AppUpdater::getGitHubToken($pdo);
$updateCheck = AppUpdater::checkForUpdates($pdo, false);
$hasUpdate = !empty($updateCheck['has_update']);

$isUpdated = isset($_GET['updated']) && $_GET['updated'] === '1';
$updatedVer = $_GET['v'] ?? $currentVersion;

$webhookUrl = rtrim(APP_BASE_URL, '/') . '/webhook.php';
$verifyToken = ADMIN_SETUP_KEY;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/app.css?v=1.4.4">
  <script src="../assets/js/admin.js?v=1.4.4" defer></script>
</head>
<body class="app-page">
  <?php renderAdminHeader('dashboard'); ?>

  <main class="main-content">
    <!-- Topbar -->
    <header class="topbar">
      <div class="topbar-left">
        <span class="eyebrow">BOT OVERVIEW</span>
        <h1 class="page-title">Messenger Support Dashboard</h1>
        <p class="page-subtitle">Deterministic 24/7 rule-based chatbot for Facebook Messenger business page.</p>
      </div>

      <div class="topbar-right">
        <div class="bot-status-badge">
          <span class="status-pulse"></span>
          <span>Bot: <strong>24/7 Active</strong></span>
        </div>

        <a href="updates.php" class="btn btn-outline btn-sm <?php echo $hasUpdate ? 'btn-update-alert' : ''; ?>" title="Version & System Updates">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>
          <span>v<?php echo htmlspecialchars($currentVersion); ?></span>
          <?php if ($hasUpdate): ?>
            <span class="status-pulse" style="background: #f59e0b; width: 6px; height: 6px;"></span>
          <?php endif; ?>
        </a>

        <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
          🌙 Dark Mode
        </button>

        <a href="simulator.php" class="btn btn-primary btn-sm">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>
          Test Simulator
        </a>
      </div>
    </header>

    <?php if ($isUpdated): ?>
      <!-- Post-Update Celebration Banner -->
      <div class="alert alert-success" style="display: flex; align-items: center; justify-content: space-between; border-left: 4px solid #10b981; padding: 1.1rem 1.25rem; margin-bottom: 1.5rem; background: rgba(16, 185, 129, 0.12); border-radius: var(--radius-sm);">
        <div style="display: flex; align-items: center; gap: 14px;">
          <span style="font-size: 1.75rem;">🎉</span>
          <div>
            <strong style="color: #10b981; font-size: 0.95rem;">System Successfully Updated to Version v<?php echo htmlspecialchars($updatedVer); ?>!</strong>
            <p style="margin: 0.2rem 0 0; font-size: 0.8125rem; color: var(--text-muted);">
              All application files have been refreshed from the release package. Your configuration and database records were safely preserved.
            </p>
          </div>
        </div>
        <a href="updates.php" class="btn btn-outline btn-sm">View Release Notes</a>
      </div>
    <?php endif; ?>

    <?php if ($hasUpdate): ?>
      <!-- Prominent Update Available Banner on Dashboard -->
      <div class="card" style="border: 2px solid #f59e0b; background: linear-gradient(90deg, rgba(245, 158, 11, 0.08) 0%, rgba(37, 99, 235, 0.05) 100%); margin-bottom: 1.5rem; padding: 1.25rem 1.5rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem;">
        <div style="display: flex; align-items: center; gap: 14px;">
          <div style="font-size: 1.75rem; width: 44px; height: 44px; border-radius: 12px; background: rgba(245, 158, 11, 0.2); display: flex; align-items: center; justify-content: center;">
            🚀
          </div>
          <div>
            <div style="display: flex; align-items: center; gap: 8px;">
              <strong style="font-size: 1.05rem;">New System Update Available: v<?php echo htmlspecialchars($updateCheck['latest_version']); ?></strong>
              <span class="badge badge-amber">Action Required</span>
            </div>
            <p style="margin: 0.25rem 0 0; font-size: 0.825rem; color: var(--text-muted);">
              You are running <code>v<?php echo htmlspecialchars($currentVersion); ?></code>. Upgrading will install the latest features and automatically refresh your dashboard.
            </p>
          </div>
        </div>
        <div style="display: flex; gap: 0.75rem;">
          <a href="updates.php" class="btn btn-outline btn-sm">View Changelog</a>
          <button type="button" class="btn btn-primary btn-sm" onclick="startQuickUpdate('<?php echo htmlspecialchars($updateCheck['latest_version']); ?>', '<?php echo htmlspecialchars($updateCheck['download_url'] ?? ''); ?>', '<?php echo htmlspecialchars($activeToken); ?>')">
            ⚡ Update Now
          </button>
        </div>
      </div>
    <?php endif; ?>

    <!-- Stat Metrics Cards -->
    <section class="stat-grid">
      <div class="stat-card">
        <div class="stat-label">Flow Nodes</div>
        <div class="stat-value"><?php echo $stats['nodes']; ?></div>
        <div class="stat-desc">Decision tree answers & menus</div>
      </div>

      <div class="stat-card stat-warning">
        <div class="stat-label">Active Keywords</div>
        <div class="stat-value"><?php echo $stats['keywords']; ?></div>
        <div class="stat-desc">Exact, phrase & contains triggers</div>
      </div>

      <div class="stat-card">
        <div class="stat-label">Total Conversations</div>
        <div class="stat-value"><?php echo $stats['conversations']; ?></div>
        <div class="stat-desc">Facebook users interacted</div>
      </div>

      <div class="stat-card stat-success">
        <div class="stat-label">Captured Leads</div>
        <div class="stat-value"><?php echo $stats['leads']; ?></div>
        <div class="stat-desc">Inquiries ready for export</div>
      </div>

      <div class="stat-card" style="border-top: 3px solid #10b981;">
        <div class="stat-label">Catalog Offerings</div>
        <div class="stat-value"><?php echo $stats['products']; ?></div>
        <div class="stat-desc">Products, pricing &amp; camera media</div>
      </div>
    </section>

    <!-- Two-Column Layout -->
    <div class="dashboard-grid">
      
      <!-- Left Column: Activity & Quick Actions -->
      <div>
        <!-- Quick Actions Panel -->
        <div class="card" style="margin-bottom: 1.5rem;">
          <h3 class="card-title">Quick Actions</h3>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 0.75rem;">
            <a href="products.php" class="btn btn-outline" style="justify-content: flex-start; border-color: rgba(16, 185, 129, 0.4); color: #34d399;">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
              🛍️ Products &amp; Services
            </a>
            <a href="ai-studio.php" class="btn btn-outline" style="justify-content: flex-start; border-color: rgba(168, 85, 247, 0.4); color: #c084fc;">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg>
              ✨ AI Flow Studio
            </a>
            <a href="flow-builder.php" class="btn btn-outline" style="justify-content: flex-start;">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg>
              Manage Decision Tree
            </a>
            <a href="keywords.php" class="btn btn-outline" style="justify-content: flex-start;">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
              Add Keyword Trigger
            </a>
            <a href="responses.php" class="btn btn-outline" style="justify-content: flex-start; border-color: rgba(14, 165, 233, 0.4); color: #38bdf8;">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>
              📚 FAQ Knowledge Base
            </a>
            <a href="webhook-logs.php" class="btn btn-outline" style="justify-content: flex-start;">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
              📡 Webhook Inspector
            </a>
            <a href="analytics.php" class="btn btn-outline" style="justify-content: flex-start; border-color: rgba(59, 130, 246, 0.4); color: #60a5fa;">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
              📊 Bot Analytics
            </a>
            <a href="conversations.php" class="btn btn-outline" style="justify-content: flex-start;">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
              Live Chat Takeover
            </a>
            <a href="updates.php" class="btn btn-outline" style="justify-content: flex-start;">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>
              Check for Updates
            </a>
          </div>
        </div>

        <!-- Recent Message Stream -->
        <div class="card" style="margin-bottom: 1.5rem;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
            <h3 class="card-title" style="margin-bottom: 0;">Recent Message Activity</h3>
            <a href="conversations.php" style="font-size: 0.8125rem; font-weight: 600;">View All Chats →</a>
          </div>

          <?php if (empty($recentMessages)): ?>
            <div style="text-align: center; padding: 2.5rem 1rem; color: var(--text-muted);">
              <div style="font-size: 2rem; margin-bottom: 0.5rem; opacity: 0.5;">💬</div>
              <p style="font-size: 0.9rem; margin-bottom: 0.75rem;">No customer messages logged yet.</p>
              <p style="font-size: 0.8rem; margin-bottom: 1.25rem;">Use the simulator to send a sample message or message your live Facebook Page.</p>
              <a href="simulator.php" class="btn btn-primary btn-sm">Launch Test Simulator</a>
            </div>
          <?php else: ?>
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>Direction</th>
                    <th>User PSID</th>
                    <th>Message Text</th>
                    <th>Time</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($recentMessages as $msg): ?>
                    <tr>
                      <td>
                        <?php if ($msg['direction'] === 'incoming'): ?>
                          <span class="badge badge-blue">Incoming</span>
                        <?php else: ?>
                          <span class="badge badge-green">Outgoing</span>
                        <?php endif; ?>
                      </td>
                      <td style="font-family: monospace; font-size: 0.75rem;">
                        <?php echo htmlspecialchars(substr($msg['page_scoped_id'], 0, 10)) . '...'; ?>
                      </td>
                      <td style="max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                        <?php echo htmlspecialchars($msg['message_text']); ?>
                      </td>
                      <td style="font-size: 0.75rem; color: var(--text-muted);">
                        <?php echo htmlspecialchars(date('M j, g:ia', strtotime($msg['created_at']))); ?>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>

        <!-- Analytics & Unmatched Inquiries Spotlight -->
        <div class="card" style="background: linear-gradient(135deg, rgba(37, 99, 235, 0.04) 0%, rgba(147, 51, 234, 0.04) 100%); border-left: 4px solid var(--primary);">
          <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
            <div>
              <h3 class="card-title" style="margin: 0; display: flex; align-items: center; gap: 8px;">
                <span>📊 Analytics &amp; Self-Learning Insights</span>
                <?php if ($unmatchedCount > 0): ?>
                  <span class="badge badge-amber"><?php echo $unmatchedCount; ?> Unanswered Inquiries</span>
                <?php else: ?>
                  <span class="badge badge-emerald">Optimal Routing</span>
                <?php endif; ?>
              </h3>
              <p style="font-size: 0.8rem; color: var(--text-muted); margin-top: 4px;">
                Review conversation conversion metrics, automated resolution rates, and 1-click teach the bot unanswered customer questions.
              </p>
            </div>
            <a href="analytics.php" class="btn btn-primary btn-sm">
              Open Full Analytics →
            </a>
          </div>
        </div>
      </div>

      <!-- Right Column: Meta Webhook Setup & System Status -->
      <div>
        <!-- System Version & GitHub Sync Card -->
        <div class="card" style="margin-bottom: 1.5rem;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem;">
            <h3 class="card-title" style="margin-bottom: 0;">Version & System Updates</h3>
            <span class="badge <?php echo $hasUpdate ? 'badge-amber' : 'badge-green'; ?>">
              v<?php echo htmlspecialchars($currentVersion); ?>
            </span>
          </div>

          <div style="font-size: 0.825rem; line-height: 1.6; color: var(--text-muted); margin-bottom: 1rem;">
            <div><strong>System Status:</strong> <code>Production Stable</code></div>
            <div><strong>Latest Available:</strong> <code>v<?php echo htmlspecialchars($updateCheck['latest_version']); ?></code></div>
            <div><strong>Update Status:</strong> <?php echo $hasUpdate ? '<span style="color: #f59e0b; font-weight: 600;">Update Available</span>' : '<span style="color: #10b981; font-weight: 600;">Up to date ✓</span>'; ?></div>
          </div>

          <div style="display: flex; gap: 0.5rem;">
            <a href="updates.php" class="btn btn-outline btn-sm" style="flex: 1;">
              Manage Updates →
            </a>
            <?php if ($hasUpdate): ?>
              <button type="button" class="btn btn-primary btn-sm" onclick="startQuickUpdate('<?php echo htmlspecialchars($updateCheck['latest_version']); ?>', '<?php echo htmlspecialchars($updateCheck['download_url'] ?? ''); ?>', '<?php echo htmlspecialchars($activeToken); ?>')">
                Update Now
              </button>
            <?php endif; ?>
          </div>
        </div>

        <div class="card">
          <h3 class="card-title">Meta Webhook Status</h3>
          <p style="font-size: 0.8125rem; color: var(--text-muted); margin-bottom: 1.25rem;">
            Configure these credentials in your <strong>Meta for Developers</strong> app under Messenger Webhooks.
          </p>

          <div style="margin-bottom: 1.25rem;">
            <label class="form-label">CALLBACK URL</label>
            <div class="copy-box">
              <span id="webhook-url-val"><?php echo htmlspecialchars($webhookUrl); ?></span>
              <button type="button" class="btn-copy" onclick="copyToClipboard('<?php echo htmlspecialchars($webhookUrl); ?>', this)">Copy</button>
            </div>
          </div>

          <div style="margin-bottom: 1.25rem;">
            <label class="form-label">VERIFY TOKEN</label>
            <div class="copy-box">
              <span id="verify-token-val"><?php echo htmlspecialchars($verifyToken); ?></span>
              <button type="button" class="btn-copy" onclick="copyToClipboard('<?php echo htmlspecialchars($verifyToken); ?>', this)">Copy</button>
            </div>
          </div>

          <div style="padding: 0.85rem 1rem; border-radius: var(--radius-sm); background: rgba(16, 185, 129, 0.08); border: 1px solid rgba(16, 185, 129, 0.25); display: flex; align-items: center; gap: 8px; margin-top: 1rem;">
            <span class="status-pulse"></span>
            <span style="font-size: 0.8125rem; font-weight: 600; color: #10b981;">
              Connected to MySQL (<?php echo htmlspecialchars(DB_HOST); ?>)
            </span>
          </div>

          <div style="margin-top: 1.25rem; padding-top: 1.25rem; border-top: 1px solid var(--border);">
            <a href="settings.php" class="btn btn-outline btn-sm" style="width: 100%;">
              Configure Page Access Token & Greetings →
            </a>
          </div>
        </div>

        <!-- 100% Rule-Based Architecture Badge -->
        <div class="card" style="background: var(--bg-card-subtle);">
          <div style="font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); margin-bottom: 0.5rem;">
            100% Deterministic & Rule-Based
          </div>
          <p style="font-size: 0.8125rem; color: var(--text-muted); line-height: 1.6; margin-bottom: 0.75rem;">
            Automated customer journeys are executed strictly through your approved decision tree and keyword dictionary. Zero LLM hallucinations, zero OpenAI API charges, and instantaneous response speeds.
          </p>
          <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
            <span class="badge badge-blue">MySQL 8.0</span>
            <span class="badge badge-green">Pure PHP 7.4 - 8.4</span>
            <span class="badge badge-blue">Automated Updates</span>
          </div>
        </div>
      </div>

    </div>
  </main>
</body>
</html>
