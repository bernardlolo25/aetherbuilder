<?php
/**
 * Leads & CRM Inquiries Management
 * Production Single-Host Architecture
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';
requireLogin();

$pdo = db();
$msg = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $lead_id = (int)($_POST['lead_id'] ?? 0);

    if ($action === 'update_status' && $lead_id > 0) {
        $new_status = $_POST['lead_status'] ?? 'new';
        if (in_array($new_status, ['new', 'contacted', 'qualified', 'closed'], true)) {
            $stmt = $pdo->prepare("UPDATE leads SET lead_status = :s WHERE id = :id");
            $stmt->execute([':s' => $new_status, ':id' => $lead_id]);
            $msg = "Lead #{$lead_id} updated.";
        }
    }

    if ($action === 'delete_lead' && $lead_id > 0) {
        $stmt = $pdo->prepare("DELETE FROM leads WHERE id = :id");
        $stmt->execute([':id' => $lead_id]);
        $msg = "Lead record deleted.";
    }
}

$status_filter = $_GET['status'] ?? 'all';
$query = "SELECT * FROM leads";
$params = [];
if ($status_filter !== 'all' && in_array($status_filter, ['new', 'contacted', 'qualified', 'closed'], true)) {
    $query .= " WHERE lead_status = :s";
    $params[':s'] = $status_filter;
}
$query .= " ORDER BY created_at DESC LIMIT 100";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$leads = $stmt->fetchAll();

$counts = [
    'total' => (int)$pdo->query("SELECT COUNT(*) FROM leads")->fetchColumn(),
    'new' => (int)$pdo->query("SELECT COUNT(*) FROM leads WHERE lead_status = 'new'")->fetchColumn(),
    'contacted' => (int)$pdo->query("SELECT COUNT(*) FROM leads WHERE lead_status = 'contacted'")->fetchColumn(),
    'qualified' => (int)$pdo->query("SELECT COUNT(*) FROM leads WHERE lead_status = 'qualified'")->fetchColumn(),
    'closed' => (int)$pdo->query("SELECT COUNT(*) FROM leads WHERE lead_status = 'closed'")->fetchColumn(),
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Captured Leads - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/app.css?v=1.4.0">
  <script src="../assets/js/admin.js?v=1.4.0" defer></script>
</head>
<body class="app-page">
  <?php renderAdminHeader('leads'); ?>

  <main class="main-content">
    <header class="topbar">
      <div class="topbar-left">
        <span class="eyebrow">CRM & INQUIRIES</span>
        <h1 class="page-title">Captured Leads</h1>
        <p class="page-subtitle">Review contact information and inquiries gathered by your automated chatbot.</p>
      </div>

      <div class="topbar-right">
        <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
          🌙 Dark Mode
        </button>
        <button class="btn btn-primary btn-sm" onclick="exportTableToCSV('leads-table', 'customer_leads.csv')">
          📥 Export CSV
        </button>
      </div>
    </header>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <!-- Tab Purpose & Usage Guide -->
    <div class="card" style="background: linear-gradient(135deg, rgba(37, 99, 235, 0.05) 0%, rgba(16, 185, 129, 0.03) 100%); border-left: 4px solid var(--primary); margin-bottom: 1.5rem; padding: 1.25rem 1.5rem;">
      <div style="display: flex; align-items: flex-start; gap: 12px;">
        <span style="font-size: 1.5rem; line-height: 1;">📋</span>
        <div style="font-size: 0.825rem; line-height: 1.6;">
          <strong style="font-size: 0.95rem; color: var(--text); display: block; margin-bottom: 0.25rem;">
            Tab Purpose & How to Use Captured Leads
          </strong>
          <p style="margin: 0 0 0.5rem 0; color: var(--text-muted);">
            <strong>Purpose:</strong> View, manage, and follow up with potential clients who provided their contact details (Name, Email, Phone number, and Interest) during automated decision tree journeys.
          </p>
          <div style="background: var(--bg-card); padding: 0.75rem 1rem; border-radius: var(--radius-sm); border: 1px solid var(--border);">
            <strong>How to Use & What to Enter:</strong>
            <ul style="margin: 0.25rem 0 0 0; padding-left: 1.2rem; color: var(--text-muted);">
              <li>Filter leads by stage: <code>New</code> → <code>Contacted</code> → <code>Qualified</code> → <code>Closed</code>.</li>
              <li>Change the status dropdown on any lead row to keep your team organized.</li>
              <li>Click <strong>📥 Export CSV</strong> to download all records into Excel, Google Sheets, or your CRM.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- Status Filter Pills -->
    <div style="display: flex; gap: 0.75rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
      <a href="leads.php?status=all" class="badge-pill <?php echo $status_filter === 'all' ? 'badge-blue' : ''; ?>" style="padding: 0.4rem 0.85rem; font-size: 0.8rem; text-decoration: none;">
        All Inquiries (<?php echo $counts['total']; ?>)
      </a>
      <a href="leads.php?status=new" class="badge-pill <?php echo $status_filter === 'new' ? 'badge-blue' : ''; ?>" style="padding: 0.4rem 0.85rem; font-size: 0.8rem; text-decoration: none;">
        New (<?php echo $counts['new']; ?>)
      </a>
      <a href="leads.php?status=contacted" class="badge-pill <?php echo $status_filter === 'contacted' ? 'badge-blue' : ''; ?>" style="padding: 0.4rem 0.85rem; font-size: 0.8rem; text-decoration: none;">
        Contacted (<?php echo $counts['contacted']; ?>)
      </a>
      <a href="leads.php?status=qualified" class="badge-pill <?php echo $status_filter === 'qualified' ? 'badge-blue' : ''; ?>" style="padding: 0.4rem 0.85rem; font-size: 0.8rem; text-decoration: none;">
        Qualified (<?php echo $counts['qualified']; ?>)
      </a>
      <a href="leads.php?status=closed" class="badge-pill <?php echo $status_filter === 'closed' ? 'badge-blue' : ''; ?>" style="padding: 0.4rem 0.85rem; font-size: 0.8rem; text-decoration: none;">
        Closed (<?php echo $counts['closed']; ?>)
      </a>
    </div>

    <!-- Table Card -->
    <div class="card">
      <div class="table-responsive">
        <table id="leads-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Customer Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Inquiry Notes</th>
              <th>Status</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($leads)): ?>
              <tr>
                <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 2rem;">
                  No leads recorded yet. Customer data captured through conversation flows will appear here.
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($leads as $l): ?>
                <tr>
                  <td>#<?php echo $l['id']; ?></td>
                  <td style="font-weight: 600;"><?php echo htmlspecialchars($l['full_name'] ?: 'Messenger User'); ?></td>
                  <td><?php echo htmlspecialchars($l['email'] ?: '-'); ?></td>
                  <td><?php echo htmlspecialchars($l['phone'] ?: '-'); ?></td>
                  <td style="max-width: 240px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                    <?php echo htmlspecialchars($l['notes'] ?: '-'); ?>
                  </td>
                  <td>
                    <form method="POST" style="margin: 0; display: inline;">
                      <input type="hidden" name="action" value="update_status">
                      <input type="hidden" name="lead_id" value="<?php echo $l['id']; ?>">
                      <select name="lead_status" class="form-control" style="padding: 0.2rem 0.5rem; font-size: 0.75rem; width: auto;" onchange="this.form.submit()">
                        <option value="new" <?php echo ($l['lead_status'] === 'new') ? 'selected' : ''; ?>>New</option>
                        <option value="contacted" <?php echo ($l['lead_status'] === 'contacted') ? 'selected' : ''; ?>>Contacted</option>
                        <option value="qualified" <?php echo ($l['lead_status'] === 'qualified') ? 'selected' : ''; ?>>Qualified</option>
                        <option value="closed" <?php echo ($l['lead_status'] === 'closed') ? 'selected' : ''; ?>>Closed</option>
                      </select>
                    </form>
                  </td>
                  <td style="font-size: 0.75rem; color: var(--text-muted);"><?php echo htmlspecialchars($l['created_at']); ?></td>
                  <td>
                    <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this record?');">
                      <input type="hidden" name="action" value="delete_lead">
                      <input type="hidden" name="lead_id" value="<?php echo $l['id']; ?>">
                      <button type="submit" class="btn btn-outline btn-sm" style="color: var(--danger); border-color: var(--border-strong); padding: 0.2rem 0.5rem;">Delete</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</body>
</html>
