<?php
/**
 * Bot Configuration & Meta Webhook Settings
 * Production Single-Host Compatible with Argon2id Security Vault
 * Includes Smart Business Hours, Instant Lead Alerts, and Optional AI Fallback
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';
requireLogin();

$pdo = db();
$msg = '';
$error = '';

function getSetting($pdo, $key, $default = '') {
    $stmt = $pdo->prepare("SELECT setting_value FROM bot_settings WHERE setting_key = :k LIMIT 1");
    $stmt->execute([':k' => $key]);
    $res = $stmt->fetchColumn();
    return ($res !== false) ? $res : $default;
}

function setSetting($pdo, $key, $val) {
    $stmt = $pdo->prepare("INSERT INTO bot_settings (setting_key, setting_value) VALUES (:k, :v) ON DUPLICATE KEY UPDATE setting_value = :v2");
    $stmt->execute([':k' => $key, ':v' => $val, ':v2' => $val]);
}

// Master Security PIN Hash (Argon2id protected)
$algo = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT;
$masterPinHash = getSetting($pdo, 'master_pin_argon_hash', '');

// If not yet initialized, set default PIN '1234' with Argon2id
if (empty($masterPinHash)) {
    $masterPinHash = password_hash('1234', $algo);
    setSetting($pdo, 'master_pin_argon_hash', $masterPinHash);
}

$isVaultUnlocked = !empty($_SESSION['security_vault_unlocked']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'unlock_vault') {
        $enteredPin = trim($_POST['master_pin'] ?? '');
        if (password_verify($enteredPin, $masterPinHash)) {
            $_SESSION['security_vault_unlocked'] = true;
            $isVaultUnlocked = true;
            $msg = "Security Vault unlocked successfully! Sensitive tokens are now editable.";
        } else {
            $error = "Incorrect Master Security PIN. Tokens remain protected.";
        }
    } elseif ($action === 'lock_vault') {
        unset($_SESSION['security_vault_unlocked']);
        $isVaultUnlocked = false;
        $msg = "Security Vault re-locked. Sensitive credentials are masked and protected.";
    } elseif ($action === 'change_pin') {
        if (!$isVaultUnlocked) {
            $error = "You must unlock the security vault first before changing the master PIN.";
        } else {
            $newPin = trim($_POST['new_pin'] ?? '');
            $confirmPin = trim($_POST['confirm_pin'] ?? '');
            if (strlen($newPin) < 4) {
                $error = "Master PIN must be at least 4 digits/characters.";
            } elseif ($newPin !== $confirmPin) {
                $error = "The new PINs do not match. Please try again.";
            } else {
                $newHash = password_hash($newPin, $algo);
                setSetting($pdo, 'master_pin_argon_hash', $newHash);
                $masterPinHash = $newHash;
                $msg = "Master Security PIN updated successfully with Argon2id cryptographic protection!";
            }
        }
    } elseif ($action === 'save_settings') {
        $bot_name = trim($_POST['bot_name'] ?? 'Chat Assistant Bot');
        $bot_enabled = isset($_POST['bot_enabled']) ? '1' : '0';
        $welcome_msg = trim($_POST['welcome_msg'] ?? '');
        $default_msg = trim($_POST['default_msg'] ?? '');
        $human_handoff_msg = trim($_POST['human_handoff_msg'] ?? '');

        setSetting($pdo, 'bot_name', $bot_name);
        setSetting($pdo, 'bot_enabled', $bot_enabled);
        setSetting($pdo, 'welcome_msg', $welcome_msg);
        setSetting($pdo, 'default_msg', $default_msg);
        setSetting($pdo, 'human_handoff_msg', $human_handoff_msg);

        // Smart Business Hours
        $biz_enabled = isset($_POST['business_hours_enabled']) ? '1' : '0';
        $biz_days = json_encode($_POST['business_days'] ?? ['Mon','Tue','Wed','Thu','Fri']);
        $biz_start = trim($_POST['business_start_time'] ?? '09:00');
        $biz_end = trim($_POST['business_end_time'] ?? '18:00');
        $biz_tz = trim($_POST['business_timezone'] ?? 'America/New_York');
        $off_hours = trim($_POST['off_hours_msg'] ?? '');

        setSetting($pdo, 'business_hours_enabled', $biz_enabled);
        setSetting($pdo, 'business_days', $biz_days);
        setSetting($pdo, 'business_start_time', $biz_start);
        setSetting($pdo, 'business_end_time', $biz_end);
        setSetting($pdo, 'business_timezone', $biz_tz);
        setSetting($pdo, 'off_hours_msg', $off_hours);

        // Instant Lead Alerts
        $notify_email = trim($_POST['notify_email'] ?? '');
        $notify_tg_token = trim($_POST['notify_telegram_token'] ?? '');
        $notify_tg_chat = trim($_POST['notify_telegram_chat_id'] ?? '');

        setSetting($pdo, 'notify_email', $notify_email);
        setSetting($pdo, 'notify_telegram_token', $notify_tg_token);
        setSetting($pdo, 'notify_telegram_chat_id', $notify_tg_chat);

        // Optional AI Fallback
        $ai_enabled = isset($_POST['ai_fallback_enabled']) ? '1' : '0';
        $ai_provider = trim($_POST['ai_provider'] ?? 'gemini');
        $ai_prompt = trim($_POST['ai_system_prompt'] ?? '');

        setSetting($pdo, 'ai_fallback_enabled', $ai_enabled);
        setSetting($pdo, 'ai_provider', $ai_provider);
        setSetting($pdo, 'ai_system_prompt', $ai_prompt);

        // Sensitive tokens can only be updated if vault is unlocked
        if ($isVaultUnlocked) {
            $verify_token = trim($_POST['verify_token'] ?? ADMIN_SETUP_KEY);
            $page_access_token = trim($_POST['page_access_token'] ?? '');
            $ai_api_key = trim($_POST['ai_api_key'] ?? '');

            setSetting($pdo, 'verify_token', $verify_token);
            setSetting($pdo, 'page_access_token', $page_access_token);
            setSetting($pdo, 'ai_api_key', $ai_api_key);
            $msg = "All general settings, operating hours, notifications, and security tokens updated successfully!";
        } else {
            $msg = "General bot settings, business hours & lead alerts updated! (Sensitive API tokens remained protected under Argon2 lock).";
        }
    }
}

// Retrieve values
$bot_name = getSetting($pdo, 'bot_name', APP_NAME);
$bot_enabled = getSetting($pdo, 'bot_enabled', '1');
$verify_token = getSetting($pdo, 'verify_token', ADMIN_SETUP_KEY);
$page_access_token = getSetting($pdo, 'page_access_token', '');
$welcome_msg = getSetting($pdo, 'welcome_msg', 'Hello! 👋 Welcome to our 24/7 customer support. How can we assist you today?');
$default_msg = getSetting($pdo, 'default_msg', "I'm sorry, I didn't recognize that request. Please select an option from the menu below or type 'menu' to start over.");
$human_handoff_msg = getSetting($pdo, 'human_handoff_msg', 'A human support specialist has been alerted and will respond shortly. You may leave your message here.');

// Operating hours
$business_hours_enabled = getSetting($pdo, 'business_hours_enabled', '0');
$saved_days = json_decode(getSetting($pdo, 'business_days', '["Mon","Tue","Wed","Thu","Fri"]'), true) ?: ['Mon','Tue','Wed','Thu','Fri'];
$business_start_time = getSetting($pdo, 'business_start_time', '09:00');
$business_end_time = getSetting($pdo, 'business_end_time', '18:00');
$business_timezone = getSetting($pdo, 'business_timezone', 'America/New_York');
$off_hours_msg = getSetting($pdo, 'off_hours_msg', '🕒 Thank you for reaching out! We are currently outside our operating hours (Mon-Fri 9AM-6PM). Please leave your inquiry and contact info, and an agent will reply promptly when we reopen.');

// Alerts
$notify_email = getSetting($pdo, 'notify_email', 'admin@uspf-mcle.ct.ws');
$notify_telegram_token = getSetting($pdo, 'notify_telegram_token', '');
$notify_telegram_chat_id = getSetting($pdo, 'notify_telegram_chat_id', '');

// AI Fallback
$ai_fallback_enabled = getSetting($pdo, 'ai_fallback_enabled', '0');
$ai_provider = getSetting($pdo, 'ai_provider', 'gemini');
$ai_system_prompt = getSetting($pdo, 'ai_system_prompt', 'You are a polite, helpful customer service assistant. Answer customer questions concisely (1-3 sentences). At the end of your reply, invite them to choose a menu option or type "menu".');
$ai_api_key = getSetting($pdo, 'ai_api_key', '');

$webhook_url = rtrim(defined('APP_BASE_URL') ? APP_BASE_URL : '', '/') . '/webhook.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bot Settings & Security - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/app.css?v=1.4.2">
  <script src="../assets/js/admin.js?v=1.4.2" defer></script>
</head>
<body class="app-page">
  <?php renderAdminHeader('settings'); ?>

  <main class="main-content">
    <header class="topbar">
      <div class="topbar-left">
        <span class="eyebrow">SYSTEM CONFIGURATION & SECURITY</span>
        <h1 class="page-title">Bot Settings &amp; Security Vault</h1>
        <p class="page-subtitle">Configure Meta Graph API credentials, webhook verification, business hours, lead alerts, and Argon2-protected master tokens.</p>
      </div>

      <div class="topbar-right">
        <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
          🌙 Dark Mode
        </button>
        <a href="simulator.php" class="btn btn-outline btn-sm">
          📱 Test Simulator
        </a>
      </div>
    </header>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <!-- Argon2 Security Vault Control Banner -->
    <div class="card" style="border: 2px solid <?php echo $isVaultUnlocked ? '#10b981' : '#2563eb'; ?>; background: <?php echo $isVaultUnlocked ? 'rgba(16, 185, 129, 0.05)' : 'rgba(37, 99, 235, 0.04)'; ?>; margin-bottom: 1.5rem; padding: 1.25rem 1.5rem;">
      <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
        <div style="display: flex; align-items: center; gap: 12px;">
          <div style="width: 44px; height: 44px; border-radius: 12px; background: <?php echo $isVaultUnlocked ? 'rgba(16, 185, 129, 0.15)' : 'rgba(37, 99, 235, 0.15)'; ?>; color: <?php echo $isVaultUnlocked ? '#10b981' : '#2563eb'; ?>; display: flex; align-items: center; justify-content: center; font-size: 1.4rem;">
            <?php echo $isVaultUnlocked ? '🔓' : '🛡️'; ?>
          </div>
          <div>
            <div style="display: flex; align-items: center; gap: 8px;">
              <strong style="font-size: 1rem;">
                <?php echo $isVaultUnlocked ? 'Security Vault Unlocked (Master Session)' : 'Argon2id Master Security Lock: Active'; ?>
              </strong>
              <span class="badge <?php echo $isVaultUnlocked ? 'badge-emerald' : 'badge-primary'; ?>">
                <?php echo $isVaultUnlocked ? 'Authorized' : 'Protected'; ?>
              </span>
            </div>
            <p style="margin: 0.2rem 0 0 0; font-size: 0.8125rem; color: var(--text-muted);">
              <?php echo $isVaultUnlocked 
                ? 'You can now view and modify Facebook Page Access Tokens and Webhook secrets. Lock vault when finished.' 
                : 'Sensitive credentials are protected against unauthorized edits. Enter Master Security PIN (Default: 1234) to unlock.'; ?>
            </p>
          </div>
        </div>

        <div style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;">
          <?php if ($isVaultUnlocked): ?>
            <form method="POST" style="margin: 0;">
              <input type="hidden" name="action" value="lock_vault">
              <button type="submit" class="btn btn-outline btn-sm">
                🔒 Re-lock Vault Now
              </button>
            </form>
          <?php else: ?>
            <form method="POST" style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap; margin: 0; max-width: 100%;">
              <input type="hidden" name="action" value="unlock_vault">
              <input type="password" name="master_pin" class="form-control" placeholder="Master PIN (Default: 1234)" style="width: auto; min-width: 150px; max-width: 100%; flex: 1;" required>
              <button type="submit" class="btn btn-primary btn-sm" style="white-space: nowrap;">
                🔓 Unlock Vault
              </button>
            </form>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <form method="POST" action="settings.php">
      <input type="hidden" name="action" value="save_settings">

      <div class="settings-grid" style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem;">
        
        <!-- Left Column: Settings Cards -->
        <div style="display: flex; flex-direction: column; gap: 1.5rem;">

          <!-- Card 1: General Bot Configuration -->
          <div class="card">
            <h3 style="font-size: 1.05rem; font-weight: 700; margin-bottom: 1rem;">1. General Bot Identity &amp; State</h3>

            <div class="form-group" style="margin-bottom: 1rem;">
              <label class="form-label">Bot Public Display Name</label>
              <input type="text" name="bot_name" class="form-input" value="<?php echo htmlspecialchars($bot_name); ?>" required>
            </div>

            <div class="form-group" style="margin-bottom: 1rem;">
              <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                <input type="checkbox" name="bot_enabled" value="1" <?php echo ($bot_enabled === '1') ? 'checked' : ''; ?>>
                <span style="font-weight: 600;">Enable 24/7 Automated Responses</span>
              </label>
              <small style="color: var(--text-muted); display: block; margin-top: 0.25rem;">When active, incoming customer messages will be processed by decision tree rules.</small>
            </div>

            <div class="form-group" style="margin-bottom: 1rem;">
              <label class="form-label">Welcome Greeting Message</label>
              <textarea name="welcome_msg" class="form-textarea" rows="2" required><?php echo htmlspecialchars($welcome_msg); ?></textarea>
              <small style="color: var(--text-muted); display: block; margin-top: 0.25rem;">Sent when a user presses 'Get Started' or opens a new session.</small>
            </div>

            <div class="form-group" style="margin-bottom: 1rem;">
              <label class="form-label">Default Fallback Response</label>
              <textarea name="default_msg" class="form-textarea" rows="2" required><?php echo htmlspecialchars($default_msg); ?></textarea>
              <small style="color: var(--text-muted); display: block; margin-top: 0.25rem;">Sent when an incoming message doesn't trigger any keyword rule or flow option.</small>
            </div>

            <div class="form-group">
              <label class="form-label">Human Takeover Notification</label>
              <textarea name="human_handoff_msg" class="form-textarea" rows="2" required><?php echo htmlspecialchars($human_handoff_msg); ?></textarea>
              <small style="color: var(--text-muted); display: block; margin-top: 0.25rem;">Sent when an agent activates live takeover or user requests a human representative.</small>
            </div>
          </div>

          <!-- Card 2: Operating Hours & Auto-Reply -->
          <div class="card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
              <h3 style="font-size: 1.05rem; font-weight: 700; margin: 0;">2. 🕒 Smart Business Operating Hours</h3>
              <label style="display: flex; align-items: center; gap: 6px; cursor: pointer;">
                <input type="checkbox" name="business_hours_enabled" value="1" <?php echo ($business_hours_enabled === '1') ? 'checked' : ''; ?>>
                <span style="font-size: 0.825rem; font-weight: 600;">Enable Hours Check</span>
              </label>
            </div>

            <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 1rem;">
              Automatically route customer inquiries during off-hours or reply with custom operating time information.
            </p>

            <div style="margin-bottom: 1rem;">
              <label class="form-label">Operating Days:</label>
              <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                <?php foreach (['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] as $d): ?>
                  <label style="display: inline-flex; align-items: center; gap: 4px; font-size: 0.8rem; padding: 4px 8px; border: 1px solid var(--border); border-radius: var(--radius-sm); cursor: pointer; background: var(--bg-card-subtle);">
                    <input type="checkbox" name="business_days[]" value="<?php echo $d; ?>" <?php echo in_array($d, $saved_days) ? 'checked' : ''; ?>>
                    <span><?php echo $d; ?></span>
                  </label>
                <?php endforeach; ?>
              </div>
            </div>

            <div class="form-grid" style="grid-template-columns: 1fr 1fr 1fr; gap: 0.75rem; margin-bottom: 1rem;">
              <div class="form-group">
                <label class="form-label">Opens At:</label>
                <input type="time" name="business_start_time" class="form-input" value="<?php echo htmlspecialchars($business_start_time); ?>">
              </div>
              <div class="form-group">
                <label class="form-label">Closes At:</label>
                <input type="time" name="business_end_time" class="form-input" value="<?php echo htmlspecialchars($business_end_time); ?>">
              </div>
              <div class="form-group">
                <label class="form-label">Timezone:</label>
                <input type="text" name="business_timezone" class="form-input" value="<?php echo htmlspecialchars($business_timezone); ?>" placeholder="America/New_York">
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Automated Off-Hours Message:</label>
              <textarea name="off_hours_msg" class="form-textarea" rows="2"><?php echo htmlspecialchars($off_hours_msg); ?></textarea>
            </div>
          </div>

          <!-- Card 3: Instant Lead Alerts -->
          <div class="card">
            <h3 style="font-size: 1.05rem; font-weight: 700; margin-bottom: 0.5rem;">3. 🔔 Instant Lead Notifications</h3>
            <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 1rem;">
              Receive instant alerts whenever a user inputs their phone number, email, or requests a quote.
            </p>

            <div class="form-group" style="margin-bottom: 1rem;">
              <label class="form-label">Notification Email Address:</label>
              <input type="email" name="notify_email" class="form-input" value="<?php echo htmlspecialchars($notify_email); ?>" placeholder="admin@example.com">
            </div>

            <div class="form-grid" style="grid-template-columns: 1fr 1fr; gap: 0.75rem;">
              <div class="form-group">
                <label class="form-label">Telegram Bot Token (Optional):</label>
                <input type="text" name="notify_telegram_token" class="form-input" value="<?php echo htmlspecialchars($notify_telegram_token); ?>" placeholder="123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11">
              </div>
              <div class="form-group">
                <label class="form-label">Telegram Chat ID (Optional):</label>
                <input type="text" name="notify_telegram_chat_id" class="form-input" value="<?php echo htmlspecialchars($notify_telegram_chat_id); ?>" placeholder="@mychannel or 987654321">
              </div>
            </div>
          </div>

          <!-- Card 4: Optional AI Fallback Integration -->
          <div class="card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
              <h3 style="font-size: 1.05rem; font-weight: 700; margin: 0;">4. 🤖 Optional Smart AI Fallback Integration</h3>
              <label style="display: flex; align-items: center; gap: 6px; cursor: pointer;">
                <input type="checkbox" name="ai_fallback_enabled" value="1" <?php echo ($ai_fallback_enabled === '1') ? 'checked' : ''; ?>>
                <span style="font-size: 0.825rem; font-weight: 600;">Enable AI Fallback</span>
              </label>
            </div>
            <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 1rem;">
              When enabled, unmatched questions are answered using an LLM API rather than standard generic fallback.
            </p>

            <div class="form-grid" style="grid-template-columns: 1fr 1fr; gap: 0.75rem; margin-bottom: 1rem;">
              <div class="form-group">
                <label class="form-label">AI Engine Provider:</label>
                <select name="ai_provider" class="form-input">
                  <option value="gemini" <?php echo ($ai_provider === 'gemini') ? 'selected' : ''; ?>>Google Gemini (Fast &amp; Accurate)</option>
                  <option value="chatgpt" <?php echo ($ai_provider === 'chatgpt') ? 'selected' : ''; ?>>OpenAI ChatGPT (GPT-4o mini)</option>
                  <option value="deepseek" <?php echo ($ai_provider === 'deepseek') ? 'selected' : ''; ?>>DeepSeek V3 / R1</option>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">AI API Key (Vault Protected):</label>
                <?php if ($isVaultUnlocked): ?>
                  <input type="password" name="ai_api_key" class="form-input" value="<?php echo htmlspecialchars($ai_api_key); ?>" placeholder="AIzaSy... or sk-...">
                <?php else: ?>
                  <input type="text" class="form-input" value="••••••••••••••••••••" disabled style="opacity: 0.7; background: var(--bg-card-subtle);">
                <?php endif; ?>
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">AI Persona &amp; Grounding Instructions:</label>
              <textarea name="ai_system_prompt" class="form-textarea" rows="3"><?php echo htmlspecialchars($ai_system_prompt); ?></textarea>
              <small style="color: var(--text-muted); display: block; margin-top: 0.25rem;">Instruct the model on tone, key products, and boundaries.</small>
            </div>
          </div>

          <!-- Card 5: Meta Webhook Credentials (Vault Protected) -->
          <div class="card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
              <h3 style="font-size: 1.05rem; font-weight: 700; margin: 0;">5. Meta Graph API &amp; Webhook Credentials</h3>
              <?php if (!$isVaultUnlocked): ?>
                <span class="badge badge-primary" style="font-size: 0.75rem;">🛡️ Locked with Argon2id</span>
              <?php else: ?>
                <span class="badge badge-emerald" style="font-size: 0.75rem;">🔓 Unlocked for Editing</span>
              <?php endif; ?>
            </div>

            <div class="form-group" style="margin-bottom: 1rem;">
              <label class="form-label">Meta Verify Token</label>
              <?php if ($isVaultUnlocked): ?>
                <input type="text" name="verify_token" class="form-input font-mono" value="<?php echo htmlspecialchars($verify_token); ?>" required>
              <?php else: ?>
                <input type="text" class="form-input font-mono" value="••••••••••••••••••••••••••••••••••••••••" disabled style="opacity: 0.7; background: var(--bg-card-subtle);">
              <?php endif; ?>
            </div>

            <div class="form-group">
              <label class="form-label">Facebook Page Access Token</label>
              <?php if ($isVaultUnlocked): ?>
                <textarea name="page_access_token" class="form-textarea font-mono" rows="3" placeholder="EAAB... (Paste Page Access Token from developer.facebook.com)"><?php echo htmlspecialchars($page_access_token); ?></textarea>
              <?php else: ?>
                <textarea class="form-textarea font-mono" rows="3" disabled style="opacity: 0.7; background: var(--bg-card-subtle);">••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••</textarea>
              <?php endif; ?>
            </div>
          </div>

          <button type="submit" class="btn btn-primary" style="padding: 0.85rem 1.5rem; font-size: 0.95rem; font-weight: 700;">
            💾 Save All Bot Settings &amp; Configuration
          </button>
        </div>

        <!-- Right Column: Meta Quick Reference -->
        <div>
          <div class="card" style="margin-bottom: 1.5rem;">
            <h4 style="font-size: 0.95rem; font-weight: 700; margin-top: 0; margin-bottom: 0.75rem;">Meta Webhook Setup</h4>

            <div style="margin-bottom: 1rem;">
              <label class="form-label">Callback URL</label>
              <div style="display: flex; gap: 6px;">
                <input type="text" class="form-input font-mono" value="<?php echo htmlspecialchars($webhook_url); ?>" readonly style="font-size: 0.75rem;">
                <button type="button" class="btn btn-outline btn-sm" onclick="navigator.clipboard.writeText('<?php echo htmlspecialchars($webhook_url); ?>'); alert('Copied Callback URL!');">Copy</button>
              </div>
            </div>

            <div style="margin-bottom: 1rem;">
              <label class="form-label">Verify Token</label>
              <div style="display: flex; gap: 6px;">
                <?php if ($isVaultUnlocked): ?>
                  <input type="text" class="form-input font-mono" value="<?php echo htmlspecialchars($verify_token); ?>" readonly style="font-size: 0.75rem;">
                  <button type="button" class="btn btn-outline btn-sm" onclick="navigator.clipboard.writeText('<?php echo htmlspecialchars($verify_token); ?>'); alert('Copied Verify Token!');">Copy</button>
                <?php else: ?>
                  <input type="text" class="form-input font-mono" value="••••••••••••" readonly style="font-size: 0.75rem; opacity: 0.7;">
                <?php endif; ?>
              </div>
            </div>

            <div>
              <label class="form-label">Subscribed Webhook Fields:</label>
              <div style="font-size: 0.8rem; margin-top: 0.25rem; line-height: 1.6; color: var(--text-muted);">
                ✓ <code>messages</code><br>
                ✓ <code>messaging_postbacks</code><br>
                ✓ <code>messaging_optins</code>
              </div>
            </div>
          </div>

          <div class="card" style="margin-bottom: 1.5rem;">
            <h4 style="font-size: 0.95rem; font-weight: 700; margin-top: 0; margin-bottom: 0.75rem;">Database Host</h4>
            <div style="font-size: 0.8rem; line-height: 1.7; color: var(--text-muted);">
              <div><strong>Host:</strong> <?php echo htmlspecialchars(DB_HOST); ?></div>
              <div><strong>Database:</strong> <?php echo htmlspecialchars(DB_NAME); ?></div>
              <div><strong>User:</strong> <?php echo htmlspecialchars(DB_USER); ?></div>
            </div>
          </div>

          <div class="card" style="border-top: 3px solid #2563eb;">
            <h4 style="font-size: 0.95rem; font-weight: 700; margin-top: 0; margin-bottom: 0.5rem;">System Version</h4>
            <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 0.75rem;">
              Installed Build: <strong>v<?php echo htmlspecialchars(defined('APP_VERSION') ? APP_VERSION : '1.4.2'); ?></strong>
            </p>
            <a href="updates.php" class="btn btn-outline btn-sm" style="width: 100%; text-align: center; justify-content: center;">
              Check for Updates →
            </a>
          </div>
        </div>

      </div>
    </form>
  </main>
</body>
</html>
