<?php
/**
 * Interactive Conversation Simulator
 * Test Decision Tree Flows & Keywords Live in Browser
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';
requireLogin();

$pdo = db();

// Load start node
$startStmt = $pdo->query("SELECT * FROM flow_nodes WHERE is_start = 1 LIMIT 1");
$startNode = $startStmt->fetch(PDO::FETCH_ASSOC);
if (!$startNode) {
    $startNode = [
        'id' => 1,
        'node_name' => 'Main Greeting',
        'response_text' => 'Welcome to our 24/7 automated support! How may we assist you today?',
    ];
}

// Fetch all nodes, options, keywords, and catalog products for simulation
$allNodes = $pdo->query("SELECT id, node_key, node_name, response_text FROM flow_nodes")->fetchAll(PDO::FETCH_ASSOC);
$allOptions = $pdo->query("SELECT * FROM flow_options ORDER BY sort_order ASC")->fetchAll(PDO::FETCH_ASSOC);
$allKeywords = $pdo->query("SELECT keyword, match_type, node_id FROM keyword_triggers WHERE is_active = 1")->fetchAll(PDO::FETCH_ASSOC);
$allProducts = [];
try {
    $allProducts = $pdo->query("SELECT id, name, category, price, currency, description, image_url, action_label FROM products ORDER BY id ASC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {}

$optionsByNode = [];
foreach ($allOptions as $opt) {
    $optionsByNode[$opt['node_id']][] = $opt;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Conversation Simulator - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/app.css?v=1.4.0">
  <script src="../assets/js/admin.js?v=1.4.0" defer></script>
</head>
<body class="app-page">
  <?php renderAdminHeader('simulator'); ?>

  <main class="main-content">
    <header class="topbar">
      <div class="topbar-left">
        <span class="eyebrow">PREVIEW & TESTING</span>
        <h1 class="page-title">Interactive Simulator</h1>
        <p class="page-subtitle">Test decision tree flows and keywords live in the browser.</p>
      </div>

      <div class="topbar-right">
        <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
          🌙 Dark Mode
        </button>
        <button class="btn btn-outline btn-sm" onclick="resetChat()">
          🔄 Restart Simulation
        </button>
      </div>
    </header>

    <div class="simulator-grid">
      <!-- Left: How it works & Quick Test Tips -->
      <div>
        <div class="card">
          <h3 style="font-size: 1rem; font-weight: 700; margin-bottom: 0.75rem;">⚡ Instant Testing Tips</h3>
          <ul style="padding-left: 1.25rem; font-size: 0.875rem; color: var(--text-muted); line-height: 1.7;">
            <li>Click any <strong>Quick Reply Button</strong> in the phone mockup to test branching decision tree paths.</li>
            <li>Type any active keyword (e.g. <em>rates</em>, <em>hours</em>, <em>schedule</em>) into the input box to verify instant triggering.</li>
            <li>If you type something unmapped, the bot will respond with your <strong>Default Fallback Response</strong> configured in Settings.</li>
            <li>All button clicks and keyword matches execute in real-time using your database records.</li>
          </ul>
        </div>

        <div class="card">
          <h3 style="font-size: 1rem; font-weight: 700; margin-bottom: 0.75rem;">Active Rules in Memory</h3>
          <div style="display: flex; gap: 1rem;">
            <div style="padding: 1rem; background: var(--bg-subtle); border-radius: var(--radius-sm); flex: 1;">
              <div style="font-size: 0.75rem; color: var(--text-muted);">Flow Nodes</div>
              <div style="font-size: 1.5rem; font-weight: 700;"><?php echo count($allNodes); ?></div>
            </div>
            <div style="padding: 1rem; background: var(--bg-subtle); border-radius: var(--radius-sm); flex: 1;">
              <div style="font-size: 0.75rem; color: var(--text-muted);">Quick Reply Buttons</div>
              <div style="font-size: 1.5rem; font-weight: 700;"><?php echo count($allOptions); ?></div>
            </div>
            <div style="padding: 1rem; background: var(--bg-subtle); border-radius: var(--radius-sm); flex: 1;">
              <div style="font-size: 0.75rem; color: var(--text-muted);">Active Keywords</div>
              <div style="font-size: 1.5rem; font-weight: 700;"><?php echo count($allKeywords); ?></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Right: Mobile Phone Simulator Mockup -->
      <div>
        <div class="phone-mockup">
          <div class="phone-header">
            <div style="width: 32px; height: 32px; background: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #2563eb; font-weight: bold; font-size: 16px;">
              🤖
            </div>
            <div>
              <div style="font-weight: 700; font-size: 0.9rem;"><?php echo htmlspecialchars(APP_NAME); ?></div>
              <div style="font-size: 0.7rem; opacity: 0.85;">⚡ 24/7 Automated Support</div>
            </div>
          </div>

          <div class="phone-body" id="chat-stream">
            <!-- Messages added via JS -->
          </div>

          <div class="phone-footer">
            <input type="text" id="sim-input" class="form-control" placeholder="Type a message or keyword..." style="font-size: 0.8rem; padding: 0.45rem 0.75rem;" onkeypress="if(event.key==='Enter') sendSimMessage()">
            <button class="btn btn-primary btn-sm" onclick="sendSimMessage()" title="Send Message" aria-label="Send" style="display: inline-flex; align-items: center; justify-content: center; min-width: 40px; padding: 0 12px; white-space: nowrap; flex-shrink: 0;">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  </main>

  <script>
    const nodes = <?php echo json_encode($allNodes); ?>;
    const optionsByNode = <?php echo json_encode($optionsByNode); ?>;
    const keywords = <?php echo json_encode($allKeywords); ?>;
    const startNode = <?php echo json_encode($startNode); ?>;
    const products = <?php echo json_encode($allProducts); ?>;

    const stream = document.getElementById('chat-stream');

    function escapeHtml(str) {
      if (!str) return '';
      return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function renderBotBubble(text, options = []) {
      const bubble = document.createElement('div');
      bubble.className = 'bubble-bot';
      const cleanText = String(text || "").replace(/\{first_name\}|\{\{first_name\}\}/gi, "Maria").replace(/\{name\}|\{\{name\}\}/gi, "Maria Santos").replace(/\{last_name\}|\{\{last_name\}\}/gi, "Santos");
      bubble.textContent = cleanText;
      stream.appendChild(bubble);

      if (options && options.length > 0) {
        const tray = document.createElement('div');
        tray.className = 'quick-replies-tray';
        options.forEach(opt => {
          const btn = document.createElement('button');
          btn.className = 'quick-btn';
          btn.textContent = opt.option_label;
          btn.onclick = () => selectOption(opt);
          tray.appendChild(btn);
        });
        stream.appendChild(tray);
      }
      stream.scrollTop = stream.scrollHeight;
    }

    function renderProductCarousel(items) {
      if (!items || items.length === 0) return;
      const tray = document.createElement('div');
      tray.style.display = 'flex';
      tray.style.gap = '10px';
      tray.style.overflowX = 'auto';
      tray.style.padding = '8px 4px 12px';
      tray.style.maxWidth = '100%';
      tray.style.scrollbarWidth = 'thin';

      items.forEach(prod => {
        const card = document.createElement('div');
        card.style.flex = '0 0 190px';
        card.style.background = 'var(--bg-card)';
        card.style.border = '1px solid var(--border)';
        card.style.borderRadius = '12px';
        card.style.overflow = 'hidden';
        card.style.display = 'flex';
        card.style.flexDirection = 'column';
        card.style.boxShadow = '0 2px 8px rgba(0,0,0,0.12)';

        const curr = prod.currency === 'USD' ? '$' : (prod.currency === 'PHP' ? '₱' : prod.currency + ' ');
        const priceStr = curr + parseFloat(prod.price).toFixed(2);

        let imgHtml = '';
        if (prod.image_url) {
          imgHtml = `<img src="${escapeHtml(prod.image_url)}" style="width:100%; height:105px; object-fit:cover;">`;
        } else {
          imgHtml = `<div style="width:100%; height:90px; background:var(--bg-card-subtle); display:flex; align-items:center; justify-content:center; color:var(--text-muted); font-size:11px;">🛍️ Product Photo</div>`;
        }

        const safeTitle = escapeHtml(prod.name);
        const safeDesc = escapeHtml(prod.description || 'Quality product/service');
        const actionLabel = escapeHtml(prod.action_label || 'Order Now');

        card.innerHTML = `
          ${imgHtml}
          <div style="padding:8px 10px; flex:1; display:flex; flex-direction:column; justify-content:space-between;">
            <div>
              <div style="font-size:11px; font-weight:700; color:var(--text); line-height:1.3; margin-bottom:2px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${safeTitle}">${safeTitle}</div>
              <div style="font-size:11px; color:#10b981; font-weight:700; margin-bottom:4px;">${priceStr}</div>
              <div style="font-size:10px; color:var(--text-muted); line-height:1.4; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;">${safeDesc}</div>
            </div>
            <button type="button" class="btn btn-primary btn-sm" style="width:100%; margin-top:8px; padding:4px 6px; font-size:11px; font-weight:700;" onclick="selectProductOrder(${prod.id}, '${safeTitle.replace(/'/g, "\\'")}', '${priceStr}')">
              🛒 ${actionLabel}
            </button>
          </div>
        `;
        tray.appendChild(card);
      });
      stream.appendChild(tray);
      stream.scrollTop = stream.scrollHeight;
    }

    function selectProductOrder(prodId, prodName, prodPrice) {
      renderUserBubble('🛒 Order: ' + prodName);
      setTimeout(() => {
        renderBotBubble(`🎉 Excellent choice! We received your order inquiry for "${prodName}" (${prodPrice}).\n\nPlease type your Full Name, Email, or Phone below so our team can immediately confirm your request:`, [
          { option_label: '🏠 Main Menu', destination_node_id: startNode.id },
          { option_label: '💬 Speak to Agent', destination_node_id: null }
        ]);
      }, 350);
    }

    function renderUserBubble(text) {
      const bubble = document.createElement('div');
      bubble.className = 'bubble-user';
      const cleanText = String(text || "").replace(/\{first_name\}|\{\{first_name\}\}/gi, "Maria").replace(/\{name\}|\{\{name\}\}/gi, "Maria Santos").replace(/\{last_name\}|\{\{last_name\}\}/gi, "Santos");
      bubble.textContent = cleanText;
      stream.appendChild(bubble);
      stream.scrollTop = stream.scrollHeight;
    }

    function selectOption(opt) {
      renderUserBubble(opt.option_label);
      setTimeout(() => {
        const isCatalog = (opt.option_payload === 'PAYLOAD_CATALOG' || opt.option_label.toLowerCase().includes('catalog') || opt.option_label.toLowerCase().includes('rates') || opt.option_label.toLowerCase().includes('product'));
        const dest = nodes.find(n => n.id == opt.destination_node_id);

        if (dest) {
          const nextOptions = optionsByNode[dest.id] || [];
          renderBotBubble(dest.response_text, nextOptions);
          if ((isCatalog || dest.node_type === 'carousel') && products.length > 0) {
            renderProductCarousel(products);
          }
        } else {
          renderBotBubble("Thank you for choosing \"" + opt.option_label + "\". An agent or next step will process your request shortly.");
          if (isCatalog && products.length > 0) {
            renderProductCarousel(products);
          }
        }
      }, 400);
    }

    function sendSimMessage() {
      const input = document.getElementById('sim-input');
      const text = input.value.trim();
      if (!text) return;
      input.value = '';
      renderUserBubble(text);

      setTimeout(() => {
        const lower = text.toLowerCase();
        let matched = null;

        for (const kw of keywords) {
          const k = kw.keyword.toLowerCase();
          if (kw.match_type === 'exact' && lower === k) { matched = kw; break; }
          if (kw.match_type === 'contains' && lower.includes(k)) { matched = kw; break; }
          if (kw.match_type === 'phrase' && lower.includes(k)) { matched = kw; break; }
        }

        const isCatalogQuery = /\b(catalog|products|product|services|shop|store|buy|items)\b/i.test(lower);

        if (matched) {
          const target = nodes.find(n => n.id == matched.node_id);
          if (target) {
            const nextOptions = optionsByNode[target.id] || [];
            renderBotBubble(target.response_text, nextOptions);
            if ((isCatalogQuery || target.node_type === 'carousel') && products.length > 0) {
              renderProductCarousel(products);
            }
            return;
          }
        }

        if (isCatalogQuery && products.length > 0) {
          renderBotBubble("🛍️ Here are our featured products and services with live pricing. Swipe to view photos and tap below to order:", [
            { option_label: '🏠 Main Menu', destination_node_id: startNode.id },
            { option_label: '💬 Talk to Agent', destination_node_id: null }
          ]);
          renderProductCarousel(products);
          return;
        }

        renderBotBubble("Thank you for your inquiry! Our automated 24/7 bot has received your message: \"" + text + "\". Feel free to select from the options or an agent will follow up shortly.");
      }, 450);
    }

    function resetChat() {
      stream.innerHTML = '';
      const initialOptions = optionsByNode[startNode.id] || [];
      renderBotBubble(startNode.response_text, initialOptions);
    }

    // Initialize on load
    resetChat();
  </script>
</body>
</html>
