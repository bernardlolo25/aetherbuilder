<?php
/**
 * AJAX API Endpoint for System Updater
 * Handles GitHub update checks and 1-click upgrade execution
 */
@ini_set('display_errors', '0');
@error_reporting(0);
if (function_exists('ob_start')) {
    @ob_start();
}

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/updater.php';

function sendJson(array $data, int $statusCode = 200): void {
    if (function_exists('ob_get_length') && ob_get_length()) {
        @ob_clean();
    }
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

// Verify admin is authenticated (dual check with fallback)
$isAuthed = false;
if (function_exists('isLoggedIn')) {
    $isAuthed = isLoggedIn();
} elseif (!empty($_SESSION['admin_id'])) {
    $isAuthed = true;
}

if (!$isAuthed) {
    sendJson(['success' => false, 'error' => 'Unauthorized. Please sign in to install updates.'], 401);
}

$pdo = db();
$action = $_GET['action'] ?? $_POST['action'] ?? 'check';

try {
    if ($action === 'check') {
        $force = isset($_GET['force']) && $_GET['force'] === '1';
        $info = AppUpdater::checkForUpdates($pdo, $force);
        sendJson(array_merge(['success' => true], $info));
    }

    if ($action === 'get_system_info') {
        $info = AppUpdater::getSystemInfo();
        sendJson(['success' => true, 'system' => $info]);
    }

    if ($action === 'upload_update_zip') {
        $newVersion = trim($_POST['version'] ?? '1.5.7');
        $uploaded = $_FILES['update_zip'] ?? $_FILES['update_file'] ?? $_FILES['file'] ?? null;

        if (!$uploaded || empty($uploaded['tmp_name'])) {
            throw new Exception("No update zip archive received in upload request.");
        }

        $result = AppUpdater::applyUploadedZip($uploaded, $newVersion, $pdo);
        $result['redirect'] = 'dashboard.php?updated=1&v=' . urlencode($newVersion);
        sendJson($result);
    }

    if ($action === 'install') {
        $newVersion = trim($_POST['version'] ?? $_GET['version'] ?? '');
        $downloadUrl = trim($_POST['download_url'] ?? $_GET['download_url'] ?? '');

        if (empty($newVersion)) {
            $info = AppUpdater::checkForUpdates($pdo, false);
            $newVersion = $info['latest_version'] ?? '1.5.7';
            if (empty($downloadUrl)) {
                $downloadUrl = $info['download_url'] ?? '';
            }
        }

        // Apply update (scans local archives, then server-direct)
        $result = AppUpdater::applyUpdate($newVersion, $downloadUrl, $pdo);
        $result['redirect'] = 'dashboard.php?updated=1&v=' . urlencode($newVersion);
        sendJson($result);
    }

    if ($action === 'simulate') {
        $version = trim($_POST['version'] ?? '1.2.0');
        AppUpdater::setSimulatedUpdate($pdo, $version);
        sendJson([
            'success' => true, 
            'message' => "Simulated update v{$version} enabled.",
            'version' => $version
        ]);
    }

    if ($action === 'clear_simulate') {
        AppUpdater::clearSimulatedUpdate($pdo);
        sendJson(['success' => true, 'message' => 'Simulated update cleared.']);
    }

    if ($action === 'save_token') {
        $tok = trim($_POST['token'] ?? '');
        $stmt = $pdo->prepare("REPLACE INTO bot_settings (setting_key, setting_value) VALUES ('github_token', ?)");
        $stmt->execute([$tok]);
        $pdo->exec("DELETE FROM bot_settings WHERE setting_key IN ('update_check_cache', 'update_check_time')");
        sendJson(['success' => true, 'message' => 'Token saved and cache cleared.']);
    }

    throw new Exception("Unknown updater action: {$action}");

} catch (Throwable $e) {
    sendJson([
        'success' => false,
        'error' => $e->getMessage()
    ], 200);
}
