<?php
/**
 * AI Flow Studio Workspace
 * Embedded AI Workspace (ChatGPT / DeepSeek / Claude / Gemini) & 1-Click JSON Flow Importer
 * Single-Host Architecture Compatible
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';
requireLogin();

$pdo = db();
$msg = '';
$error = '';

// Handle Import & Template Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'import_json') {
        $jsonStr = trim($_POST['json_data'] ?? '');
        if (empty($jsonStr)) {
            $error = 'Please paste valid JSON flow data to import.';
        } else {
            $data = json_decode($jsonStr, true);
            if (!is_array($data)) {
                $error = 'Invalid JSON syntax. Please verify the AI response is valid JSON format.';
            } else {
                try {
                    $pdo->beginTransaction();

                    // Get or create active flow version
                    $stmtVer = $pdo->query("SELECT id FROM flow_versions WHERE status = 'published' LIMIT 1");
                    $versionId = $stmtVer->fetchColumn();
                    if (!$versionId) {
                        $pdo->exec("INSERT INTO flow_versions (version_name, status) VALUES ('AI Generated Flow', 'published')");
                        $versionId = $pdo->lastInsertId();
                    }

                    $nodeCount = 0;
                    $kwCount = 0;
                    $nodeKeyMap = [];

                    // Process Nodes
                    if (!empty($data['nodes']) && is_array($data['nodes'])) {
                        // Optional clear existing if checked
                        if (!empty($_POST['clear_existing'])) {
                            $pdo->exec("DELETE FROM flow_nodes WHERE version_id = {$versionId}");
                            $pdo->exec("DELETE FROM keyword_triggers");
                        }

                        $stmtNode = $pdo->prepare("INSERT INTO flow_nodes (version_id, node_key, node_name, node_type, response_text, is_start, is_active) 
                            VALUES (:ver, :key, :name, :type, :text, :start, 1)
                            ON DUPLICATE KEY UPDATE node_name = VALUES(node_name), node_type = VALUES(node_type), response_text = VALUES(response_text), is_start = VALUES(is_start)");

                        foreach ($data['nodes'] as $node) {
                            $key = preg_replace('/[^a-z0-9_]/', '_', strtolower($node['node_key'] ?? ('node_' . uniqid())));
                            $name = trim($node['node_name'] ?? ucfirst($key));
                            $type = in_array($node['node_type'] ?? '', ['message', 'menu', 'input', 'end']) ? $node['node_type'] : 'message';
                            $text = trim($node['response_text'] ?? '');
                            $isStart = !empty($node['is_start']) ? 1 : 0;

                            $stmtNode->execute([
                                ':ver' => $versionId,
                                ':key' => $key,
                                ':name' => $name,
                                ':type' => $type,
                                ':text' => $text,
                                ':start' => $isStart
                            ]);
                            $dbNodeId = $pdo->lastInsertId() ?: $pdo->query("SELECT id FROM flow_nodes WHERE version_id = {$versionId} AND node_key = '{$key}'")->fetchColumn();
                            $nodeKeyMap[$key] = $dbNodeId;
                            $nodeCount++;
                        }

                        // Process Options / Quick Replies
                        $stmtOpt = $pdo->prepare("INSERT INTO flow_options (node_id, option_label, option_payload, destination_node_id, sort_order) VALUES (:nid, :lbl, :pld, :did, :sort)");
                        foreach ($data['nodes'] as $node) {
                            $srcKey = preg_replace('/[^a-z0-9_]/', '_', strtolower($node['node_key'] ?? ''));
                            $srcId = $nodeKeyMap[$srcKey] ?? null;
                            if (!$srcId || empty($node['options']) || !is_array($node['options'])) continue;

                            $pdo->exec("DELETE FROM flow_options WHERE node_id = " . intval($srcId));
                            $sort = 1;
                            foreach ($node['options'] as $opt) {
                                $lbl = trim($opt['option_label'] ?? 'Option');
                                $pld = trim($opt['option_payload'] ?? ('PAYLOAD_' . strtoupper(substr(md5($lbl), 0, 8))));
                                $destKey = !empty($opt['destination_key']) ? preg_replace('/[^a-z0-9_]/', '_', strtolower($opt['destination_key'])) : null;
                                $destId = ($destKey && isset($nodeKeyMap[$destKey])) ? $nodeKeyMap[$destKey] : ($opt['destination_node_id'] ?? null);

                                $stmtOpt->execute([
                                    ':nid' => $srcId,
                                    ':lbl' => $lbl,
                                    ':pld' => $pld,
                                    ':did' => $destId ?: null,
                                    ':sort' => $sort++
                                ]);
                            }
                        }
                    }

                    // Process Keywords
                    if (!empty($data['keywords']) && is_array($data['keywords'])) {
                        $stmtKw = $pdo->prepare("INSERT INTO keyword_triggers (keyword, match_type, node_id, priority, is_active) VALUES (:kw, :match, :nid, :prio, 1)");
                        foreach ($data['keywords'] as $kw) {
                            $term = trim($kw['keyword'] ?? '');
                            if (empty($term)) continue;
                            $match = in_array($kw['match_type'] ?? '', ['exact', 'contains', 'phrase']) ? $kw['match_type'] : 'contains';
                            $prio = intval($kw['priority'] ?? 10);
                            $destKey = !empty($kw['destination_key']) ? preg_replace('/[^a-z0-9_]/', '_', strtolower($kw['destination_key'])) : null;
                            $nodeId = ($destKey && isset($nodeKeyMap[$destKey])) ? $nodeKeyMap[$destKey] : ($kw['node_id'] ?? null);

                            if (!$nodeId) {
                                // Default to start node or first node
                                $nodeId = reset($nodeKeyMap);
                            }

                            if ($nodeId) {
                                $stmtKw->execute([
                                    ':kw' => $term,
                                    ':match' => $match,
                                    ':nid' => $nodeId,
                                    ':prio' => $prio
                                ]);
                                $kwCount++;
                            }
                        }
                    }

                    $pdo->commit();
                    $msg = "🎉 Flow imported successfully! Created {$nodeCount} decision tree nodes and {$kwCount} keyword triggers.";
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) $pdo->rollBack();
                    $error = "Import failed: " . $e->getMessage();
                }
            }
        }
    } elseif ($action === 'load_template') {
        $tpl = $_POST['template'] ?? '';
        try {
            $pdo->beginTransaction();
            $stmtVer = $pdo->query("SELECT id FROM flow_versions WHERE status = 'published' LIMIT 1");
            $versionId = $stmtVer->fetchColumn() ?: 1;

            if ($tpl === 'ecommerce') {
                $nodes = [
                    ['key' => 'main_menu', 'name' => 'Store Welcome', 'type' => 'menu', 'text' => "🛍️ Welcome to our Online Store!\nHow can we assist you today?", 'start' => 1, 'opts' => [
                        ['label' => '📦 Browse Catalog', 'pld' => 'PAYLOAD_CATALOG', 'dest' => 'ecom_catalog'],
                        ['label' => '🚚 Track My Order', 'pld' => 'PAYLOAD_TRACK', 'dest' => 'ecom_track'],
                        ['label' => '🎟️ Discount Coupon', 'pld' => 'PAYLOAD_DISCOUNT', 'dest' => 'ecom_discount'],
                        ['label' => '👤 Talk to Agent', 'pld' => 'PAYLOAD_AGENT', 'dest' => 'live_agent_handoff']
                    ]],
                    ['key' => 'ecom_catalog', 'name' => 'Product Catalog', 'type' => 'message', 'text' => "Check out our featured categories:\n1. 👟 Footwear & Sneakers\n2. 👕 Apparel & Hoodies\n3. 🎒 Bags & Accessories\n\nVisit: https://yourstore.example.com", 'start' => 0, 'opts' => [
                        ['label' => '🎟️ Get 15% Off', 'pld' => 'PAYLOAD_DISCOUNT', 'dest' => 'ecom_discount'],
                        ['label' => '↩️ Main Menu', 'pld' => 'PAYLOAD_MENU', 'dest' => 'main_menu']
                    ]],
                    ['key' => 'ecom_track', 'name' => 'Order Tracking', 'type' => 'input', 'text' => "To track your shipment, please type your Order Number (e.g., #ORD-12345):", 'start' => 0, 'opts' => [
                        ['label' => '↩️ Main Menu', 'pld' => 'PAYLOAD_MENU', 'dest' => 'main_menu']
                    ]],
                    ['key' => 'ecom_discount', 'name' => 'VIP Discount Voucher', 'type' => 'end', 'text' => "🎉 Here is your exclusive 15% discount coupon: VIP15OFF.\nUse it at checkout on our website!", 'start' => 0, 'opts' => [
                        ['label' => '↩️ Main Menu', 'pld' => 'PAYLOAD_MENU', 'dest' => 'main_menu']
                    ]],
                    ['key' => 'live_agent_handoff', 'name' => 'Agent Handoff', 'type' => 'end', 'text' => "A human support specialist has been alerted and will respond shortly. Please leave your message below.", 'start' => 0, 'opts' => [
                        ['label' => '↩️ Main Menu', 'pld' => 'PAYLOAD_MENU', 'dest' => 'main_menu']
                    ]]
                ];

                $keywords = [
                    ['kw' => 'catalog, products, shop, shoes, store, items', 'match' => 'contains', 'dest' => 'ecom_catalog', 'prio' => 15],
                    ['kw' => 'track, order, package, shipping, where is', 'match' => 'contains', 'dest' => 'ecom_track', 'prio' => 18],
                    ['kw' => 'discount, promo, coupon, voucher, sale', 'match' => 'contains', 'dest' => 'ecom_discount', 'prio' => 20],
                    ['kw' => 'human, agent, representative, operator, real person', 'match' => 'contains', 'dest' => 'live_agent_handoff', 'prio' => 25],
                ];
            } elseif ($tpl === 'booking') {
                $nodes = [
                    ['key' => 'main_menu', 'name' => 'Consultation Welcome', 'type' => 'menu', 'text' => "👋 Welcome to our Booking & Consultation Assistant! How can we assist you?", 'start' => 1, 'opts' => [
                        ['label' => '📅 Book Appointment', 'pld' => 'PAYLOAD_BOOK', 'dest' => 'book_step1'],
                        ['label' => '💰 Service Rates', 'pld' => 'PAYLOAD_RATES', 'dest' => 'book_rates'],
                        ['label' => '📍 Location & Hours', 'pld' => 'PAYLOAD_HOURS', 'dest' => 'book_hours'],
                        ['label' => '📞 Speak with Reception', 'pld' => 'PAYLOAD_AGENT', 'dest' => 'live_agent_handoff']
                    ]],
                    ['key' => 'book_step1', 'name' => 'Appointment Request', 'type' => 'input', 'text' => "What date and time would you prefer for your appointment? Please type your preferred slot and phone number:", 'start' => 0, 'opts' => [
                        ['label' => '↩️ Main Menu', 'pld' => 'PAYLOAD_MENU', 'dest' => 'main_menu']
                    ]],
                    ['key' => 'book_rates', 'name' => 'Service Pricing', 'type' => 'message', 'text' => "Our standard session rates:\n• Initial Consultation: $49\n• Standard Session: $95\n• Comprehensive Package: $180", 'start' => 0, 'opts' => [
                        ['label' => '📅 Book Now', 'pld' => 'PAYLOAD_BOOK', 'dest' => 'book_step1'],
                        ['label' => '↩️ Main Menu', 'pld' => 'PAYLOAD_MENU', 'dest' => 'main_menu']
                    ]],
                    ['key' => 'book_hours', 'name' => 'Hours & Location', 'type' => 'message', 'text' => "📍 100 Main Street, Suite 400\n🕒 Mon-Fri: 9:00 AM – 6:00 PM\nSaturday: 10:00 AM – 2:00 PM\nSunday: Closed", 'start' => 0, 'opts' => [
                        ['label' => '📅 Book Now', 'pld' => 'PAYLOAD_BOOK', 'dest' => 'book_step1'],
                        ['label' => '↩️ Main Menu', 'pld' => 'PAYLOAD_MENU', 'dest' => 'main_menu']
                    ]],
                    ['key' => 'live_agent_handoff', 'name' => 'Reception Handoff', 'type' => 'end', 'text' => "Our receptionist has been notified and will reply shortly. Please type your inquiry below.", 'start' => 0, 'opts' => [
                        ['label' => '↩️ Main Menu', 'pld' => 'PAYLOAD_MENU', 'dest' => 'main_menu']
                    ]]
                ];

                $keywords = [
                    ['kw' => 'book, appointment, schedule, reserve, slot', 'match' => 'contains', 'dest' => 'book_step1', 'prio' => 20],
                    ['kw' => 'price, cost, rates, fee, pricing, how much', 'match' => 'contains', 'dest' => 'book_rates', 'prio' => 15],
                    ['kw' => 'hours, open, location, address, directions', 'match' => 'contains', 'dest' => 'book_hours', 'prio' => 12],
                    ['kw' => 'agent, operator, phone, human, receptionist', 'match' => 'contains', 'dest' => 'live_agent_handoff', 'prio' => 25],
                ];
            } else {
                throw new Exception("Unknown template selected.");
            }

            // Insert template
            $nodeMap = [];
            $stmtN = $pdo->prepare("INSERT INTO flow_nodes (version_id, node_key, node_name, node_type, response_text, is_start, is_active) 
                VALUES (?, ?, ?, ?, ?, ?, 1)
                ON DUPLICATE KEY UPDATE node_name=VALUES(node_name), node_type=VALUES(node_type), response_text=VALUES(response_text), is_start=VALUES(is_start)");

            foreach ($nodes as $n) {
                $stmtN->execute([$versionId, $n['key'], $n['name'], $n['type'], $n['text'], $n['start']]);
                $nodeMap[$n['key']] = $pdo->lastInsertId() ?: $pdo->query("SELECT id FROM flow_nodes WHERE version_id = {$versionId} AND node_key = '{$n['key']}'")->fetchColumn();
            }

            $stmtO = $pdo->prepare("INSERT INTO flow_options (node_id, option_label, option_payload, destination_node_id, sort_order) VALUES (?, ?, ?, ?, ?)");
            foreach ($nodes as $n) {
                $srcId = $nodeMap[$n['key']];
                $pdo->exec("DELETE FROM flow_options WHERE node_id = " . intval($srcId));
                $sort = 1;
                foreach ($n['opts'] as $o) {
                    $destId = $nodeMap[$o['dest']] ?? null;
                    $stmtO->execute([$srcId, $o['label'], $o['pld'], $destId, $sort++]);
                }
            }

            $stmtK = $pdo->prepare("INSERT INTO keyword_triggers (keyword, match_type, node_id, priority, is_active) VALUES (?, ?, ?, ?, 1)");
            foreach ($keywords as $k) {
                $destId = $nodeMap[$k['dest']] ?? reset($nodeMap);
                $stmtK->execute([$k['kw'], $k['match'], $destId, $k['prio']]);
            }

            $pdo->commit();
            $msg = "🚀 Template '" . ucfirst($tpl) . "' loaded successfully! Check Decision Trees tab to review.";
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = "Template load failed: " . $e->getMessage();
        }
    }
}

// Prepare Export Data
$exportData = ['nodes' => [], 'keywords' => []];
try {
    $dbNodes = $pdo->query("SELECT * FROM flow_nodes ORDER BY is_start DESC, id ASC")->fetchAll();
    foreach ($dbNodes as $n) {
        $opts = $pdo->query("SELECT * FROM flow_options WHERE node_id = " . intval($n['id']) . " ORDER BY sort_order ASC")->fetchAll();
        $formattedOpts = [];
        foreach ($opts as $o) {
            $destKey = null;
            if (!empty($o['destination_node_id'])) {
                $destKey = $pdo->query("SELECT node_key FROM flow_nodes WHERE id = " . intval($o['destination_node_id']))->fetchColumn();
            }
            $formattedOpts[] = [
                'option_label' => $o['option_label'],
                'option_payload' => $o['option_payload'],
                'destination_key' => $destKey
            ];
        }
        $exportData['nodes'][] = [
            'node_key' => $n['node_key'],
            'node_name' => $n['node_name'],
            'node_type' => $n['node_type'],
            'response_text' => $n['response_text'],
            'is_start' => (bool)$n['is_start'],
            'options' => $formattedOpts
        ];
    }

    $dbKws = $pdo->query("SELECT * FROM keyword_triggers ORDER BY priority DESC")->fetchAll();
    foreach ($dbKws as $k) {
        $destKey = $pdo->query("SELECT node_key FROM flow_nodes WHERE id = " . intval($k['node_id']))->fetchColumn();
        $exportData['keywords'][] = [
            'keyword' => $k['keyword'],
            'match_type' => $k['match_type'],
            'priority' => (int)$k['priority'],
            'destination_key' => $destKey
        ];
    }
} catch (Throwable $e) {}
$exportJsonStr = json_encode($exportData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

// Retrieve products & services from catalog for Instant Flow Prompt Builder
$catalogProducts = [];
try {
    $catalogProducts = $pdo->query("SELECT id, name, category, price, currency, description, features, image_url, action_label FROM products ORDER BY category ASC, name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AI Flow Studio - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/app.css?v=1.4.2">
  <script src="../assets/js/admin.js?v=1.4.2" defer></script>
  <style>
    .ai-tabs-bar {
      display: flex;
      gap: 8px;
      margin-bottom: 1.5rem;
      border-bottom: 1px solid var(--border);
      padding-bottom: 0.75rem;
      overflow-x: auto;
    }
    .ai-tab-btn {
      padding: 0.6rem 1.1rem;
      border-radius: var(--radius-sm);
      border: 1px solid var(--border);
      background: var(--bg-card);
      color: var(--text-muted);
      font-size: 0.825rem;
      font-weight: 600;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: all 0.15s ease;
      white-space: nowrap;
    }
    .ai-tab-btn:hover {
      color: var(--text);
      border-color: var(--primary);
    }
    .ai-tab-btn.active {
      background: var(--primary);
      color: #fff;
      border-color: var(--primary);
      box-shadow: 0 4px 10px rgba(37, 99, 235, 0.25);
    }
    .provider-toggle-bar {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px;
      background: var(--bg-card-subtle);
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
      margin-bottom: 12px;
      flex-wrap: wrap;
    }
    .provider-pill {
      padding: 6px 14px;
      border-radius: 999px;
      border: 1px solid var(--border);
      background: var(--bg-card);
      font-size: 0.775rem;
      font-weight: 600;
      cursor: pointer;
      color: var(--text-muted);
      transition: all 0.15s;
    }
    .provider-pill:hover {
      color: var(--text);
      border-color: var(--primary);
    }
    .provider-pill.active {
      background: #2563eb;
      color: #fff;
    .ai-launch-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 10px;
      margin-bottom: 1.25rem;
    }
    .ai-launch-card {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 14px;
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
      text-decoration: none;
      color: var(--text);
      transition: all 0.15s ease-in-out;
    }
    .ai-launch-card:hover {
      border-color: var(--primary);
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    .ai-launch-name {
      font-weight: 700;
      font-size: 0.825rem;
    }
    .ai-launch-desc {
      font-size: 0.7rem;
      color: var(--text-muted);
    }
  </style>
</head>
<body class="app-page">
  <?php renderAdminHeader('ai-studio'); ?>

  <main class="main-content">
    <header class="topbar">
      <div class="topbar-left">
        <span class="eyebrow">AI FLOW STUDIO</span>
        <h1 class="page-title">AI Flow Studio &amp; JSON Generator</h1>
        <p class="page-subtitle">Draft custom decision trees and keyword triggers using AI prompt generators (ChatGPT, DeepSeek, Claude, Gemini) or pre-built industry templates.</p>
      </div>

      <div class="topbar-right">
        <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
          🌙 Dark Mode
        </button>
        <a href="flow-builder.php" class="btn btn-outline btn-sm">
          View Decision Trees ↗
        </a>
      </div>
    </header>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <!-- AI Studio Navigation Tabs -->
    <div class="ai-tabs-bar">
      <button type="button" class="ai-tab-btn active" onclick="switchAITab('prompt-gen')">
        ⚡ Prompt &amp; Schema Generator
      </button>
      <button type="button" class="ai-tab-btn" onclick="switchAITab('json-import')">
        📥 1-Click JSON Flow Importer
      </button>
      <button type="button" class="ai-tab-btn" onclick="switchAITab('templates')">
        🚀 1-Click Industry Templates
      </button>
      <button type="button" class="ai-tab-btn" onclick="switchAITab('export')">
        📤 Export Flow JSON
      </button>
    </div>

    <!-- TAB 1: PROMPT & SCHEMA GENERATOR -->
    <div id="tab-prompt-gen" class="ai-tab-content">
      <!-- Direct External Launchers (Replaces non-functional iframes) -->
      <div class="card" style="margin-bottom: 1.25rem; background: linear-gradient(135deg, rgba(37,99,235,0.06) 0%, rgba(139,92,246,0.06) 100%); border-left: 4px solid var(--primary);">
        <div style="margin-bottom: 0.75rem;">
          <h3 class="card-title" style="margin: 0; font-size: 0.95rem;">🚀 Launch AI Assistant (Dedicated Window)</h3>
          <p style="font-size: 0.775rem; color: var(--text-muted); margin: 2px 0 0 0;">
            Major AI sites block embedded iframes via strict browser security policies. Click below to launch your favorite AI model in a dedicated tab:
          </p>
        </div>

        <div class="ai-launch-grid">
          <a href="https://chat.deepseek.com" target="_blank" rel="noopener noreferrer" class="ai-launch-card">
            <div>
              <div class="ai-launch-name">DeepSeek AI</div>
              <div class="ai-launch-desc">High-speed reasoning model</div>
            </div>
            <span style="font-size: 0.85rem; color: var(--primary);">↗</span>
          </a>
          <a href="https://chatgpt.com" target="_blank" rel="noopener noreferrer" class="ai-launch-card">
            <div>
              <div class="ai-launch-name">ChatGPT (OpenAI)</div>
              <div class="ai-launch-desc">GPT-4o conversational engine</div>
            </div>
            <span style="font-size: 0.85rem; color: var(--primary);">↗</span>
          </a>
          <a href="https://claude.ai" target="_blank" rel="noopener noreferrer" class="ai-launch-card">
            <div>
              <div class="ai-launch-name">Claude (Anthropic)</div>
              <div class="ai-launch-desc">Natural customer dialogue</div>
            </div>
            <span style="font-size: 0.85rem; color: var(--primary);">↗</span>
          </a>
          <a href="https://aistudio.google.com" target="_blank" rel="noopener noreferrer" class="ai-launch-card">
            <div>
              <div class="ai-launch-name">Google AI Studio</div>
              <div class="ai-launch-desc">Gemini structured prompts</div>
            </div>
            <span style="font-size: 0.85rem; color: var(--primary);">↗</span>
          </a>
        </div>
      </div>
      <div class="card" style="margin-bottom: 1.5rem;">
        <h3 class="card-title">Instant Flow Prompt Builder for AI</h3>
        <p style="font-size: 0.825rem; color: var(--text-muted); margin-bottom: 1.25rem;">
          Fill in your business details below to generate a perfectly formatted prompt. Paste it into ChatGPT or DeepSeek to get clean JSON ready for 1-click import.
        </p>

        <div class="form-grid" style="grid-template-columns: 1fr 1fr; margin-bottom: 1rem;">
          <div class="form-group">
            <label class="form-label">Business Name &amp; Industry:</label>
            <input type="text" id="gen-biz-name" class="form-input" value="Apex Dental &amp; Wellness Clinic" placeholder="e.g. Apex Real Estate">
          </div>
          <div class="form-group">
            <label class="form-label">Primary Goal:</label>
            <input type="text" id="gen-biz-goal" class="form-input" value="Appointment booking &amp; dental price inquiries" placeholder="e.g. Order tracking &amp; product discovery">
          </div>
        </div>

        <!-- Connected Products & Services Catalog Selector -->
        <?php if (!empty($catalogProducts)): ?>
        <div style="margin-bottom: 1.25rem; padding: 1rem; background: var(--bg-card-subtle); border: 1px solid var(--border); border-radius: var(--radius-sm);">
          <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px; margin-bottom: 0.75rem;">
            <div>
              <strong style="font-size: 0.875rem; color: var(--text);">📦 Products &amp; Services Catalog (<?php echo count($catalogProducts); ?> items)</strong>
              <div style="font-size: 0.75rem; color: var(--text-muted);">Select products to automatically include their names, pricing, and camera media links in the AI prompt:</div>
            </div>
            <div style="display: flex; gap: 6px;">
              <button type="button" class="btn btn-outline btn-sm" onclick="selectAllCatalog(true)" style="padding: 2px 8px; font-size: 0.725rem;">Select All</button>
              <button type="button" class="btn btn-outline btn-sm" onclick="selectAllCatalog(false)" style="padding: 2px 8px; font-size: 0.725rem;">Clear</button>
              <button type="button" class="btn btn-primary btn-sm" onclick="applyCatalogToPrompt()" style="padding: 2px 10px; font-size: 0.725rem;">✨ Insert Selected into Prompt</button>
            </div>
          </div>

          <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 8px; max-height: 220px; overflow-y: auto; padding-right: 4px;">
            <?php foreach ($catalogProducts as $prod): ?>
            <label style="display: flex; align-items: center; gap: 8px; padding: 6px 8px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 6px; cursor: pointer; font-size: 0.785rem; transition: border-color 0.15s;">
              <input type="checkbox" class="catalog-item-checkbox" 
                     data-id="<?php echo $prod['id']; ?>"
                     data-name="<?php echo htmlspecialchars($prod['name'], ENT_QUOTES); ?>"
                     data-category="<?php echo htmlspecialchars($prod['category'] ?? '', ENT_QUOTES); ?>"
                     data-price="<?php echo htmlspecialchars($prod['currency'] . ' ' . number_format((float)$prod['price'], 2), ENT_QUOTES); ?>"
                     data-desc="<?php echo htmlspecialchars($prod['description'] ?? '', ENT_QUOTES); ?>"
                     data-features="<?php echo htmlspecialchars($prod['features'] ?? '', ENT_QUOTES); ?>"
                     data-img="<?php echo htmlspecialchars(!empty($prod['image_url']) ? (strlen($prod['image_url']) > 100 ? 'Media Photo Attached' : $prod['image_url']) : '', ENT_QUOTES); ?>"
                     onchange="applyCatalogToPrompt()"
                     checked>
              <?php if (!empty($prod['image_url'])): ?>
                <img src="<?php echo htmlspecialchars($prod['image_url']); ?>" alt="" style="width: 32px; height: 32px; object-fit: cover; border-radius: 4px; border: 1px solid var(--border); flex-shrink: 0;">
              <?php else: ?>
                <span style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; background: rgba(37,99,235,0.1); color: var(--primary); border-radius: 4px; font-size: 0.85rem; flex-shrink: 0;">🏷️</span>
              <?php endif; ?>
              <div style="flex: 1; min-width: 0;">
                <div style="font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: var(--text);">
                  <?php echo htmlspecialchars($prod['name']); ?>
                </div>
                <div style="font-size: 0.7rem; color: var(--text-muted);">
                  <strong style="color: #10b981;"><?php echo htmlspecialchars($prod['currency'] . ' ' . number_format((float)$prod['price'], 2)); ?></strong> &bull; <?php echo htmlspecialchars($prod['category']); ?>
                </div>
              </div>
            </label>
            <?php endforeach; ?>
          </div>
        </div>
        <?php else: ?>
        <div style="margin-bottom: 1.25rem; padding: 0.75rem 1rem; background: var(--bg-card-subtle); border: 1px dashed var(--border); border-radius: var(--radius-sm); font-size: 0.8rem; color: var(--text-muted); display: flex; justify-content: space-between; align-items: center;">
          <span>💡 No products saved in catalog yet. You can add them with camera capture in the Products &amp; Services tab.</span>
          <a href="products.php" class="btn btn-outline btn-sm" style="font-size: 0.75rem; padding: 2px 8px;">+ Add Products</a>
        </div>
        <?php endif; ?>

        <div class="form-group" style="margin-bottom: 1.25rem;">
          <label class="form-label">Key Services, FAQs, or Offers (Comma-separated or bullet points):</label>
          <textarea id="gen-biz-details" class="form-textarea" rows="4" placeholder="e.g. Teeth Whitening ($120), Dental Implants ($850), Emergency Walk-in Hours, Insurance Accepted">Teeth Cleaning ($85), Teeth Whitening ($150), Dental Implants, Open Mon-Fri 9AM-6PM, Emergency Walk-in Accepted, Doctor Consultation.</textarea>
        </div>

        <button type="button" class="btn btn-primary btn-sm" onclick="buildAIPrompt()" style="margin-bottom: 1.5rem;">
          ⚡ Generate AI Prompt
        </button>

        <div style="position: relative;">
          <label class="form-label" style="display: flex; justify-content: space-between; align-items: center;">
            <span>Formatted AI Prompt (Copy and paste into ChatGPT or DeepSeek):</span>
            <button type="button" class="btn btn-outline btn-sm" onclick="copyPromptToClipboard()" style="padding: 2px 8px; font-size: 0.75rem;">
              📋 Copy Prompt
            </button>
          </label>
          <textarea id="output-ai-prompt" class="form-textarea" rows="10" readonly style="font-family: monospace; font-size: 0.8rem; background: var(--bg-card-subtle);"></textarea>
        </div>
      </div>
    </div>

    <!-- TAB 3: 1-CLICK JSON FLOW IMPORTER -->
    <div id="tab-json-import" class="ai-tab-content" style="display: none;">
      <div class="card" style="margin-bottom: 1.5rem;">
        <h3 class="card-title">1-Click JSON Flow &amp; Triggers Importer</h3>
        <p style="font-size: 0.825rem; color: var(--text-muted); margin-bottom: 1.25rem;">
          Paste the JSON object generated by ChatGPT, DeepSeek, or another bot backup below. The system will automatically build your decision tree nodes, quick reply buttons, and keyword triggers.
        </p>

        <form method="POST" action="ai-studio.php">
          <input type="hidden" name="action" value="import_json">

          <div class="form-group" style="margin-bottom: 1rem;">
            <label class="form-label">Flow JSON Data:</label>
            <textarea name="json_data" class="form-textarea" rows="12" placeholder='{\n  "nodes": [\n    {\n      "node_key": "main_menu",\n      "node_name": "Main Menu",\n      "node_type": "menu",\n      "response_text": "Welcome to our clinic! How may we assist you?",\n      "is_start": true,\n      "options": [\n        { "option_label": "📅 Book Appointment", "option_payload": "PAYLOAD_BOOK", "destination_key": "book_step" }\n      ]\n    }\n  ],\n  "keywords": [\n    { "keyword": "book, appointment, schedule", "match_type": "contains", "destination_key": "book_step", "priority": 15 }\n  ]\n}' required style="font-family: monospace; font-size: 0.8rem;"></textarea>
          </div>

          <div class="form-group" style="margin-bottom: 1.25rem;">
            <label style="display: flex; align-items: center; gap: 8px; font-size: 0.825rem; cursor: pointer;">
              <input type="checkbox" name="clear_existing" value="1">
              <span>Replace existing nodes &amp; keyword triggers (recommended for brand new templates)</span>
            </label>
          </div>

          <div style="display: flex; gap: 10px;">
            <button type="submit" class="btn btn-primary">
              📥 Import Decision Tree &amp; Triggers
            </button>
            <a href="flow-builder.php" class="btn btn-outline">
              Cancel
            </a>
          </div>
        </form>
      </div>
    </div>

    <!-- TAB 4: PRE-BUILT INDUSTRY TEMPLATES -->
    <div id="tab-templates" class="ai-tab-content" style="display: none;">
      <div style="margin-bottom: 1.5rem;">
        <h3 style="font-size: 1.15rem; font-weight: 700; margin-bottom: 0.25rem;">Instant Industry Bot Templates</h3>
        <p style="font-size: 0.825rem; color: var(--text-muted);">
          Deploy verified, multi-node decision trees with automated keyword routing in one single click.
        </p>
      </div>

      <div class="grid-2" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1.25rem; margin-bottom: 1.5rem;">
        <!-- Template 1: E-Commerce -->
        <div class="card" style="display: flex; flex-direction: column; justify-content: space-between;">
          <div>
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
              <span style="font-size: 1.75rem;">🛍️</span>
              <div>
                <strong style="font-size: 1rem;">E-Commerce &amp; Retail Shop</strong>
                <span class="badge badge-emerald" style="margin-left: 6px;">Ready to Deploy</span>
              </div>
            </div>
            <p style="font-size: 0.825rem; color: var(--text-muted); line-height: 1.5; margin-bottom: 12px;">
              Equipped with Product Catalog browsing, Shipment Order Tracking input, VIP 15% discount coupon voucher, and human live chat escalation.
            </p>
            <ul style="font-size: 0.775rem; color: var(--text-muted); padding-left: 1.2rem; line-height: 1.6; margin-bottom: 14px;">
              <li><strong>4 Nodes:</strong> Store Welcome, Catalog, Order Tracking, VIP Discount</li>
              <li><strong>3 Keyword Rules:</strong> 'catalog', 'track package', 'coupon'</li>
            </ul>
          </div>

          <form method="POST" action="ai-studio.php" onsubmit="return confirm('Load E-Commerce Template? Existing nodes will be preserved.');">
            <input type="hidden" name="action" value="load_template">
            <input type="hidden" name="template" value="ecommerce">
            <button type="submit" class="btn btn-primary btn-sm" style="width: 100%; justify-content: center;">
              🚀 1-Click Install E-Commerce Flow
            </button>
          </form>
        </div>

        <!-- Template 2: Appointment Booking -->
        <div class="card" style="display: flex; flex-direction: column; justify-content: space-between;">
          <div>
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
              <span style="font-size: 1.75rem;">📅</span>
              <div>
                <strong style="font-size: 1rem;">Appointments &amp; Consultations</strong>
                <span class="badge badge-primary" style="margin-left: 6px;">Popular</span>
              </div>
            </div>
            <p style="font-size: 0.825rem; color: var(--text-muted); line-height: 1.5; margin-bottom: 12px;">
              Ideal for clinics, law offices, salons, or consultants. Includes appointment requests, rates, opening hours, and reception handoff.
            </p>
            <ul style="font-size: 0.775rem; color: var(--text-muted); padding-left: 1.2rem; line-height: 1.6; margin-bottom: 14px;">
              <li><strong>5 Nodes:</strong> Consultation Welcome, Request Form, Rates, Hours, Reception</li>
              <li><strong>4 Keyword Rules:</strong> 'book appointment', 'pricing', 'hours', 'receptionist'</li>
            </ul>
          </div>

          <form method="POST" action="ai-studio.php" onsubmit="return confirm('Load Appointment Booking Template? Existing nodes will be preserved.');">
            <input type="hidden" name="action" value="load_template">
            <input type="hidden" name="template" value="booking">
            <button type="submit" class="btn btn-primary btn-sm" style="width: 100%; justify-content: center;">
              🚀 1-Click Install Booking Flow
            </button>
          </form>
        </div>
      </div>
    </div>

    <!-- TAB 5: EXPORT JSON -->
    <div id="tab-export" class="ai-tab-content" style="display: none;">
      <div class="card" style="margin-bottom: 1.5rem;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
          <div>
            <h3 class="card-title" style="margin: 0;">Export Current Bot Decision Tree</h3>
            <p style="font-size: 0.8rem; color: var(--text-muted); margin-top: 2px;">
              Export all your current decision tree nodes, quick reply links, and keyword triggers as JSON.
            </p>
          </div>
          <button type="button" class="btn btn-outline btn-sm" onclick="copyExportJson()">
            📋 Copy JSON
          </button>
        </div>

        <textarea id="export-json-textarea" class="form-textarea" rows="14" readonly style="font-family: monospace; font-size: 0.8rem; background: var(--bg-card-subtle);"><?php echo htmlspecialchars($exportJsonStr); ?></textarea>
      </div>
    </div>

  </main>

  <script>
    function switchAITab(tabId) {
      document.querySelectorAll('.ai-tab-content').forEach(el => el.style.display = 'none');
      document.querySelectorAll('.ai-tab-btn').forEach(btn => btn.classList.remove('active'));

      const target = document.getElementById('tab-' + tabId);
      if (target) target.style.display = 'block';

      const clickedBtn = Array.from(document.querySelectorAll('.ai-tab-btn')).find(b => b.getAttribute('onclick')?.includes(tabId));
      if (clickedBtn) clickedBtn.classList.add('active');
    }

    function buildAIPrompt() {
      const bizName = document.getElementById('gen-biz-name')?.value.trim() || 'Our Business';
      const goal = document.getElementById('gen-biz-goal')?.value.trim() || 'Customer Inquiries & Support';
      const details = document.getElementById('gen-biz-details')?.value.trim() || 'General Information';

      const prompt = `Act as an expert Conversational UX Architect for a Meta Facebook Messenger chatbot for "${bizName}".
The primary objective of the chatbot is: "${goal}".
Key business details, services, and FAQs:
${details}

Generate a complete Decision Tree flow and Keyword Trigger set formatted STRICTLY as a single valid JSON object with NO surrounding markdown or commentary.
Use this exact schema:

{
  "nodes": [
    {
      "node_key": "main_menu",
      "node_name": "Main Menu & Welcome",
      "node_type": "menu",
      "response_text": "Welcome to ${bizName}! How may we assist you today?",
      "is_start": true,
      "options": [
        {
          "option_label": "Button Label",
          "option_payload": "PAYLOAD_KEY",
          "destination_key": "target_node_key"
        }
      ]
    },
    {
      "node_key": "target_node_key",
      "node_name": "Node Title",
      "node_type": "message",
      "response_text": "Answer text for customer inquiry...",
      "is_start": false,
      "options": [
        {
          "option_label": "↩️ Back to Menu",
          "option_payload": "PAYLOAD_MENU",
          "destination_key": "main_menu"
        }
      ]
    }
  ],
  "keywords": [
    {
      "keyword": "comma, separated, search, terms",
      "match_type": "contains",
      "destination_key": "target_node_key",
      "priority": 15
    }
  ]
}

Ensure the response text is friendly, concise, and professional for Facebook Messenger.`;

      document.getElementById('output-ai-prompt').value = prompt;
    }

    function copyPromptToClipboard() {
      const promptEl = document.getElementById('output-ai-prompt');
      if (!promptEl || !promptEl.value) {
        buildAIPrompt();
      }
      navigator.clipboard.writeText(promptEl.value).then(() => {
        alert('Copied AI prompt to clipboard! You can now paste it into ChatGPT, DeepSeek, or Claude.');
      });
    }

    function copyExportJson() {
      const exportEl = document.getElementById('export-json-textarea');
      navigator.clipboard.writeText(exportEl.value).then(() => {
        alert('Copied Flow JSON to clipboard!');
      });
    }

    function selectAllCatalog(checked) {
      document.querySelectorAll('.catalog-item-checkbox').forEach(cb => {
        cb.checked = checked;
      });
      applyCatalogToPrompt();
    }

    function applyCatalogToPrompt() {
      const checkedBoxes = Array.from(document.querySelectorAll('.catalog-item-checkbox:checked'));
      if (checkedBoxes.length === 0) {
        buildAIPrompt();
        return;
      }

      let detailsText = "CATALOG OFFERINGS & SERVICES AVAILABLE:\n";
      checkedBoxes.forEach(cb => {
        const name = cb.dataset.name || '';
        const price = cb.dataset.price || '';
        const cat = cb.dataset.category ? `[${cb.dataset.category}] ` : '';
        const desc = cb.dataset.desc ? ` - ${cb.dataset.desc}` : '';
        const feat = cb.dataset.features ? ` (Features: ${cb.dataset.features.replace(/\n/g, ', ')})` : '';
        detailsText += `• ${cat}${name}: ${price}${desc}${feat}\n`;
      });

      const detailsEl = document.getElementById('gen-biz-details');
      if (detailsEl) {
        detailsEl.value = detailsText.trim();
      }

      buildAIPrompt();
    }

    // Auto-generate initial prompt on load with catalog items
    window.addEventListener('DOMContentLoaded', () => {
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.get('autofill') === '1' || urlParams.get('source') === 'products') {
        selectAllCatalog(true);
      } else {
        applyCatalogToPrompt();
      }
    });
  </script>
</body>
</html>
