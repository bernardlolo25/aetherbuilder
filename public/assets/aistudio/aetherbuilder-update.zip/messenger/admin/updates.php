<?php
/**
 * System Updates & Version Management Page
 * Single-Host Deployment Compatible
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/updater.php';
requireLogin();

$pdo = db();
$msg = '';
$error = '';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'simulate_update') {
        $nextVer = trim($_POST['sim_version'] ?? '1.2.0');
        AppUpdater::setSimulatedUpdate($pdo, $nextVer);
        $msg = "Simulated update for Version {$nextVer} activated! Notification banners and update buttons are now active.";
    } elseif ($action === 'clear_simulation') {
        AppUpdater::clearSimulatedUpdate($pdo);
        $msg = "Simulated update cleared. Now checking live update server.";
    } elseif ($action === 'save_token') {
        $newToken = trim($_POST['github_token'] ?? '');
        try {
            $stmt = $pdo->prepare("REPLACE INTO bot_settings (setting_key, setting_value) VALUES ('github_token', ?)");
            $stmt->execute([$newToken]);
            $pdo->exec("DELETE FROM bot_settings WHERE setting_key IN ('update_check_cache', 'update_check_time')");
            $msg = "GitHub Token saved successfully! Live GitHub release stream synchronized.";
            $_GET['check'] = '1';
        } catch (Throwable $e) {
            $error = "Failed to save token: " . $e->getMessage();
        }
    }
}

// Support 1-click token setup via query param (e.g. ?set_token=ghp_...)
if (!empty($_GET['set_token'])) {
    $paramToken = trim($_GET['set_token']);
    try {
        $stmt = $pdo->prepare("REPLACE INTO bot_settings (setting_key, setting_value) VALUES ('github_token', ?)");
        $stmt->execute([$paramToken]);
        $pdo->exec("DELETE FROM bot_settings WHERE setting_key IN ('update_check_cache', 'update_check_time')");
        $msg = "GitHub Token configured and saved successfully!";
        $_GET['check'] = '1';
    } catch (Throwable $e) {}
}

$currentVersion = AppUpdater::getCurrentVersion();
$versionData = AppUpdater::getVersionData();
$forceCheck = isset($_GET['check']) && $_GET['check'] === '1';
$activeToken = AppUpdater::getGitHubToken($pdo);
$updateInfo = AppUpdater::checkForUpdates($pdo, $forceCheck);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>System Updates & Versioning - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/app.css?v=1.5.7">
  <script src="../assets/js/admin.js?v=1.5.7" defer></script>
</head>
<body class="app-page">
  <?php renderAdminHeader('updates'); ?>

  <main class="main-content">
    <header class="topbar">
      <div class="topbar-left">
        <span class="eyebrow">LIFECYCLE & UPGRADES</span>
        <h1 class="page-title">System Updates & Versioning</h1>
        <p class="page-subtitle">Synchronize your chatbot dashboard with verified release packages and apply 1-click upgrades with live auto-refresh.</p>
      </div>

      <div class="topbar-right">
        <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
          🌙 Dark Mode
        </button>
        <a href="updates.php?check=1" class="btn btn-primary btn-sm">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>
          Check for Updates
        </a>
      </div>
    </header>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <!-- Tab Purpose & Usage Guide -->
    <div class="card" style="background: linear-gradient(135deg, rgba(37, 99, 235, 0.05) 0%, rgba(16, 185, 129, 0.03) 100%); border-left: 4px solid var(--primary); margin-bottom: 1.5rem; padding: 1.25rem 1.5rem;">
      <div style="display: flex; align-items: flex-start; gap: 12px;">
        <span style="font-size: 1.5rem; line-height: 1;">ℹ️</span>
        <div style="font-size: 0.825rem; line-height: 1.6;">
          <strong style="font-size: 0.95rem; color: var(--text); display: block; margin-bottom: 0.25rem;">
            Tab Purpose & How to Use System Updates
          </strong>
          <p style="margin: 0 0 0.5rem 0; color: var(--text-muted);">
            <strong>Purpose:</strong> Maintain your production chatbot with seamless, zero-downtime version upgrades. Whenever new enhancements, security patches, or Meta API updates are published, this engine pulls the new code, extracts updated assets, preserves your database and configuration passwords, and refreshes the browser automatically.
          </p>
          <div style="background: var(--bg-card); padding: 0.75rem 1rem; border-radius: var(--radius-sm); border: 1px solid var(--border);">
            <strong>How to Use:</strong>
            <ul style="margin: 0.25rem 0 0 0; padding-left: 1.2rem; color: var(--text-muted);">
              <li>Click <strong>Check for Updates</strong> at any time to verify if a newer build is available.</li>
              <li>When an amber <em>Important Update Available</em> banner appears, click <strong>Install Update Now</strong>.</li>
              <li>The system safely bypasses <code>config/config.php</code> so your Facebook tokens and database tables remain 100% intact.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <!-- Version Summary Cards -->
    <section class="stat-grid" style="margin-bottom: 1.5rem;">
      <div class="stat-card">
        <div class="stat-label">Installed Version</div>
        <div class="stat-value" style="display: flex; align-items: baseline; gap: 8px;">
          <span>v<?php echo htmlspecialchars($currentVersion); ?></span>
          <span class="badge badge-green" style="font-size: 0.75rem;">Stable</span>
        </div>
        <div class="stat-desc">Released: <?php echo htmlspecialchars($versionData['release_date'] ?? date('Y-m-d')); ?></div>
      </div>

      <div class="stat-card <?php echo !empty($updateInfo['has_update']) ? 'stat-warning' : 'stat-success'; ?>">
        <div class="stat-label">Latest Available Release</div>
        <div class="stat-value" style="display: flex; align-items: baseline; gap: 8px;">
          <span>v<?php echo htmlspecialchars($updateInfo['latest_version']); ?></span>
          <?php if (!empty($updateInfo['has_update'])): ?>
            <span class="badge badge-amber" style="font-size: 0.75rem;">Update Ready!</span>
          <?php else: ?>
            <span class="badge badge-green" style="font-size: 0.75rem;">Up to Date</span>
          <?php endif; ?>
        </div>
        <div class="stat-desc">
          <?php echo !empty($updateInfo['has_update']) ? 'New features available' : 'You are on the latest build'; ?>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-label">Update Channel</div>
        <div class="stat-value" style="font-size: 1.15rem; font-weight: 700; color: #2563eb;">
          Production Stable
        </div>
        <div class="stat-desc">Continuous Delivery Channel</div>
      </div>

      <div class="stat-card">
        <div class="stat-label">Safety Shield</div>
        <div class="stat-value" style="color: #10b981; font-size: 1.25rem;">
          Protected
        </div>
        <div class="stat-desc">DB config locked against overwrite</div>
      </div>
    </section>

    <!-- Two-Column Layout -->
    <div class="updates-grid">
      
      <!-- Left Column: Update Status & Installation -->
      <div>
        <?php if (!empty($updateInfo['has_update'])): ?>
          <!-- Upgrade Available Box -->
          <div class="card" style="border: 2px solid #f59e0b; background: linear-gradient(180deg, rgba(245, 158, 11, 0.04) 0%, transparent 100%); margin-bottom: 1.5rem;">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 1rem; margin-bottom: 1.25rem;">
              <div>
                <span class="badge badge-amber" style="margin-bottom: 0.5rem; display: inline-block;">NEW RELEASE AVAILABLE</span>
                <h2 style="font-size: 1.35rem; font-weight: 700; margin-bottom: 0.25rem;">
                  <?php echo htmlspecialchars($updateInfo['release_name'] ?? ('Version ' . $updateInfo['latest_version'])); ?>
                </h2>
                <p style="color: var(--text-muted); font-size: 0.85rem;">
                  Upgrades your installation from <code>v<?php echo htmlspecialchars($currentVersion); ?></code> to <code>v<?php echo htmlspecialchars($updateInfo['latest_version']); ?></code>.
                </p>
              </div>

              <button type="button" class="btn btn-primary" id="btn-main-update" onclick="startQuickUpdate('<?php echo htmlspecialchars($updateInfo['latest_version']); ?>', '<?php echo htmlspecialchars($updateInfo['download_url'] ?? ''); ?>', '<?php echo htmlspecialchars($activeToken); ?>')" style="padding: 0.75rem 1.4rem; font-size: 0.95rem; font-weight: 700; box-shadow: 0 4px 14px rgba(37, 99, 235, 0.35);">
                ⚡ Install Update Now
              </button>
            </div>

            <!-- Changelog -->
            <div style="background: var(--bg-card-subtle); border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 1.25rem; margin-bottom: 1rem;">
              <h4 style="font-size: 0.85rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); margin-bottom: 0.75rem;">
                What's New in this Release:
              </h4>
              <ul style="padding-left: 1.25rem; margin: 0; line-height: 1.7; font-size: 0.875rem;">
                <?php foreach (($updateInfo['changelog'] ?? []) as $note): ?>
                  <li><?php echo htmlspecialchars($note); ?></li>
                <?php endforeach; ?>
              </ul>
            </div>

            <div style="display: flex; align-items: center; justify-content: space-between; font-size: 0.8rem; color: var(--text-muted);">
              <span>🔒 Automatically reloads dashboard upon completion</span>
              <span>Source: Verified Release Mirror</span>
            </div>
          </div>
        <?php else: ?>
          <!-- Up to date box -->
          <div class="card" style="margin-bottom: 1.5rem; text-align: center; padding: 2.5rem 1.5rem;">
            <div style="display: inline-flex; align-items: center; justify-content: center; width: 64px; height: 64px; border-radius: 50%; background: rgba(16, 185, 129, 0.1); color: #10b981; font-size: 2rem; margin-bottom: 1rem;">
              ✓
            </div>
            <h2 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 0.5rem;">You are up to date!</h2>
            <p style="color: var(--text-muted); font-size: 0.875rem; max-width: 480px; margin: 0 auto 1.5rem;">
              Your Messenger Bot Dashboard is running the latest version (<strong>v<?php echo htmlspecialchars($currentVersion); ?></strong>). We'll notify you automatically whenever a new update is available.
            </p>
            <div style="display: flex; justify-content: center; gap: 0.75rem; flex-wrap: wrap;">
              <a href="updates.php?check=1" class="btn btn-outline btn-sm">
                🔄 Check for Updates
              </a>
              <a href="dashboard.php" class="btn btn-primary btn-sm">
                Return to Dashboard
              </a>
            </div>
          </div>
        <?php endif; ?>

        <!-- 1-Click ZIP Upload & Local Scan (Shared Host Firewall Bypass) -->
        <div class="card" style="border: 1px solid var(--border); margin-bottom: 1.5rem; background: var(--bg-card);">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.75rem;">
            <h3 class="card-title" style="margin: 0; display: flex; align-items: center; gap: 8px;">
              <span>📦 1-Click Update via ZIP Package</span>
              <span class="badge badge-green" style="font-size: 0.7rem;">Firewall Bypass</span>
            </h3>
            <span style="font-size: 0.75rem; color: var(--text-muted);">Zero-Data-Loss Shield Active</span>
          </div>
          
          <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 1rem; line-height: 1.5;">
            Ideal for free hosting environments (such as InfinityFree) where outbound cURL connections to GitHub are blocked by server firewalls. Upload your update archive or scan the server root for an existing zip.
          </p>

          <!-- Drag and Drop Upload Zone -->
          <div id="zip-drop-zone" style="border: 2px dashed var(--border); border-radius: var(--radius-sm); padding: 1.5rem 1rem; text-align: center; background: var(--bg-card-subtle); transition: all 0.2s ease; margin-bottom: 1rem;">
            <div style="font-size: 1.75rem; margin-bottom: 0.5rem;">📁</div>
            <p style="font-weight: 600; font-size: 0.9rem; margin-bottom: 0.25rem;">Drag &amp; Drop Update ZIP Here</p>
            <p style="font-size: 0.75rem; color: var(--text-muted); margin-bottom: 0.75rem;">
              Supports <code>Chat-Assistant-Bot-v<?php echo htmlspecialchars($updateInfo['latest_version']); ?>.zip</code> or <code>update.zip</code>
            </p>
            <label class="btn btn-primary btn-sm" style="cursor: pointer; display: inline-flex; align-items: center; gap: 6px;">
              <span>Select ZIP from Computer / Phone</span>
              <input type="file" id="page-zip-upload-input" accept=".zip" data-version="<?php echo htmlspecialchars($updateInfo['latest_version']); ?>" style="display: none;">
            </label>
          </div>

          <!-- Secondary Actions -->
          <div style="display: flex; gap: 0.75rem; flex-wrap: wrap; align-items: center; justify-content: space-between;">
            <button type="button" id="btn-scan-server-archive" data-version="<?php echo htmlspecialchars($updateInfo['latest_version']); ?>" class="btn btn-outline btn-sm">
              🔍 Scan Server Root for <code>update.zip</code>
            </button>
            <a href="https://github.com/<?php echo htmlspecialchars(AppUpdater::getGitHubRepo($pdo)); ?>/releases" target="_blank" rel="noopener" class="btn btn-ghost btn-sm" style="color: var(--text-muted);">
              ⬇️ Download from GitHub Releases ↗
            </a>
          </div>
          <div id="scan-archive-status" style="margin-top: 0.5rem; font-size: 0.8rem; color: var(--text-muted);"></div>
        </div>

        <!-- Version History / Changelog of current version -->
        <div class="card">
          <h3 class="card-title">Installed Version Metadata (v<?php echo htmlspecialchars($currentVersion); ?>)</h3>
          <div style="font-size: 0.875rem; line-height: 1.7;">
            <div style="margin-bottom: 0.75rem;">
              <strong>Installed Package:</strong> <?php echo htmlspecialchars($versionData['app_name'] ?? APP_NAME); ?><br>
              <strong>Build Identifier:</strong> <code><?php echo htmlspecialchars($versionData['build'] ?? 'release-stable'); ?></code><br>
              <strong>Current Channel:</strong> <code>stable</code>
            </div>

            <h4 style="font-size: 0.85rem; font-weight: 700; margin-top: 1rem; margin-bottom: 0.5rem;">Installed Features in this Build:</h4>
            <ul style="padding-left: 1.25rem; margin: 0; color: var(--text-muted);">
              <?php foreach (($versionData['changelog'] ?? []) as $item): ?>
                <li><?php echo htmlspecialchars($item); ?></li>
              <?php endforeach; ?>
            </ul>
          </div>
        </div>
      </div>

      <!-- Right Column: Settings & Testing Tools -->
      <div>
        <!-- Cloud Update Vault Status Card -->
        <div class="card" style="margin-bottom: 1.5rem;">
          <h3 class="card-title" style="display: flex; align-items: center; gap: 8px;">
            <span>🛡️ Update Stream Status</span>
          </h3>
          <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 1rem;">
            Updates are delivered from the developer's secured release repository with automatic checksum verification.
          </p>

          <div style="background: var(--bg-card-subtle); padding: 0.85rem 1rem; border-radius: var(--radius-sm); border: 1px solid var(--border); font-size: 0.8rem; line-height: 1.6; margin-bottom: 1rem;">
            <div><strong>Stream:</strong> <code>Production Main</code></div>
            <div><strong>Mode:</strong> 1-Click Zero Downtime</div>
            <div><strong>State:</strong> <span style="color: #10b981; font-weight: 600;">Active & Synced</span></div>
          </div>

          <a href="updates.php?check=1" class="btn btn-primary btn-sm" style="width: 100%; text-align: center; justify-content: center;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/></svg>
            Check for Updates Now
          </a>
        </div>

        <!-- GitHub Token Configuration for Private Repos -->
        <div class="card" style="margin-bottom: 1.5rem;">
          <h3 class="card-title" style="display: flex; align-items: center; gap: 8px;">
            <span>🔑 GitHub Token (Private Repo)</span>
          </h3>
          <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 0.75rem;">
            Since <code><?php echo htmlspecialchars(AppUpdater::getGitHubRepo($pdo)); ?></code> is a private repository, GitHub requires an authenticated Personal Access Token (PAT) with <code>repo</code> scope to query releases and version manifests.
          </p>

          <div style="background: var(--bg-card-subtle); padding: 0.75rem 1rem; border-radius: var(--radius-sm); border: 1px solid var(--border); font-size: 0.8rem; margin-bottom: 1rem;">
            <div><strong>Token Status:</strong> <?php if (!empty($activeToken)): ?>
              <span style="color: #10b981; font-weight: 600;">✓ Configured</span>
              <span style="color: var(--text-muted); font-size: 0.75rem; margin-left: 4px;">(<?php echo substr($activeToken, 0, 7) . '...' . substr($activeToken, -4); ?>)</span>
            <?php else: ?>
              <span style="color: #ef4444; font-weight: 600;">✗ Missing (Required for Private Repos)</span>
            <?php endif; ?></div>
          </div>

          <form method="POST" action="updates.php">
            <input type="hidden" name="action" value="save_token">
            <div style="margin-bottom: 0.75rem;">
              <label style="font-size: 0.75rem; font-weight: 600; text-transform: uppercase; color: var(--text-muted); display: block; margin-bottom: 0.25rem;">
                GitHub Personal Access Token:
              </label>
              <input type="password" name="github_token" value="<?php echo htmlspecialchars($activeToken); ?>" placeholder="ghp_..." style="width: 100%; padding: 0.5rem 0.75rem; font-size: 0.8rem; border-radius: var(--radius-sm); border: 1px solid var(--border); background: var(--bg-card); color: var(--text);" required>
            </div>
            <button type="submit" class="btn btn-outline btn-sm" style="width: 100%; justify-content: center;">
              Save Token &amp; Re-check
            </button>
          </form>
        </div>

      </div>

    </div>
  </main>
</body>
</html>
