<?php
/**
 * Keyword Triggers Management
 * Production Single-Host Architecture
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';
requireLogin();

$pdo = db();
$msg = '';
$error = '';

// Handle Keyword Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create_keyword') {
        $kw = trim($_POST['keyword'] ?? '');
        $match = $_POST['match_type'] ?? 'contains';
        $node_id = (int)($_POST['node_id'] ?? 0);
        $priority = (int)($_POST['priority'] ?? 10);

        if ($kw !== '' && $node_id > 0) {
            $stmt = $pdo->prepare("INSERT INTO keyword_triggers (keyword, match_type, node_id, priority, is_active) VALUES (:k, :m, :nid, :p, 1)");
            $stmt->execute([':k' => strtolower($kw), ':m' => $match, ':nid' => $node_id, ':p' => $priority]);
            $msg = "Keyword '{$kw}' saved successfully!";
        }
    }

    if ($action === 'toggle_active') {
        $id = (int)($_POST['keyword_id'] ?? 0);
        if ($id) {
            $curr = $pdo->prepare("SELECT is_active FROM keyword_triggers WHERE id = :id");
            $curr->execute([':id' => $id]);
            $val = $curr->fetchColumn() ? 0 : 1;
            $u = $pdo->prepare("UPDATE keyword_triggers SET is_active = :v WHERE id = :id");
            $u->execute([':v' => $val, ':id' => $id]);
            $msg = "Keyword status updated.";
        }
    }

    if ($action === 'delete_keyword') {
        $id = (int)($_POST['keyword_id'] ?? 0);
        if ($id) {
            $stmt = $pdo->prepare("DELETE FROM keyword_triggers WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $msg = "Keyword trigger removed.";
        }
    }
}

// Fetch keywords and nodes
$keywords = $pdo->query("SELECT k.*, n.node_name, n.node_key FROM keyword_triggers k JOIN flow_nodes n ON k.node_id = n.id ORDER BY k.priority DESC, k.id ASC")->fetchAll();
$nodes = $pdo->query("SELECT id, node_name, node_key FROM flow_nodes ORDER BY node_name ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Keyword Triggers - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/app.css?v=1.4.0">
  <script src="../assets/js/admin.js?v=1.4.0" defer></script>
</head>
<body class="app-page">
  <?php renderAdminHeader('keywords'); ?>

  <main class="main-content">
    <header class="topbar">
      <div class="topbar-left">
        <span class="eyebrow">TRIGGER RULES</span>
        <h1 class="page-title">Keyword Triggers</h1>
        <p class="page-subtitle">Instantly trigger responses and jump customers directly to relevant answers.</p>
      </div>

      <div class="topbar-right">
        <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
          🌙 Dark Mode
        </button>
        <a href="simulator.php" class="btn btn-primary btn-sm">
          📱 Test Simulator
        </a>
      </div>
    </header>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <!-- Tab Purpose & Usage Guide -->
    <div class="card" style="background: linear-gradient(135deg, rgba(37, 99, 235, 0.05) 0%, rgba(245, 158, 11, 0.03) 100%); border-left: 4px solid var(--primary); margin-bottom: 1.5rem; padding: 1.25rem 1.5rem;">
      <div style="display: flex; align-items: flex-start; gap: 12px;">
        <span style="font-size: 1.5rem; line-height: 1;">🔑</span>
        <div style="font-size: 0.825rem; line-height: 1.6;">
          <strong style="font-size: 0.95rem; color: var(--text); display: block; margin-bottom: 0.25rem;">
            Tab Purpose & How to Use Keyword Triggers
          </strong>
          <p style="margin: 0 0 0.5rem 0; color: var(--text-muted);">
            <strong>Purpose:</strong> Detect terms and phrases typed by customers into Messenger and automatically route them directly to the appropriate decision tree node, eliminating the need to search through menus manually.
          </p>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 0.75rem; margin-top: 0.75rem;">
            <div style="background: var(--bg-card); padding: 0.75rem 1rem; border-radius: var(--radius-sm); border: 1px solid var(--border);">
              <strong style="color: var(--primary);">What to Enter (Examples):</strong>
              <div style="color: var(--text-muted); font-size: 0.8rem; margin-top: 0.25rem;">
                • <strong>Keyword / Phrase:</strong> <code>fees</code> or <code>tuition</code> or <code>how much</code><br>
                • <strong>Match Type:</strong> <code>Contains</code> (matches sentences like "How much are the fees?")<br>
                • <strong>Route to Node:</strong> <code>Registration Rates & Fees</code><br>
                • <strong>Priority:</strong> <code>10 - 20</code> (higher priority checked first)
              </div>
            </div>
            <div style="background: var(--bg-card); padding: 0.75rem 1rem; border-radius: var(--radius-sm); border: 1px solid var(--border);">
              <strong style="color: var(--primary);">Common Essential Triggers:</strong>
              <div style="color: var(--text-muted); font-size: 0.8rem; margin-top: 0.25rem;">
                • <code>schedule</code>, <code>dates</code> → Jumps to Seminar Calendar<br>
                • <code>human</code>, <code>agent</code>, <code>staff</code> → Escalates to Live Chat<br>
                • <code>menu</code>, <code>restart</code> → Resets back to Main Menu (#start)<br>
                • <code>accredited</code>, <code>units</code> → Answers compliance requirements
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Add Keyword Form -->
    <div class="card">
      <h3 style="font-size: 1.05rem; font-weight: 700; margin-bottom: 1rem;">Add New Keyword Trigger</h3>
      <form method="POST" class="keyword-add-form">
        <input type="hidden" name="action" value="create_keyword">

        <div class="form-group" style="margin: 0;">
          <label class="form-label">Keyword or Phrase</label>
          <input type="text" name="keyword" class="form-control" placeholder="e.g. schedule, fee, discount" required>
        </div>

        <div class="form-group" style="margin: 0;">
          <label class="form-label">Match Type</label>
          <select name="match_type" class="form-control">
            <option value="contains">Contains (e.g. "what is schedule?")</option>
            <option value="exact">Exact (only the exact word)</option>
            <option value="phrase">Phrase (matches whole phrase)</option>
          </select>
        </div>

        <div class="form-group" style="margin: 0;">
          <label class="form-label">Destination Node Answer</label>
          <select name="node_id" class="form-control" required>
            <option value="">-- Choose Node --</option>
            <?php foreach ($nodes as $n): ?>
              <option value="<?php echo $n['id']; ?>"><?php echo htmlspecialchars($n['node_name']); ?> (#<?php echo htmlspecialchars($n['node_key']); ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group" style="margin: 0;">
          <label class="form-label">Priority</label>
          <input type="number" name="priority" class="form-control" value="10" min="1" max="100">
        </div>

        <button type="submit" class="btn btn-primary" style="height: 38px;">+ Add Trigger</button>
      </form>
    </div>

    <!-- Keyword List -->
    <div class="card">
      <h3 style="font-size: 1.05rem; font-weight: 700; margin-bottom: 1rem;">Active Keywords (<?php echo count($keywords); ?>)</h3>

      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>Trigger Word / Phrase</th>
              <th>Match Type</th>
              <th>Target Node Answer</th>
              <th>Priority</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($keywords)): ?>
              <tr>
                <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 2rem;">
                  No keyword triggers defined yet. Add keywords like "rates" or "hours" to jump users to answers.
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($keywords as $k): ?>
                <tr>
                  <td>
                    <span style="font-family: monospace; font-size: 0.9rem; font-weight: 700; color: var(--primary);">
                      "<?php echo htmlspecialchars($k['keyword']); ?>"
                    </span>
                  </td>
                  <td>
                    <span class="badge-pill"><?php echo htmlspecialchars($k['match_type']); ?></span>
                  </td>
                  <td>
                    <strong><?php echo htmlspecialchars($k['node_name']); ?></strong>
                    <span style="font-size: 0.75rem; color: var(--text-muted);"> (#<?php echo htmlspecialchars($k['node_key']); ?>)</span>
                  </td>
                  <td><?php echo $k['priority']; ?></td>
                  <td>
                    <form method="POST" style="margin: 0; display: inline;">
                      <input type="hidden" name="action" value="toggle_active">
                      <input type="hidden" name="keyword_id" value="<?php echo $k['id']; ?>">
                      <button type="submit" class="badge-pill <?php echo $k['is_active'] ? 'badge-green' : ''; ?>" style="cursor: pointer; border: 1px solid var(--border);">
                        <?php echo $k['is_active'] ? '● Active' : '○ Paused'; ?>
                      </button>
                    </form>
                  </td>
                  <td>
                    <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this keyword trigger?');">
                      <input type="hidden" name="action" value="delete_keyword">
                      <input type="hidden" name="keyword_id" value="<?php echo $k['id']; ?>">
                      <button type="submit" class="btn btn-outline btn-sm" style="color: var(--danger); border-color: var(--border-strong);">Delete</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</body>
</html>
