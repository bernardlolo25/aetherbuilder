<?php
/**
 * Conversations & Live Chat Takeover
 * Production Single-Host Architecture
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';
requireLogin();

$pdo = db();
$msg = '';
$error = '';

// Handle Human Takeover Toggle or Direct Message
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $conv_id = (int)($_POST['conversation_id'] ?? 0);

    if ($action === 'toggle_takeover' && $conv_id > 0) {
        $stmt = $pdo->prepare("SELECT human_takeover FROM conversations WHERE id = :id");
        $stmt->execute([':id' => $conv_id]);
        $curr = $stmt->fetchColumn();
        $next = ($curr == 1) ? 0 : 1;
        $uStmt = $pdo->prepare("UPDATE conversations SET human_takeover = :val WHERE id = :id");
        $uStmt->execute([':val' => $next, ':id' => $conv_id]);
        $msg = "Conversation #" . $conv_id . " takeover set to: " . ($next ? 'MANUAL TAKEOVER (Bot paused)' : 'AUTOMATED (Bot active)');
    }

    if ($action === 'send_reply' && $conv_id > 0) {
        $reply_text = trim($_POST['reply_text'] ?? '');
        if (!empty($reply_text)) {
            $cStmt = $pdo->prepare("SELECT page_scoped_id FROM conversations WHERE id = :id");
            $cStmt->execute([':id' => $conv_id]);
            $psid = $cStmt->fetchColumn();

            if ($psid) {
                $mStmt = $pdo->prepare("INSERT INTO messages (conversation_id, direction, message_text, message_type) VALUES (:cid, 'outgoing', :txt, 'text')");
                $mStmt->execute([':cid' => $conv_id, ':txt' => $reply_text]);

                require_once __DIR__ . '/../send_api.php';
                sendMessengerTextMessage($psid, $reply_text);
                $msg = "Reply logged & sent!";
            }
        }
    }
}

// Fetch conversations
$active_id = isset($_GET['view']) ? (int)$_GET['view'] : 0;
$conversations = $pdo->query("SELECT c.*, (SELECT message_text FROM messages WHERE conversation_id = c.id ORDER BY id DESC LIMIT 1) as last_msg FROM conversations c ORDER BY c.last_interaction DESC LIMIT 50")->fetchAll();

if ($active_id === 0 && !empty($conversations)) {
    $active_id = (int)$conversations[0]['id'];
}

$active_messages = [];
$active_conv = null;
if ($active_id > 0) {
    $aStmt = $pdo->prepare("SELECT * FROM conversations WHERE id = :id");
    $aStmt->execute([':id' => $active_id]);
    $active_conv = $aStmt->fetch();

    $mStmt = $pdo->prepare("SELECT * FROM messages WHERE conversation_id = :cid ORDER BY id ASC");
    $mStmt->execute([':cid' => $active_id]);
    $active_messages = $mStmt->fetchAll();
}

$cannedResponses = [];
try {
    $cannedResponses = $pdo->query("SELECT id, title, response_text FROM canned_responses ORDER BY category ASC, id ASC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Conversations - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/app.css?v=1.4.0">
  <script src="../assets/js/admin.js?v=1.4.0" defer></script>
</head>
<body class="app-page">
  <?php renderAdminHeader('conversations'); ?>

  <main class="main-content">
    <header class="topbar">
      <div class="topbar-left">
        <span class="eyebrow">CUSTOMER SUPPORT</span>
        <h1 class="page-title">Live Conversations</h1>
        <p class="page-subtitle">Review customer interactions and take over conversations when human support is needed.</p>
      </div>

      <div class="topbar-right">
        <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
          🌙 Dark Mode
        </button>
        <a href="simulator.php" class="btn btn-outline btn-sm">
          📱 Test Simulator
        </a>
      </div>
    </header>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <!-- Tab Purpose & Usage Guide -->
    <div class="card" style="background: linear-gradient(135deg, rgba(37, 99, 235, 0.05) 0%, rgba(16, 185, 129, 0.03) 100%); border-left: 4px solid var(--primary); margin-bottom: 1.25rem; padding: 1rem 1.25rem;">
      <div style="display: flex; align-items: flex-start; gap: 10px;">
        <span style="font-size: 1.35rem; line-height: 1;">💬</span>
        <div style="font-size: 0.8rem; line-height: 1.5;">
          <strong style="font-size: 0.9rem; color: var(--text); display: block; margin-bottom: 0.2rem;">
            Tab Purpose & How to Use Live Conversations
          </strong>
          <span style="color: var(--text-muted);">
            <strong>Purpose:</strong> Live monitoring and human intervention. View incoming messages from Facebook Messenger users in real time. Click <strong>Take Over</strong> to pause bot automation for a customer and reply manually; click <strong>Resume Bot</strong> once human assistance is concluded.
          </span>
        </div>
      </div>
    </div>

    <div class="conversations-grid">
      <!-- Left List -->
      <div class="card" style="overflow-y: auto; padding: 0.5rem; margin-bottom: 0;">
        <h4 style="font-size: 0.85rem; font-weight: 700; padding: 0.5rem 0.75rem; color: var(--text-muted); text-transform: uppercase;">
          Recent Chats (<?php echo count($conversations); ?>)
        </h4>

        <?php if (empty($conversations)): ?>
          <p style="padding: 1.5rem; text-align: center; color: var(--text-muted); font-size: 0.85rem;">No active customer conversations yet.</p>
        <?php else: ?>
          <?php foreach ($conversations as $c): ?>
            <a href="conversations.php?view=<?php echo $c['id']; ?>" style="text-decoration: none; color: inherit; padding: 0.75rem 1rem; border-bottom: 1px solid var(--border); display: block; border-radius: var(--radius-sm); <?php echo ($c['id'] == $active_id) ? 'background: var(--bg-hover); font-weight: 600;' : ''; ?>">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.25rem;">
                <?php 
                    $cCtx = !empty($c['context_data']) ? json_decode($c['context_data'], true) : [];
                    $cName = !empty($cCtx['name']) ? $cCtx['name'] : (!empty($cCtx['first_name']) ? $cCtx['first_name'] : ('User ' . substr($c['page_scoped_id'], 0, 8)));
                  ?>
                  <span style="font-size: 0.85rem; font-weight: 600;">👤 <?php echo htmlspecialchars($cName); ?></span>
                <span class="badge-pill <?php echo $c['human_takeover'] ? 'badge-blue' : 'badge-green'; ?>" style="font-size: 0.65rem;">
                  <?php echo $c['human_takeover'] ? 'Manual Takeover' : 'Bot Active'; ?>
                </span>
              </div>
              <div style="font-size: 0.8rem; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                <?php echo htmlspecialchars($c['last_msg'] ?? 'No messages'); ?>
              </div>
            </a>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <!-- Right Message Feed -->
      <div class="card" style="display: flex; flex-direction: column; padding: 0; overflow: hidden; margin-bottom: 0;">
        <?php if ($active_conv): ?>
          <div style="padding: 1rem 1.5rem; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; background: var(--bg-card);">
            <div>
              <div style="font-weight: 700; font-size: 0.95rem;">PSID: <?php echo htmlspecialchars($active_conv['page_scoped_id']); ?></div>
              <div style="font-size: 0.75rem; color: var(--text-muted);">
                Mode: <strong><?php echo $active_conv['human_takeover'] ? 'Human Staff Agent' : 'Automated 24/7 Bot'; ?></strong>
              </div>
            </div>

            <form method="POST" style="margin: 0;">
              <input type="hidden" name="action" value="toggle_takeover">
              <input type="hidden" name="conversation_id" value="<?php echo $active_conv['id']; ?>">
              <button type="submit" class="btn <?php echo $active_conv['human_takeover'] ? 'btn-success' : 'btn-danger'; ?> btn-sm">
                <?php echo $active_conv['human_takeover'] ? 'Resume 24/7 Bot' : 'Take Over Chat (Pause Bot)'; ?>
              </button>
            </form>
          </div>

          <div style="flex: 1; overflow-y: auto; padding: 1.5rem; display: flex; flex-direction: column; gap: 0.75rem; background: var(--bg-subtle);">
            <?php foreach ($active_messages as $m): ?>
              <div style="max-width: 70%; padding: 0.75rem 1rem; border-radius: 14px; font-size: 0.85rem; <?php echo ($m['direction'] === 'outgoing') ? 'margin-left: auto; background: var(--primary); color: white;' : 'margin-right: auto; background: var(--bg-card); border: 1px solid var(--border);'; ?>">
                <div><?php echo nl2br(htmlspecialchars($m['message_text'])); ?></div>
                <div style="font-size: 0.65rem; margin-top: 0.25rem; opacity: 0.75; text-align: right;">
                  <?php echo ($m['direction'] === 'outgoing' ? 'Agent/Bot • ' : 'Customer • ') . htmlspecialchars($m['created_at']); ?>
                </div>
              </div>
            <?php endforeach; ?>
          </div>

          <?php if (!empty($cannedResponses)): ?>
            <div style="padding: 0.5rem 1.25rem 0.25rem; background: var(--bg-card); display: flex; align-items: center; gap: 6px; overflow-x: auto; border-top: 1px solid var(--border);">
              <span style="font-size: 0.725rem; font-weight: 700; color: var(--text-muted); white-space: nowrap;">⚡ Quick Answers:</span>
              <?php foreach ($cannedResponses as $cr): ?>
                <button type="button" class="btn btn-outline btn-sm" style="font-size: 0.725rem; padding: 2px 9px; white-space: nowrap; border-radius: 999px;" onclick="insertCannedText(<?php echo htmlspecialchars(json_encode($cr['response_text']), ENT_QUOTES); ?>)" title="<?php echo htmlspecialchars($cr['response_text'], ENT_QUOTES); ?>">
                  <?php echo htmlspecialchars($cr['title']); ?>
                </button>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>

          <div style="padding: 0.75rem 1.25rem 1rem; border-top: 1px solid var(--border); background: var(--bg-card);">
            <form method="POST" style="display: flex; gap: 0.75rem; margin: 0;">
              <input type="hidden" name="action" value="send_reply">
              <input type="hidden" name="conversation_id" value="<?php echo $active_conv['id']; ?>">
              <input type="text" name="reply_text" class="form-control" placeholder="Type a message or click a Quick Answer above..." required style="flex: 1;">
              <button type="submit" class="btn btn-primary" title="Send Message" aria-label="Send" style="display: inline-flex; align-items: center; justify-content: center; min-width: 48px; padding: 0 16px; white-space: nowrap; flex-shrink: 0;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                  <line x1="22" y1="2" x2="11" y2="13"></line>
                  <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                </svg>
              </button>
            </form>
          </div>
        <?php else: ?>
          <div style="display: flex; align-items: center; justify-content: center; height: 100%; color: var(--text-muted); font-size: 0.9rem;">
            Select a conversation to review messages.
          </div>
        <?php endif; ?>
      </div>
    </div>
  </main>
  <script>
    function insertCannedText(text) {
      const input = document.querySelector('input[name="reply_text"]');
      if (input) {
        input.value = text;
        input.focus();
      }
    }
  </script>
</body>
</html>
