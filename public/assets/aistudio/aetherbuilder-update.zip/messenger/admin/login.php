<?php
/**
 * Admin Sign In
 * Production Single-Host Architecture
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

if (!empty($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    try {
        $stmt = db()->prepare("SELECT id, username, password_hash, role, is_active FROM admins WHERE username = ? LIMIT 1");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();

        if ($admin && (int)$admin['is_active'] === 1 && password_verify($password, $admin['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['admin_id'] = (int)$admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['admin_role'] = $admin['role'];
            db()->prepare("UPDATE admins SET last_login = NOW() WHERE id = ?")->execute([$admin['id']]);
            header('Location: dashboard.php');
            exit;
        }

        $error = 'Invalid username or password, or account is inactive.';
    } catch (Throwable $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sign In - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/app.css?v=1.4.0">
  <script src="../assets/js/admin.js?v=1.4.0" defer></script>
</head>
<body style="display: flex; align-items: center; justify-content: center; min-height: 100vh; background: var(--bg-page); padding: 1.5rem;">
  <div class="card" style="width: 100%; max-width: 420px; padding: 2.25rem; box-shadow: var(--shadow-lg);">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
      <div style="display: flex; align-items: center; gap: 0.75rem;">
        <div class="brand-mark" style="width: 36px; height: 36px;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
          </svg>
        </div>
        <div>
          <div style="font-weight: 700; font-size: 0.95rem; line-height: 1.2;"><?php echo htmlspecialchars(APP_NAME); ?></div>
          <div style="font-size: 0.7rem; color: var(--text-muted);">Enterprise Suite</div>
        </div>
      </div>
      <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
        🌙 Dark Mode
      </button>
    </div>

    <h2 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 0.25rem;">Administrator Sign In</h2>
    <p style="font-size: 0.8125rem; color: var(--text-muted); margin-bottom: 1.5rem;">Enter your credentials to access the 24/7 support control panel.</p>

    <?php if ($error): ?>
      <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" placeholder="admin" required autofocus>
      </div>

      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="••••••••" required>
      </div>

      <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 0.75rem; padding: 0.75rem;">
        Sign In to Dashboard
      </button>
    </form>

    <div style="margin-top: 1.5rem; display: flex; justify-content: space-between; font-size: 0.8125rem; padding-top: 1rem; border-top: 1px solid var(--border);">
      <a href="../reset-password.php" style="color: var(--primary);">Forgot password?</a>
      <a href="../setup.php" style="color: var(--text-muted);">Initial Setup</a>
    </div>

    <div style="margin-top: 1.25rem; text-align: center; font-size: 0.75rem; color: var(--text-muted);">
      Production Single-Host · 100% Rule-Based Messenger Engine
    </div>
  </div>
</body>
</html>
