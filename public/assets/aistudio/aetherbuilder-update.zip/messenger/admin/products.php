<?php
/**
 * Products & Services Catalog Management
 * Production Single-Host Architecture
 * Includes Built-in Device Camera Capture, Lightweight Photo Storage, and AI Flow Studio Connector
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';
requireLogin();

$pdo = db();
$msg = '';
$error = '';

// Ensure products table exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS products (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        category VARCHAR(100) DEFAULT 'Services',
        price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        currency VARCHAR(10) NOT NULL DEFAULT 'USD',
        description TEXT,
        sku VARCHAR(100) DEFAULT NULL,
        stock_status ENUM('available','in_stock','preorder','out_of_stock') NOT NULL DEFAULT 'available',
        features TEXT,
        image_url LONGTEXT,
        action_label VARCHAR(100) DEFAULT 'Order Now',
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        sort_order INT NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Self-healing: add missing columns to existing live tables
    try { $pdo->exec("ALTER TABLE products ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1"); } catch (\Throwable $e) {}
    try { $pdo->exec("ALTER TABLE products ADD COLUMN sort_order INT NOT NULL DEFAULT 0"); } catch (\Throwable $e) {}

    // Seed default sample products if table is currently empty
    $count = (int)$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    if ($count === 0) {
        $sampleStmt = $pdo->prepare("INSERT INTO products (name, category, price, currency, description, sku, stock_status, features, image_url, action_label) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $sampleStmt->execute([
            'Executive MCLE Compliance Bundle (36 Units)',
            'Legal Courses',
            199.00,
            'USD',
            'Complete accredited compliance bundle with ethics, trial advocacy, and digital certificates sent instantly.',
            'MCLE-EXEC-36',
            'available',
            "36 Accredited Credit Hours\nInstant Certificate Generation\nLifetime Video Access\nMobile Friendly",
            'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=600&q=80',
            'Order Compliance Bundle'
        ]);
        $sampleStmt->execute([
            'Legal Ethics & Professional Responsibility Pass',
            'Legal Courses',
            49.00,
            'USD',
            'Specialized 6-unit mandatory legal ethics intensive with interactive assessments and court compliance verification.',
            'MCLE-ETH-06',
            'available',
            "6 Mandatory Ethics Units\nState Bar Approved\nIncludes Self-Assessment Quiz",
            'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=600&q=80',
            'Enroll in Ethics Pass'
        ]);
        $sampleStmt->execute([
            'Private Corporate Legal Retainer & Consultation',
            'Consultation Services',
            450.00,
            'USD',
            '1-on-1 strategy and advisory session with senior partner for corporate restructuring, compliance audits, or IP.',
            'SRV-CONSULT-1HR',
            'available',
            "60-Minute Direct Partner Session\nWritten Action Memo\nConfidential NDA Coverage",
            'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=600&q=80',
            'Book Consultation'
        ]);
        $sampleStmt->execute([
            'Firm Enterprise Group License (Up to 25 Attorneys)',
            'Enterprise Packages',
            1850.00,
            'USD',
            'Centralized admin billing dashboard, bulk enrollment, firm-wide compliance reporting, and priority dedicated phone concierge.',
            'MCLE-CORP-25',
            'available',
            "Up to 25 Attorney Accounts\nCentral Manager Dashboard\nAutomated Bar Reporting\nDedicated Account Rep",
            'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=600&q=80',
            'Request Corporate Quote'
        ]);
    }
} catch (Throwable $e) {
    $error = "Database notice: " . $e->getMessage();
}

// Handle Form Submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create_product') {
        $name = trim($_POST['name'] ?? '');
        $category = trim($_POST['category'] ?? 'Services');
        $price = (float)($_POST['price'] ?? 0);
        $currency = trim($_POST['currency'] ?? 'USD');
        $description = trim($_POST['description'] ?? '');
        $sku = trim($_POST['sku'] ?? '');
        $stock_status = $_POST['stock_status'] ?? 'available';
        $features = trim($_POST['features'] ?? '');
        $image_url = trim($_POST['image_url'] ?? '');
        $action_label = trim($_POST['action_label'] ?? 'Order Now');

        if ($name !== '') {
            try {
                $stmt = $pdo->prepare("INSERT INTO products (name, category, price, currency, description, sku, stock_status, features, image_url, action_label) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $category, $price, $currency, $description, $sku, $stock_status, $features, $image_url, $action_label]);
                $msg = "Product '{$name}' added to catalog successfully!";
            } catch (Throwable $e) {
                $error = "Failed to add product: " . $e->getMessage();
            }
        } else {
            $error = "Product / Service Name is required.";
        }
    } elseif ($action === 'update_product') {
        $id = (int)($_POST['product_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $category = trim($_POST['category'] ?? 'Services');
        $price = (float)($_POST['price'] ?? 0);
        $currency = trim($_POST['currency'] ?? 'USD');
        $description = trim($_POST['description'] ?? '');
        $sku = trim($_POST['sku'] ?? '');
        $stock_status = $_POST['stock_status'] ?? 'available';
        $features = trim($_POST['features'] ?? '');
        $image_url = trim($_POST['image_url'] ?? '');
        $action_label = trim($_POST['action_label'] ?? 'Order Now');

        if ($id > 0 && $name !== '') {
            try {
                $stmt = $pdo->prepare("UPDATE products SET name = ?, category = ?, price = ?, currency = ?, description = ?, sku = ?, stock_status = ?, features = ?, image_url = ?, action_label = ? WHERE id = ?");
                $stmt->execute([$name, $category, $price, $currency, $description, $sku, $stock_status, $features, $image_url, $action_label, $id]);
                $msg = "Product '{$name}' updated successfully!";
            } catch (Throwable $e) {
                $error = "Failed to update product: " . $e->getMessage();
            }
        }
    } elseif ($action === 'delete_product') {
        $id = (int)($_POST['product_id'] ?? 0);
        if ($id > 0) {
            try {
                $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
                $stmt->execute([$id]);
                $msg = "Product deleted from catalog.";
            } catch (Throwable $e) {
                $error = "Failed to delete product: " . $e->getMessage();
            }
        }
    } elseif ($action === 'seed_samples') {
        try {
            $pdo->exec("DELETE FROM products");
            // Re-seed
            header("Location: products.php?seeded=1");
            exit;
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

// Fetch all products
$products = [];
try {
    $products = $pdo->query("SELECT * FROM products ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {}

$currentVersion = AppUpdater::getCurrentVersion();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Products & Services - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/app.css?v=<?php echo htmlspecialchars($currentVersion); ?>">
  <script src="../assets/js/admin.js?v=<?php echo htmlspecialchars($currentVersion); ?>" defer></script>
  <style>
    .catalog-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 1.25rem;
      margin-top: 1.25rem;
    }
    .product-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      overflow: hidden;
      display: flex;
      flex-col: column;
      flex-direction: column;
      box-shadow: 0 1px 3px rgba(0,0,0,0.06);
      transition: transform 0.2s, box-shadow 0.2s, border-color 0.2s;
    }
    .product-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      border-color: #3b82f6;
    }
    .product-thumb-wrap {
      position: relative;
      width: 100%;
      height: 160px;
      background: var(--bg-subtle);
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .product-thumb-wrap img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .price-pill {
      position: absolute;
      bottom: 8px;
      right: 8px;
      background: #2563eb;
      color: white;
      font-weight: 700;
      font-size: 0.8125rem;
      padding: 3px 8px;
      border-radius: 6px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.25);
    }
    .badge-category {
      position: absolute;
      top: 8px;
      left: 8px;
      background: rgba(0,0,0,0.65);
      backdrop-filter: blur(4px);
      color: white;
      font-size: 0.7rem;
      font-weight: 600;
      padding: 2px 7px;
      border-radius: 4px;
    }
    .card-body {
      padding: 1rem;
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .card-title {
      font-size: 0.9375rem;
      font-weight: 700;
      color: var(--text-main);
      margin: 0 0 0.35rem;
      line-height: 1.3;
    }
    .card-desc {
      font-size: 0.8125rem;
      color: var(--text-muted);
      margin: 0 0 0.75rem;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      line-height: 1.5;
    }
    .card-meta {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-top: 1px solid var(--border-color);
      padding-top: 0.75rem;
      margin-top: 0.5rem;
      font-size: 0.75rem;
    }
    .camera-modal {
      display: none;
      position: fixed;
      inset: 0;
      z-index: 99999;
      background: rgba(0,0,0,0.85);
      backdrop-filter: blur(5px);
      align-items: center;
      justify-content: center;
      padding: 1rem;
    }
    .camera-modal.active {
      display: flex;
    }
    .camera-box {
      background: var(--bg-card);
      border-radius: 16px;
      max-width: 540px;
      width: 100%;
      overflow: hidden;
      border: 1px solid var(--border-color);
      box-shadow: 0 20px 40px rgba(0,0,0,0.5);
    }
    .camera-viewport {
      position: relative;
      background: #000;
      width: 100%;
      aspect-ratio: 4/3;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
    }
    .camera-viewport video {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  </style>
</head>
<body class="app-page">
  <?php renderAdminHeader('products'); ?>

  <main class="main-content">
    <header class="topbar">
      <div class="topbar-left">
        <span class="eyebrow">CATALOG & OFFERINGS</span>
        <h1 class="page-title">Products & Services Management</h1>
        <p class="page-subtitle">Manage catalog items, pricing, photos with device camera capture, and generate AI flows in 1 click.</p>
      </div>

      <div class="topbar-right">
        <a href="ai-studio.php" class="btn btn-outline btn-sm" style="border-color: #8b5cf6; color: #8b5cf6;" title="Send products to AI flow builder">
          ✨ Open AI Flow Studio
        </a>
        <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
          🌙 Dark Mode
        </button>
        <button type="button" class="btn btn-primary btn-sm" onclick="openAddProductModal()">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
          Add Product / Service
        </button>
      </div>
    </header>

    <?php if ($msg): ?>
      <div class="alert alert-success" style="padding: 0.85rem 1.25rem; border-radius: var(--radius-sm); margin-bottom: 1.25rem; background: rgba(16, 185, 129, 0.12); border-left: 4px solid #10b981; color: #10b981; font-size: 0.875rem;">
        <?php echo htmlspecialchars($msg); ?>
      </div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div class="alert alert-danger" style="padding: 0.85rem 1.25rem; border-radius: var(--radius-sm); margin-bottom: 1.25rem; background: rgba(239, 68, 68, 0.12); border-left: 4px solid #ef4444; color: #ef4444; font-size: 0.875rem;">
        <?php echo htmlspecialchars($error); ?>
      </div>
    <?php endif; ?>

    <!-- Catalog Summary & AI Generation Action Card -->
    <div class="card" style="margin-bottom: 1.25rem; background: linear-gradient(135deg, rgba(37,99,235,0.08) 0%, rgba(139,92,246,0.08) 100%); border-color: rgba(99,102,241,0.25);">
      <div style="display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 1rem;">
        <div>
          <h3 style="margin: 0 0 0.25rem; font-size: 1rem; font-weight: 700; color: var(--text-main);">
            Connect Catalog to AI Messenger Flow Generator
          </h3>
          <p style="margin: 0; font-size: 0.8125rem; color: var(--text-muted);">
            Total Catalog Items: <strong><?php echo count($products); ?></strong>. Your products and prices are automatically available in the <strong>AI Flow Studio</strong> for instant ChatGPT, DeepSeek, and Claude prompt creation.
          </p>
        </div>
        <div style="display: flex; gap: 0.5rem;">
          <a href="ai-studio.php?autofill=1" class="btn btn-primary btn-sm">
            🚀 Generate Flow from Catalog
          </a>
        </div>
      </div>
    </div>

    <!-- Products Grid -->
    <?php if (empty($products)): ?>
      <div class="card" style="text-align: center; padding: 3rem 1rem;">
        <div style="font-size: 2.5rem; margin-bottom: 0.75rem;">📦</div>
        <h3 style="margin: 0 0 0.5rem; font-size: 1.1rem; font-weight: 700;">No Products in Catalog Yet</h3>
        <p style="margin: 0 0 1.25rem; font-size: 0.85rem; color: var(--text-muted); max-width: 460px; margin-left: auto; margin-right: auto;">
          Add your services, courses, or retail merchandise with descriptions, pricing, and photos from your camera or file upload.
        </p>
        <button type="button" class="btn btn-primary" onclick="openAddProductModal()">
          + Add Your First Product
        </button>
      </div>
    <?php else: ?>
      <div class="catalog-grid">
        <?php foreach ($products as $p): ?>
          <div class="product-card">
            <div class="product-thumb-wrap">
              <?php if (!empty($p['image_url'])): ?>
                <img src="<?php echo htmlspecialchars($p['image_url']); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>" loading="lazy">
              <?php else: ?>
                <div style="color: var(--text-muted); font-size: 0.75rem; text-align: center;">
                  <span style="font-size: 1.5rem; display: block; margin-bottom: 2px;">🖼</span>
                  No Photo Attached
                </div>
              <?php endif; ?>
              <span class="badge-category"><?php echo htmlspecialchars($p['category']); ?></span>
              <span class="price-pill">
                <?php 
                  $currSymbol = $p['currency'] === 'USD' ? '$' : ($p['currency'] === 'PHP' ? '₱' : ($p['currency'] === 'EUR' ? '€' : $p['currency'] . ' '));
                  echo $currSymbol . number_format((float)$p['price'], 2);
                ?>
              </span>
            </div>

            <div class="card-body">
              <div>
                <h4 class="card-title"><?php echo htmlspecialchars($p['name']); ?></h4>
                <p class="card-desc"><?php echo htmlspecialchars($p['description'] ?: 'No description provided.'); ?></p>
              </div>

              <div>
                <div class="card-meta">
                  <span style="color: var(--text-muted); font-family: monospace;">SKU: <?php echo htmlspecialchars($p['sku'] ?: 'N/A'); ?></span>
                  <div style="display: flex; gap: 6px;">
                    <button type="button" class="btn btn-outline btn-sm" style="padding: 3px 8px; font-size: 0.75rem;" onclick='editProduct(<?php echo json_encode($p, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>)'>
                      Edit
                    </button>
                    <form method="POST" style="margin: 0;" onsubmit="return confirm('Delete this product from catalog?');">
                      <input type="hidden" name="action" value="delete_product">
                      <input type="hidden" name="product_id" value="<?php echo (int)$p['id']; ?>">
                      <button type="submit" class="btn btn-danger btn-sm" style="padding: 3px 8px; font-size: 0.75rem;">
                        Delete
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <!-- Add / Edit Modal -->
    <div id="productModal" class="camera-modal">
      <div class="camera-box" style="max-width: 580px; max-height: 90vh; overflow-y: auto;">
        <div style="padding: 1rem 1.25rem; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; justify-content: space-between;">
          <h3 id="modalTitle" style="margin: 0; font-size: 0.95rem; font-weight: 700;">Add Product / Service</h3>
          <button type="button" onclick="closeProductModal()" style="background: none; border: none; font-size: 1.25rem; cursor: pointer; color: var(--text-muted);">&times;</button>
        </div>

        <form method="POST" style="padding: 1.25rem;">
          <input type="hidden" name="action" id="formAction" value="create_product">
          <input type="hidden" name="product_id" id="formProductId" value="">

          <div style="margin-bottom: 1rem;">
            <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Product / Service Name *</label>
            <input type="text" name="name" id="fieldName" required class="form-control" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);" placeholder="e.g. Legal Consultation, 36-Unit MCLE Bundle">
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; margin-bottom: 1rem;">
            <div>
              <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Category</label>
              <input type="text" name="category" id="fieldCategory" class="form-control" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);" placeholder="e.g. Courses, Retainers">
            </div>
            <div>
              <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">SKU / Code</label>
              <input type="text" name="sku" id="fieldSku" class="form-control" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);" placeholder="e.g. SRV-001">
            </div>
          </div>

          <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 0.75rem; margin-bottom: 1rem;">
            <div>
              <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Price *</label>
              <input type="number" step="any" min="0" name="price" id="fieldPrice" required class="form-control" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);" value="49.00">
            </div>
            <div>
              <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Currency</label>
              <select name="currency" id="fieldCurrency" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);">
                <option value="USD">USD ($)</option>
                <option value="PHP">PHP (₱)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
                <option value="CAD">CAD ($)</option>
                <option value="AUD">AUD ($)</option>
              </select>
            </div>
          </div>

          <div style="margin-bottom: 1rem;">
            <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Description</label>
            <textarea name="description" id="fieldDescription" rows="2" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);" placeholder="Summary of what the customer receives..."></textarea>
          </div>

          <!-- Photo & Camera Capture Section -->
          <div style="margin-bottom: 1rem;">
            <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Product Photo (Camera or Upload)</label>
            <div style="display: flex; gap: 0.75rem; align-items: center; margin-bottom: 0.5rem;">
              <button type="button" class="btn btn-outline btn-sm" onclick="openCameraModal()" style="border-color: #2563eb; color: #2563eb;">
                📸 Snap with Camera
              </button>
              <label class="btn btn-outline btn-sm" style="margin: 0; cursor: pointer;">
                📁 Choose Image File
                <input type="file" accept="image/*" style="display: none;" onchange="handleImageFileSelect(event)">
              </label>
            </div>
            <input type="text" name="image_url" id="fieldImageUrl" class="form-control" style="width: 100%; padding: 0.4rem 0.65rem; font-size: 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);" placeholder="Or paste image URL...">
            <div id="imagePreviewContainer" style="margin-top: 0.5rem; display: none;">
              <img id="imagePreview" src="" style="width: 90px; height: 70px; object-fit: cover; border-radius: 6px; border: 1px solid var(--border-color);">
            </div>
          </div>

          <div style="margin-bottom: 1.25rem;">
            <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Messenger Button Text</label>
            <input type="text" name="action_label" id="fieldActionLabel" value="Order Now" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);" placeholder="e.g. Order Now, Inquire Price">
          </div>

          <div style="display: flex; justify-content: flex-end; gap: 0.5rem;">
            <button type="button" class="btn btn-outline" onclick="closeProductModal()">Cancel</button>
            <button type="submit" class="btn btn-primary" id="modalSubmitBtn">Save Product</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Live Camera Capture Modal -->
    <div id="liveCameraModal" class="camera-modal">
      <div class="camera-box">
        <div style="padding: 0.75rem 1rem; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; justify-content: space-between;">
          <h4 style="margin: 0; font-size: 0.875rem; font-weight: 700;">📸 Camera Viewfinder</h4>
          <button type="button" onclick="closeCameraModal()" style="background: none; border: none; font-size: 1.25rem; color: #fff; cursor: pointer;">&times;</button>
        </div>
        <div class="camera-viewport">
          <video id="cameraVideo" autoplay playsinline muted></video>
          <canvas id="cameraCanvas" style="display: none;"></canvas>
        </div>
        <div style="padding: 0.75rem 1rem; display: flex; align-items: center; justify-content: space-between; background: var(--bg-subtle);">
          <button type="button" class="btn btn-outline btn-sm" onclick="switchCamera()">🔄 Switch Lens</button>
          <button type="button" class="btn btn-primary btn-sm" onclick="takeSnapshot()">📸 Take Snapshot</button>
        </div>
      </div>
    </div>
  </main>

  <script>
    let cameraStream = null;
    let currentFacingMode = 'environment';

    function openAddProductModal() {
      document.getElementById('formAction').value = 'create_product';
      document.getElementById('formProductId').value = '';
      document.getElementById('modalTitle').textContent = 'Add Product / Service';
      document.getElementById('modalSubmitBtn').textContent = 'Save Product';
      document.getElementById('fieldName').value = '';
      document.getElementById('fieldCategory').value = 'Services';
      document.getElementById('fieldSku').value = 'PROD-' + Math.floor(1000 + Math.random() * 9000);
      document.getElementById('fieldPrice').value = '49.00';
      document.getElementById('fieldDescription').value = '';
      document.getElementById('fieldImageUrl').value = '';
      document.getElementById('fieldActionLabel').value = 'Order Now';
      document.getElementById('imagePreviewContainer').style.display = 'none';
      document.getElementById('productModal').classList.add('active');
    }

    function editProduct(product) {
      document.getElementById('formAction').value = 'update_product';
      document.getElementById('formProductId').value = product.id;
      document.getElementById('modalTitle').textContent = 'Edit Product / Service';
      document.getElementById('modalSubmitBtn').textContent = 'Update Product';
      document.getElementById('fieldName').value = product.name || '';
      document.getElementById('fieldCategory').value = product.category || '';
      document.getElementById('fieldSku').value = product.sku || '';
      document.getElementById('fieldPrice').value = product.price || '';
      document.getElementById('fieldCurrency').value = product.currency || 'USD';
      document.getElementById('fieldDescription').value = product.description || '';
      document.getElementById('fieldImageUrl').value = product.image_url || '';
      document.getElementById('fieldActionLabel').value = product.action_label || 'Order Now';
      if (product.image_url) {
        document.getElementById('imagePreview').src = product.image_url;
        document.getElementById('imagePreviewContainer').style.display = 'block';
      } else {
        document.getElementById('imagePreviewContainer').style.display = 'none';
      }
      document.getElementById('productModal').classList.add('active');
    }

    function closeProductModal() {
      document.getElementById('productModal').classList.remove('active');
    }

    async function openCameraModal() {
      document.getElementById('liveCameraModal').classList.add('active');
      startCamera(currentFacingMode);
    }

    function closeCameraModal() {
      stopCamera();
      document.getElementById('liveCameraModal').classList.remove('active');
    }

    async function startCamera(mode) {
      stopCamera();
      try {
        cameraStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: mode, width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false
        });
        const video = document.getElementById('cameraVideo');
        video.srcObject = cameraStream;
      } catch (err) {
        alert('Could not access camera: ' + err.message + '. You may select an image file instead.');
        closeCameraModal();
      }
    }

    function stopCamera() {
      if (cameraStream) {
        cameraStream.getTracks().forEach(t => t.stop());
        cameraStream = null;
      }
    }

    function switchCamera() {
      currentFacingMode = currentFacingMode === 'environment' ? 'user' : 'environment';
      startCamera(currentFacingMode);
    }

    function takeSnapshot() {
      const video = document.getElementById('cameraVideo');
      const canvas = document.getElementById('cameraCanvas');
      if (!video || !canvas) return;

      const maxDim = 800;
      let w = video.videoWidth || 640;
      let h = video.videoHeight || 480;
      if (w > maxDim || h > maxDim) {
        if (w > h) { h = Math.round((h * maxDim) / w); w = maxDim; }
        else { w = Math.round((w * maxDim) / h); h = maxDim; }
      }
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0, w, h);

      const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.82);
      document.getElementById('fieldImageUrl').value = compressedDataUrl;
      document.getElementById('imagePreview').src = compressedDataUrl;
      document.getElementById('imagePreviewContainer').style.display = 'block';

      closeCameraModal();
    }

    function handleImageFileSelect(e) {
      const file = e.target.files && e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = function(evt) {
        const img = new Image();
        img.onload = function() {
          const canvas = document.createElement('canvas');
          const maxDim = 800;
          let w = img.width;
          let h = img.height;
          if (w > maxDim || h > maxDim) {
            if (w > h) { h = Math.round((h * maxDim) / w); w = maxDim; }
            else { w = Math.round((w * maxDim) / h); h = maxDim; }
          }
          canvas.width = w;
          canvas.height = h;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, w, h);
          const compressed = canvas.toDataURL('image/jpeg', 0.82);
          document.getElementById('fieldImageUrl').value = compressed;
          document.getElementById('imagePreview').src = compressed;
          document.getElementById('imagePreviewContainer').style.display = 'block';
        };
        img.src = evt.target.result;
      };
      reader.readAsDataURL(file);
    }
  </script>
</body>
</html>
