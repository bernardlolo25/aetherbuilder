<?php
/**
 * Approved 24/7 FAQ Responses & Knowledge Base
 * Production Single-Host Architecture
 * Pre-approved answers for common customer inquiries, service policies, and 1-click live agent replies.
 */

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';
requireLogin();

$pdo = db();
$msg = '';
$error = '';

// Ensure canned_responses table exists and seed defaults if empty
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS canned_responses (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        category VARCHAR(100) NOT NULL DEFAULT 'General',
        response_text TEXT NOT NULL,
        quick_replies TEXT DEFAULT NULL,
        tags VARCHAR(255) DEFAULT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_canned_cat (category)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $count = (int)$pdo->query("SELECT COUNT(*) FROM canned_responses")->fetchColumn();
    if ($count === 0) {
        $sampleStmt = $pdo->prepare("INSERT INTO canned_responses (title, category, response_text, quick_replies, tags, sort_order) VALUES (?, ?, ?, ?, ?, ?)");
        $sampleStmt->execute([
            '24/7 Support Commitment',
            'Support Policy',
            'Our automated assistant operates 24 hours a day, 7 days a week to provide immediate answers. Live representatives review all escalated inquiries Monday through Friday from 9 AM to 6 PM.',
            'View Pricing, Speak to Agent, Main Menu',
            '24/7, availability, support, hours',
            1
        ]);
        $sampleStmt->execute([
            'Certificate & Receipt Issuance',
            'Billing & Records',
            'All official certificates, receipts, and compliance confirmations are sent directly to your registered email address within 24 hours of successful processing.',
            'Submit Inquiry, Main Menu',
            'certificate, receipt, email, billing',
            2
        ]);
        $sampleStmt->execute([
            'Refund & Cancellation Policy',
            'Policies',
            'Cancellations requested at least 48 hours prior to scheduled live events are eligible for a 100% full refund or credit transfer to future sessions.',
            'Contact Support, Main Menu',
            'refund, cancel, policy, credit',
            3
        ]);
        $sampleStmt->execute([
            'MCLE Accreditation & State Bar Verification',
            'Compliance',
            'All compliance seminars and online modules are fully accredited and verified for mandatory legal education credit units with automated bar attendance reporting.',
            'View Packages, Enroll Now, Main Menu',
            'mcle, accredited, units, legal education',
            4
        ]);
    }
} catch (Throwable $e) {
    $error = "Database notice: " . $e->getMessage();
}

// Handle Form Submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create_response') {
        $title = trim($_POST['title'] ?? '');
        $category = trim($_POST['category'] ?? 'General');
        $response_text = trim($_POST['response_text'] ?? '');
        $quick_replies = trim($_POST['quick_replies'] ?? '');
        $tags = trim($_POST['tags'] ?? '');
        
        if ($title !== '' && $response_text !== '') {
            try {
                $stmt = $pdo->prepare("INSERT INTO canned_responses (title, category, response_text, quick_replies, tags) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$title, $category, $response_text, $quick_replies, $tags]);
                $msg = "Approved FAQ response '{$title}' added to Knowledge Base!";
            } catch (Throwable $e) {
                $error = "Failed to add response: " . $e->getMessage();
            }
        } else {
            $error = "Response Title and Full Message Text are required.";
        }
    } elseif ($action === 'update_response') {
        $id = (int)($_POST['response_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $category = trim($_POST['category'] ?? 'General');
        $response_text = trim($_POST['response_text'] ?? '');
        $quick_replies = trim($_POST['quick_replies'] ?? '');
        $tags = trim($_POST['tags'] ?? '');
        
        if ($id > 0 && $title !== '' && $response_text !== '') {
            try {
                $stmt = $pdo->prepare("UPDATE canned_responses SET title = ?, category = ?, response_text = ?, quick_replies = ?, tags = ? WHERE id = ?");
                $stmt->execute([$title, $category, $response_text, $quick_replies, $tags, $id]);
                $msg = "Approved FAQ response '{$title}' updated successfully!";
            } catch (Throwable $e) {
                $error = "Failed to update response: " . $e->getMessage();
            }
        } else {
            $error = "Response Title and Full Message Text are required.";
        }
    } elseif ($action === 'delete_response') {
        $id = (int)($_POST['response_id'] ?? 0);
        if ($id > 0) {
            try {
                $stmt = $pdo->prepare("DELETE FROM canned_responses WHERE id = ?");
                $stmt->execute([$id]);
                $msg = "Approved response deleted from Knowledge Base.";
            } catch (Throwable $e) {
                $error = "Failed to delete response: " . $e->getMessage();
            }
        }
    }
}

// Fetch all canned responses
$responses = [];
$categories = [];
try {
    $responses = $pdo->query("SELECT * FROM canned_responses ORDER BY category ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC);
    $categories = $pdo->query("SELECT DISTINCT category FROM canned_responses WHERE category != '' ORDER BY category ASC")->fetchAll(PDO::FETCH_COLUMN);
} catch (Throwable $e) {}

$currentVersion = AppUpdater::getCurrentVersion();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>FAQ Knowledge Base & Approved Responses - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/app.css?v=<?php echo htmlspecialchars($currentVersion); ?>">
  <script src="../assets/js/admin.js?v=<?php echo htmlspecialchars($currentVersion); ?>" defer></script>
  <style>
    .faq-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      gap: 1.25rem;
      margin-top: 1.25rem;
    }
    .faq-card {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 1.25rem;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      box-shadow: var(--shadow-sm);
      transition: transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease;
    }
    .faq-card:hover {
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
      border-color: var(--primary);
    }
    .faq-text-box {
      background: var(--bg-card-subtle);
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
      padding: 0.85rem 1rem;
      font-size: 0.825rem;
      line-height: 1.6;
      color: var(--text);
      margin: 0.75rem 0;
      white-space: pre-wrap;
      word-break: break-word;
    }
    .quick-replies-list {
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
      margin-top: 0.5rem;
    }
    .chip {
      font-size: 0.7rem;
      font-weight: 600;
      padding: 2px 8px;
      border-radius: 999px;
      background: rgba(37, 99, 235, 0.08);
      color: var(--primary);
      border: 1px solid rgba(37, 99, 235, 0.2);
    }
    .tag-badge {
      font-size: 0.675rem;
      color: var(--text-muted);
      background: var(--bg-card-subtle);
      border: 1px solid var(--border);
      padding: 2px 6px;
      border-radius: 4px;
    }
    .faq-modal-backdrop {
      display: none;
      position: fixed;
      inset: 0;
      z-index: 9999;
      background: rgba(0, 0, 0, 0.75);
      backdrop-filter: blur(4px);
      align-items: center;
      justify-content: center;
      padding: 1rem;
    }
    .faq-modal-backdrop.active {
      display: flex;
    }
    .faq-modal-card {
      background: var(--bg-card);
      border: 1px solid var(--border-strong);
      border-radius: var(--radius);
      width: 100%;
      max-width: 560px;
      box-shadow: var(--shadow-lg);
      overflow: hidden;
      max-height: 90vh;
      display: flex;
      flex-direction: column;
    }
  </style>
</head>
<body class="app-page">
  <?php renderAdminHeader('responses'); ?>
  <main class="main-content">
    <header class="topbar">
      <div class="topbar-left">
        <span class="eyebrow">APPROVED POLICIES & CANNED RESPONSES</span>
        <h1 class="page-title">24/7 FAQ Knowledge Base</h1>
        <p class="page-subtitle">Pre-approved answers to customer inquiries, policies, and instant 1-click live agent replies.</p>
      </div>
      <div class="topbar-right">
        <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
            Dark Mode
        </button>
        <a href="conversations.php" class="btn btn-outline btn-sm" title="View live chats">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
          Live Chats
        </a>
        <button type="button" class="btn btn-primary btn-sm" onclick="openAddFaqModal()">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
          Add Approved Answer
        </button>
      </div>
    </header>

    <?php if ($msg): ?>
      <div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <!-- Tab Purpose & Usage Guide Banner -->
    <div class="card" style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.05) 0%, rgba(37, 99, 235, 0.04) 100%); border-left: 4px solid #10b981; margin-bottom: 1.5rem; padding: 1.25rem 1.5rem;">
      <div style="display: flex; align-items: flex-start; gap: 12px;">
        <span style="font-size: 1.5rem; line-height: 1;">📚</span>
        <div style="font-size: 0.825rem; line-height: 1.6;">
          <strong style="font-size: 0.95rem; color: var(--text); display: block; margin-bottom: 0.25rem;">
            Tab Purpose & How to Use FAQ Knowledge Base
          </strong>
          <p style="margin: 0 0 0.5rem 0; color: var(--text-muted);">
            <strong>Purpose:</strong> Maintain verified, business-approved answers for common inquiries (operating policies, certificate deliveries, compliance verification, and refund procedures). Human staff taking over Facebook conversations can insert these verified responses into the reply box in 1 single click to eliminate typos and prevent policy violations.
          </p>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 0.75rem; margin-top: 0.75rem;">
            <div style="background: var(--bg-card); padding: 0.75rem 1rem; border-radius: var(--radius-sm); border: 1px solid var(--border);">
              <strong style="color: var(--primary);">1. Standardized Customer Answers</strong>
              <div style="color: var(--text-muted); font-size: 0.8rem; margin-top: 0.25rem;">
                Craft clear, lawyer-vetted or management-approved explanations so team members deliver consistent answers across every Messenger conversation.
              </div>
            </div>
            <div style="background: var(--bg-card); padding: 0.75rem 1rem; border-radius: var(--radius-sm); border: 1px solid var(--border);">
              <strong style="color: var(--primary);">2. 1-Click Clipboard & Live Chat Inserter</strong>
              <div style="color: var(--text-muted); font-size: 0.8rem; margin-top: 0.25rem;">
                Click <strong>Copy</strong> to paste anywhere, or navigate to <strong>Live Conversations</strong> where these answers appear right above the reply input!
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Metrics Cards -->
    <section class="stat-grid" style="margin-bottom: 1.5rem;">
      <div class="stat-card">
        <div class="stat-label">Approved FAQ Answers</div>
        <div class="stat-value"><?php echo count($responses); ?></div>
        <div class="stat-desc">Ready for live replies</div>
      </div>
      <div class="stat-card stat-success">
        <div class="stat-label">Active Categories</div>
        <div class="stat-value" style="color: #10b981;"><?php echo count($categories); ?></div>
        <div class="stat-desc">Organized topics</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Staff Response Speed</div>
        <div class="stat-value" style="color: #2563eb;">&lt; 5s</div>
        <div class="stat-desc">Instant 1-click insertion</div>
      </div>
      <div class="stat-card stat-warning">
        <div class="stat-label">Compliance Shield</div>
        <div class="stat-value" style="color: #f59e0b;">100%</div>
        <div class="stat-desc">Verified policy text</div>
      </div>
    </section>

    <!-- Search & Category Filter Bar -->
    <div class="card" style="margin-bottom: 1.25rem; padding: 0.85rem 1.25rem; display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 0.75rem;">
      <div style="position: relative; flex: 1; max-width: 380px;">
        <input type="text" id="faqSearchInput" onkeyup="filterFaqs()" placeholder="Search by title, keyword, policy, or tag..." class="form-input" style="width: 100%; padding-left: 2rem; font-size: 0.825rem;">
        <span style="position: absolute; left: 10px; top: 50%; transform: translateY(-50%); color: var(--text-muted); font-size: 0.85rem;">🔍</span>
      </div>
      <div style="display: flex; gap: 6px; flex-wrap: wrap;" id="categoryFilterBar">
        <button type="button" class="btn btn-primary btn-sm category-filter-btn" onclick="filterByCategory('all', this)">All (<?php echo count($responses); ?>)</button>
        <?php foreach ($categories as $cat): ?>
          <button type="button" class="btn btn-outline btn-sm category-filter-btn" onclick="filterByCategory('<?php echo htmlspecialchars($cat, ENT_QUOTES); ?>', this)">
            <?php echo htmlspecialchars($cat); ?>
          </button>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- FAQ Cards Grid -->
    <?php if (empty($responses)): ?>
      <div class="card" style="text-align: center; padding: 3rem 1rem;">
        <div style="font-size: 2.5rem; margin-bottom: 0.75rem;">📚</div>
        <h3 style="margin: 0 0 0.5rem; font-size: 1.1rem; font-weight: 700;">Knowledge Base is Empty</h3>
        <p style="margin: 0 0 1.25rem; font-size: 0.85rem; color: var(--text-muted); max-width: 440px; margin-left: auto; margin-right: auto;">
          Add common customer inquiries, pricing guidelines, delivery turnaround times, and policy statements.
        </p>
        <button type="button" class="btn btn-primary" onclick="openAddFaqModal()">
          + Add First FAQ Answer
        </button>
      </div>
    <?php else: ?>
      <div class="faq-grid" id="faqCardsContainer">
        <?php foreach ($responses as $r): ?>
          <div class="faq-card" data-category="<?php echo htmlspecialchars($r['category'], ENT_QUOTES); ?>" data-search="<?php echo htmlspecialchars(strtolower($r['title'] . ' ' . $r['category'] . ' ' . $r['response_text'] . ' ' . $r['tags']), ENT_QUOTES); ?>">
            <div>
              <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 8px;">
                <span class="badge badge-blue" style="font-size: 0.7rem; font-weight: 700;">
                  <?php echo htmlspecialchars($r['category']); ?>
                </span>
                <div style="display: flex; gap: 4px;">
                  <button type="button" class="btn btn-outline btn-sm" style="padding: 2px 7px; font-size: 0.725rem;" onclick="copyToClipboard('<?php echo htmlspecialchars(addslashes($r['response_text']), ENT_QUOTES); ?>', this)" title="Copy text to clipboard">
                    Copy
                  </button>
                  <button type="button" class="btn btn-outline btn-sm" style="padding: 2px 7px; font-size: 0.725rem;" onclick='editFaq(<?php echo json_encode($r, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>)' title="Edit Response">
                    Edit
                  </button>
                  <form method="POST" style="margin: 0;" onsubmit="return confirm('Delete this FAQ answer from Knowledge Base?');">
                    <input type="hidden" name="action" value="delete_response">
                    <input type="hidden" name="response_id" value="<?php echo (int)$r['id']; ?>">
                    <button type="submit" class="btn btn-outline btn-sm" style="padding: 2px 7px; font-size: 0.725rem; color: var(--danger); border-color: var(--border);" title="Delete Response">
                      ✕
                    </button>
                  </form>
                </div>
              </div>

              <h4 style="margin: 0.6rem 0 0; font-size: 0.95rem; font-weight: 700; color: var(--text);">
                <?php echo htmlspecialchars($r['title']); ?>
              </h4>

              <div class="faq-text-box">
                <?php echo nl2br(htmlspecialchars($r['response_text'])); ?>
              </div>

              <?php if (!empty($r['quick_replies'])): ?>
                <div style="margin-top: 0.5rem;">
                  <span style="font-size: 0.6875rem; text-transform: uppercase; font-weight: 700; color: var(--text-muted); display: block; margin-bottom: 2px;">
                    Suggested Quick Replies:
                  </span>
                  <div class="quick-replies-list">
                    <?php 
                      $chips = array_map('trim', explode(',', $r['quick_replies']));
                      foreach ($chips as $ch):
                        if (empty($ch)) continue;
                    ?>
                      <span class="chip"><?php echo htmlspecialchars($ch); ?></span>
                    <?php endforeach; ?>
                  </div>
                </div>
              <?php endif; ?>
            </div>

            <?php if (!empty($r['tags'])): ?>
              <div style="border-top: 1px solid var(--border); padding-top: 0.6rem; margin-top: 0.75rem; display: flex; flex-wrap: wrap; gap: 4px;">
                <?php 
                  $tagList = array_map('trim', explode(',', $r['tags']));
                  foreach ($tagList as $tag):
                    if (empty($tag)) continue;
                ?>
                  <span class="tag-badge">#<?php echo htmlspecialchars($tag); ?></span>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <!-- Add / Edit Modal -->
    <div id="faqModal" class="faq-modal-backdrop">
      <div class="faq-modal-card">
        <div style="padding: 1rem 1.25rem; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between;">
          <h3 id="modalTitle" style="margin: 0; font-size: 1rem; font-weight: 700; color: var(--text);">Add Approved FAQ Response</h3>
          <button type="button" onclick="closeFaqModal()" style="background: none; border: none; font-size: 1.25rem; cursor: pointer; color: var(--text-muted);">✕</button>
        </div>
        <form method="POST" style="padding: 1.25rem; overflow-y: auto;">
          <input type="hidden" name="action" id="formAction" value="create_response">
          <input type="hidden" name="response_id" id="formResponseId" value="">

          <div class="form-group" style="margin-bottom: 1rem;">
            <label class="form-label">Response Headline / Topic *</label>
            <input type="text" name="title" id="fieldTitle" required class="form-input" placeholder="e.g. Turnaround Time & Certificate Delivery">
          </div>

          <div class="form-group" style="margin-bottom: 1rem;">
            <label class="form-label">Category</label>
            <input type="text" name="category" id="fieldCategory" class="form-input" placeholder="e.g. Policies, Billing, MCLE Attendance" value="Support Policy">
          </div>

          <div class="form-group" style="margin-bottom: 1rem;">
            <label class="form-label">Approved Response Text (Sent to customer) *</label>
            <textarea name="response_text" id="fieldText" rows="4" required class="form-textarea" placeholder="The exact vetted message delivered to the customer..."></textarea>
          </div>

          <div class="form-group" style="margin-bottom: 1rem;">
            <label class="form-label">Quick Reply Buttons (Comma-separated)</label>
            <input type="text" name="quick_replies" id="fieldQuickReplies" class="form-input" placeholder="e.g. View Pricing, Speak with Agent, Main Menu">
            <small style="color: var(--text-muted); font-size: 0.725rem;">Buttons offered to customer after reading this answer.</small>
          </div>

          <div class="form-group" style="margin-bottom: 1.25rem;">
            <label class="form-label">Search Tags (Comma-separated)</label>
            <input type="text" name="tags" id="fieldTags" class="form-input" placeholder="e.g. 24/7, availability, hours, refund, certificate">
          </div>

          <div style="display: flex; justify-content: flex-end; gap: 0.5rem; border-top: 1px solid var(--border); padding-top: 1rem;">
            <button type="button" class="btn btn-outline" onclick="closeFaqModal()">Cancel</button>
            <button type="submit" class="btn btn-primary" id="modalSubmitBtn">Save FAQ Response</button>
          </div>
        </form>
      </div>
    </div>
  </main>

  <script>
    function openAddFaqModal() {
      document.getElementById('formAction').value = 'create_response';
      document.getElementById('formResponseId').value = '';
      document.getElementById('modalTitle').textContent = 'Add Approved FAQ Response';
      document.getElementById('modalSubmitBtn').textContent = 'Save FAQ Response';
      document.getElementById('fieldTitle').value = '';
      document.getElementById('fieldCategory').value = 'Support Policy';
      document.getElementById('fieldText').value = '';
      document.getElementById('fieldQuickReplies').value = 'Main Menu, Speak to Agent';
      document.getElementById('fieldTags').value = '';
      document.getElementById('faqModal').classList.add('active');
    }

    function editFaq(item) {
      document.getElementById('formAction').value = 'update_response';
      document.getElementById('formResponseId').value = item.id;
      document.getElementById('modalTitle').textContent = 'Edit Approved FAQ Response';
      document.getElementById('modalSubmitBtn').textContent = 'Update FAQ Response';
      document.getElementById('fieldTitle').value = item.title || '';
      document.getElementById('fieldCategory').value = item.category || 'General';
      document.getElementById('fieldText').value = item.response_text || '';
      document.getElementById('fieldQuickReplies').value = item.quick_replies || '';
      document.getElementById('fieldTags').value = item.tags || '';
      document.getElementById('faqModal').classList.add('active');
    }

    function closeFaqModal() {
      document.getElementById('faqModal').classList.remove('active');
    }

    let currentSelectedCategory = 'all';

    function filterByCategory(cat, btn) {
      currentSelectedCategory = cat;
      document.querySelectorAll('.category-filter-btn').forEach(b => {
        b.classList.remove('btn-primary');
        b.classList.add('btn-outline');
      });
      if (btn) {
        btn.classList.remove('btn-outline');
        btn.classList.add('btn-primary');
      }
      filterFaqs();
    }

    function filterFaqs() {
      const q = (document.getElementById('faqSearchInput')?.value || '').toLowerCase().trim();
      const cards = document.querySelectorAll('.faq-card');
      cards.forEach(card => {
        const cardCat = card.getAttribute('data-category') || '';
        const cardSearch = card.getAttribute('data-search') || '';
        const matchCat = (currentSelectedCategory === 'all' || cardCat.toLowerCase() === currentSelectedCategory.toLowerCase());
        const matchQuery = (!q || cardSearch.includes(q));
        card.style.display = (matchCat && matchQuery) ? 'flex' : 'none';
      });
    }
  </script>
</body>
</html>
