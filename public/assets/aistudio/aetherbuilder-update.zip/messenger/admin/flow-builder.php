<?php
/**
 * Decision Tree Flow Builder
 * Production Single-Host Architecture
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';
requireLogin();

$pdo = db();
$msg = '';
$error = '';

// Self-healing database migration: ensure flow_nodes.node_type supports 'carousel' and modern types
try {
    $pdo->exec("ALTER TABLE flow_nodes MODIFY COLUMN node_type VARCHAR(50) NOT NULL DEFAULT 'message'");
} catch (Throwable $e) {
    try {
        $pdo->exec("ALTER TABLE flow_nodes MODIFY COLUMN node_type ENUM('message','menu','input','end','carousel') NOT NULL DEFAULT 'message'");
    } catch (Throwable $e2) {}
}

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create_node') {
        $node_name = trim($_POST['node_name'] ?? '');
        $node_key = trim($_POST['node_key'] ?? '');
        $node_type = $_POST['node_type'] ?? 'message';
        $response_text = trim($_POST['response_text'] ?? '');
        $is_start = isset($_POST['is_start']) ? 1 : 0;

        if ($node_name && $node_key) {
            // Ensure at least one flow version exists
            $vStmt = $pdo->query("SELECT id FROM flow_versions LIMIT 1");
            $version_id = $vStmt ? $vStmt->fetchColumn() : null;
            if (!$version_id) {
                $pdo->exec("INSERT INTO flow_versions (version_name, status) VALUES ('Initial Flow v1', 'published')");
                $version_id = $pdo->lastInsertId();
            }

            if ($is_start) {
                $pdo->prepare("UPDATE flow_nodes SET is_start = 0 WHERE version_id = :vid")->execute([':vid' => $version_id]);
            }

            $stmt = $pdo->prepare("INSERT INTO flow_nodes (version_id, node_key, node_name, node_type, response_text, is_start, is_active) 
                VALUES (:vid, :k, :name, :type, :resp, :start, 1)
                ON DUPLICATE KEY UPDATE node_name = :name2, node_type = :type2, response_text = :resp2, is_start = :start2");
            $stmt->execute([
                ':vid' => $version_id,
                ':k' => $node_key,
                ':name' => $node_name,
                ':type' => $node_type,
                ':resp' => $response_text,
                ':start' => $is_start,
                ':name2' => $node_name,
                ':type2' => $node_type,
                ':resp2' => $response_text,
                ':start2' => $is_start,
            ]);
            $msg = "Flow node '{$node_name}' saved successfully!";
        }
    }

    if ($action === 'add_option') {
        $node_id = (int)($_POST['node_id'] ?? 0);
        $label = trim($_POST['option_label'] ?? '');
        $payload = trim($_POST['option_payload'] ?? '');
        $dest_id = !empty($_POST['destination_node_id']) ? (int)$_POST['destination_node_id'] : null;

        if ($node_id && $label) {
            if (empty($payload)) {
                $payload = 'PAYLOAD_' . strtoupper(preg_replace('/[^a-zA-Z0-9]/', '_', $label));
            }
            $stmt = $pdo->prepare("INSERT INTO flow_options (node_id, option_label, option_payload, destination_node_id, sort_order) VALUES (:nid, :lbl, :pl, :dest, 0)");
            $stmt->execute([':nid' => $node_id, ':lbl' => $label, ':pl' => $payload, ':dest' => $dest_id]);
            $msg = "Quick reply option '{$label}' attached!";
        }
    }

    if ($action === 'update_node') {
        $node_id = (int)($_POST['node_id'] ?? 0);
        $node_name = trim($_POST['node_name'] ?? '');
        $node_key = trim($_POST['node_key'] ?? '');
        $node_type = $_POST['node_type'] ?? 'message';
        $response_text = trim($_POST['response_text'] ?? '');
        $is_start = isset($_POST['is_start']) ? 1 : 0;

        if ($node_id > 0 && $node_name && $node_key) {
            if ($is_start) {
                $pdo->exec("UPDATE flow_nodes SET is_start = 0");
            }
            $stmt = $pdo->prepare("UPDATE flow_nodes SET node_name = :name, node_key = :k, node_type = :type, response_text = :resp, is_start = :start WHERE id = :id");
            $stmt->execute([
                ':name' => $node_name,
                ':k' => $node_key,
                ':type' => $node_type,
                ':resp' => $response_text,
                ':start' => $is_start,
                ':id' => $node_id
            ]);
            $msg = "Flow node '{$node_name}' updated successfully!";
        } else {
            $error = "Node Title and Unique Key are required.";
        }
    }

    if ($action === 'delete_node') {
        $node_id = (int)($_POST['node_id'] ?? 0);
        if ($node_id) {
            $stmt = $pdo->prepare("DELETE FROM flow_nodes WHERE id = :id");
            $stmt->execute([':id' => $node_id]);
            $msg = "Flow node deleted.";
        }
    }

    if ($action === 'delete_option') {
        $opt_id = (int)($_POST['option_id'] ?? 0);
        if ($opt_id) {
            $stmt = $pdo->prepare("DELETE FROM flow_options WHERE id = :id");
            $stmt->execute([':id' => $opt_id]);
            $msg = "Quick reply button removed.";
        }
    }
}

// Fetch all nodes and options
$nodes = $pdo->query("SELECT * FROM flow_nodes ORDER BY is_start DESC, id ASC")->fetchAll();
$options_raw = $pdo->query("SELECT * FROM flow_options ORDER BY sort_order ASC, id ASC")->fetchAll();
$options_by_node = [];
foreach ($options_raw as $opt) {
    $options_by_node[$opt['node_id']][] = $opt;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Decision Trees - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/app.css?v=1.4.2">
  <script src="../assets/js/admin.js?v=1.4.2" defer></script>
</head>
<body class="app-page">
  <?php renderAdminHeader('flow-builder'); ?>

  <main class="main-content">
    <header class="topbar">
      <div class="topbar-left">
        <span class="eyebrow">BOT LOGIC & DECISION TREES</span>
        <h1 class="page-title">Decision Tree Nodes</h1>
        <p class="page-subtitle">Construct branching customer journeys with customizable greeting menus and quick reply buttons.</p>
      </div>

      <div class="topbar-right">
        <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
          🌙 Dark Mode
        </button>
        <a href="ai-studio.php" class="btn btn-outline btn-sm" style="display: inline-flex; align-items: center; gap: 6px; border-color: rgba(168, 85, 247, 0.4); color: #c084fc;">
          ✨ AI Flow Studio
        </a>
        <a href="simulator.php" class="btn btn-primary btn-sm">
          📱 Test Simulator
        </a>
      </div>
    </header>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <!-- Tab Purpose & Usage Guide -->
    <div class="card" style="background: linear-gradient(135deg, rgba(37, 99, 235, 0.05) 0%, rgba(14, 165, 233, 0.03) 100%); border-left: 4px solid var(--primary); margin-bottom: 1.5rem; padding: 1.25rem 1.5rem;">
      <div style="display: flex; align-items: flex-start; gap: 12px;">
        <span style="font-size: 1.5rem; line-height: 1;">🌿</span>
        <div style="font-size: 0.825rem; line-height: 1.6;">
          <strong style="font-size: 0.95rem; color: var(--text); display: block; margin-bottom: 0.25rem;">
            Tab Purpose & How to Use Decision Trees
          </strong>
          <p style="margin: 0 0 0.5rem 0; color: var(--text-muted);">
            <strong>Purpose:</strong> Build interactive, automated 24/7 conversation paths for Facebook Messenger. When a customer sends a message or clicks "Get Started", your <strong>Start / Greeting Node</strong> answers immediately with self-service quick reply buttons. Customers click choices to explore FAQs, seminar dates, fees, or request human support.
          </p>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 0.75rem; margin-top: 0.75rem;">
            <div style="background: var(--bg-card); padding: 0.75rem 1rem; border-radius: var(--radius-sm); border: 1px solid var(--border);">
              <strong style="color: var(--primary);">Example 1: Main Menu Start Node</strong>
              <div style="color: var(--text-muted); font-size: 0.8rem; margin-top: 0.25rem;">
                • <strong>Key:</strong> <code>#start</code> (set checkbox as Start Node)<br>
                • <strong>Bot Response Text:</strong> "Welcome to the MCLE Messenger Assistant! How may we help you?"<br>
                • <strong>Buttons:</strong> <code>🗓️ Schedules</code>, <code>💳 Rates & Fees</code>, <code>💬 Speak to Live Staff</code>
              </div>
            </div>
            <div style="background: var(--bg-card); padding: 0.75rem 1rem; border-radius: var(--radius-sm); border: 1px solid var(--border);">
              <strong style="color: var(--primary);">Example 2: Sub-Nodes &amp; Answer Routing</strong>
              <div style="color: var(--text-muted); font-size: 0.8rem; margin-top: 0.25rem;">
                • <strong>Key:</strong> <code>schedule_info</code><br>
                • <strong>Bot Response Text:</strong> "Our next online MCLE Accredited Compliance Seminar runs Nov 20-23. Sessions are 8:00 AM - 12:00 PM."<br>
                • <strong>Buttons:</strong> <code>Register Now</code>, <code>Back to Main Menu</code>
              </div>
            </div>
            <div style="background: var(--bg-card); padding: 0.75rem 1rem; border-radius: var(--radius-sm); border: 1px solid var(--border);">
              <strong style="color: var(--primary);">Example 3: 🖼️ Product &amp; Image Carousel</strong>
              <div style="color: var(--text-muted); font-size: 0.8rem; margin-top: 0.25rem;">
                • <strong>Node Type:</strong> Set to <code>🖼️ Product &amp; Image Carousel</code><br>
                • <strong>How it works:</strong> The bot streams your <strong>Products &amp; Services</strong> catalog photos, prices, and 'Order Now' buttons directly to Meta Messenger as an interactive horizontal swipe carousel.<br>
                • <strong>Button Payload:</strong> Set button payload to <code>PAYLOAD_CATALOG</code> or link to this node.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Create Node Card -->
    <div class="card">
      <h3 style="font-size: 1.05rem; font-weight: 700; margin-bottom: 1rem;">Create New Flow Node</h3>
      <form method="POST">
        <input type="hidden" name="action" value="create_node">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; margin-bottom: 1rem;">
          <div class="form-group" style="margin: 0;">
            <label class="form-label">Node Title</label>
            <input type="text" name="node_name" class="form-control" placeholder="e.g. Schedule & Dates" required>
          </div>
          <div class="form-group" style="margin: 0;">
            <label class="form-label">Unique Node Key</label>
            <input type="text" name="node_key" class="form-control" placeholder="e.g. schedule_info" required>
          </div>
          <div class="form-group" style="margin: 0;">
            <label class="form-label">Node Type</label>
            <select name="node_type" class="form-control" id="create_node_type" onchange="checkCarouselNotice(this, 'create_carousel_note')">
              <option value="message">Standard Message</option>
              <option value="carousel">🖼️ Product &amp; Image Carousel (Shows Catalog Photos &amp; Prices)</option>
              <option value="menu">Interactive Menu</option>
              <option value="input">User Data Input / Lead Capture</option>
              <option value="end">Resolution / End</option>
            </select>
          </div>
        </div>

        <div id="create_carousel_note" style="display: none; padding: 0.75rem 1rem; border-radius: var(--radius-sm); background: rgba(37,99,235,0.06); border: 1px solid rgba(37,99,235,0.2); margin-bottom: 1rem; font-size: 0.8rem; color: var(--text);">
          ℹ️ <strong>Carousel Mode Active:</strong> When customers reach this node, Meta Messenger will send an interactive swipeable card carousel featuring the product photos, pricing, descriptions, and 1-click 'Order Now' buttons configured in your <strong>Products &amp; Services</strong> tab.
        </div>

        <div class="form-group">
          <label class="form-label">Bot Response Text (Message delivered to customer)</label>
          <textarea name="response_text" class="form-control" rows="3" placeholder="Type the automated response sent to the customer..." required></textarea>
          <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.35rem;">💡 <strong>Personalize with Name:</strong> Use <code>{first_name}</code> (e.g. <em>"Hello {first_name}!"</em>) or <code>{name}</code> for full FB name.</div>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center;">
          <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer; font-size: 0.85rem;">
            <input type="checkbox" name="is_start" value="1">
            <span>Set as Start / Greeting Node (#start)</span>
          </label>
          <button type="submit" class="btn btn-primary">+ Create Node</button>
        </div>
      </form>
    </div>

    <!-- Existing Flow Nodes List -->
    <h3 style="font-size: 1.1rem; font-weight: 700; margin-bottom: 1rem;">Current Flow Nodes (<?php echo count($nodes); ?>)</h3>

    <div style="display: grid; gap: 1.25rem;">
      <?php foreach ($nodes as $n): ?>
        <div class="card" style="margin-bottom: 0; <?php if ($n['is_start']) echo 'border-left: 5px solid #2563eb; background: rgba(37, 99, 235, 0.03); box-shadow: var(--shadow-md);'; ?>">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.75rem;">
            <div>
              <div style="display: flex; align-items: center; gap: 0.5rem;">
                <h4 style="font-size: 1.05rem; font-weight: 700; margin: 0;"><?php echo htmlspecialchars($n['node_name']); ?></h4>
                <span class="badge-pill badge-blue"><?php echo htmlspecialchars($n['node_type']); ?></span>
                <?php if ($n['node_type'] === 'carousel'): ?>
                  <span class="badge-pill badge-green" style="font-weight: 700; font-size: 0.75rem;">🖼️ PHOTO CAROUSEL</span>
                <?php endif; ?>
                <?php if ($n['is_start']): ?>
                  <span class="badge-pill badge-green" style="font-weight: 700; font-size: 0.75rem;">★ MAIN GREETING NODE</span>
                <?php endif; ?>
              </div>
              <div style="font-size: 0.75rem; color: var(--text-muted); font-family: monospace; margin-top: 0.25rem;">
                Key: #<?php echo htmlspecialchars($n['node_key']); ?> <?php if ($n['is_start']) echo '— <span style="color:#2563eb; font-weight:600;">Triggered on chat start</span>'; ?>
              </div>
            </div>

            <div style="display: flex; gap: 0.5rem; align-items: center;">
              <?php if ($n['is_start']): ?>
                <button type="button" class="btn btn-primary btn-sm" onclick="toggleEditNode(<?php echo $n['id']; ?>)">
                  ✏️ Edit Main Menu Greeting
                </button>
              <?php else: ?>
                <button type="button" class="btn btn-outline btn-sm" onclick="toggleEditNode(<?php echo $n['id']; ?>)">
                  ✏️ Edit Node
                </button>
                <form method="POST" onsubmit="return confirm('Delete this flow node and its attached buttons?');" style="margin: 0;">
                  <input type="hidden" name="action" value="delete_node">
                  <input type="hidden" name="node_id" value="<?php echo $n['id']; ?>">
                  <button type="submit" class="btn btn-outline btn-sm" style="color: var(--danger); border-color: var(--border-strong);">Delete</button>
                </form>
              <?php endif; ?>
            </div>
          </div>

          <!-- Inline Edit Form (Toggled by Edit Node button) -->
          <div id="edit-node-<?php echo $n['id']; ?>" class="edit-node-panel" style="display: none; background: var(--bg-card); border: 2px solid #2563eb; border-radius: var(--radius-sm); padding: 1.25rem; margin-bottom: 1.25rem; box-shadow: var(--shadow-md);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
              <h5 style="margin: 0; font-size: 0.95rem; font-weight: 700; color: #2563eb;">
                ✏️ Edit Flow Node: <?php echo htmlspecialchars($n['node_name']); ?>
                <?php if ($n['is_start']) echo '<span class="badge badge-green" style="font-size: 0.75rem; margin-left: 8px;">★ Main Greeting Node</span>'; ?>
              </h5>
              <button type="button" class="btn btn-sm btn-outline" onclick="toggleEditNode(<?php echo $n['id']; ?>)">✕ Close</button>
            </div>

            <form method="POST">
              <input type="hidden" name="action" value="update_node">
              <input type="hidden" name="node_id" value="<?php echo $n['id']; ?>">

              <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1rem;">
                <div class="form-group" style="margin: 0;">
                  <label class="form-label">Node Title</label>
                  <input type="text" name="node_name" class="form-control" value="<?php echo htmlspecialchars($n['node_name']); ?>" required>
                </div>

                <div class="form-group" style="margin: 0;">
                  <label class="form-label">Unique Node Key</label>
                  <input type="text" name="node_key" class="form-control" value="<?php echo htmlspecialchars($n['node_key']); ?>" required>
                </div>

                <div class="form-group" style="margin: 0;">
                  <label class="form-label">Node Type</label>
                  <select name="node_type" class="form-control" onchange="checkCarouselNotice(this, 'edit_carousel_note_<?php echo $n['id']; ?>')">
                    <option value="message" <?php echo ($n['node_type'] === 'message') ? 'selected' : ''; ?>>Standard Message</option>
                    <option value="carousel" <?php echo ($n['node_type'] === 'carousel') ? 'selected' : ''; ?>>🖼️ Product &amp; Image Carousel (Shows Catalog Photos &amp; Prices)</option>
                    <option value="menu" <?php echo ($n['node_type'] === 'menu') ? 'selected' : ''; ?>>Interactive Menu</option>
                    <option value="input" <?php echo ($n['node_type'] === 'input') ? 'selected' : ''; ?>>User Data Input / Lead Capture</option>
                    <option value="end" <?php echo ($n['node_type'] === 'end') ? 'selected' : ''; ?>>Resolution / End</option>
                  </select>
                </div>
              </div>

              <div id="edit_carousel_note_<?php echo $n['id']; ?>" style="display: <?php echo ($n['node_type'] === 'carousel') ? 'block' : 'none'; ?>; padding: 0.75rem 1rem; border-radius: var(--radius-sm); background: rgba(37,99,235,0.06); border: 1px solid rgba(37,99,235,0.2); margin-bottom: 1rem; font-size: 0.8rem; color: var(--text);">
                ℹ️ <strong>Carousel Mode Active:</strong> When customers reach this node, Meta Messenger will send an interactive card carousel featuring the product photos, pricing, descriptions, and 1-click 'Order Now' buttons configured in your <strong>Products &amp; Services</strong> tab.
              </div>

              <div class="form-group">
                <label class="form-label">
                  Bot Response Text (Customer receives this message on Messenger):
                </label>
                <textarea name="response_text" class="form-control" rows="4" required style="font-family: inherit; font-size: 0.875rem;"><?php echo htmlspecialchars($n['response_text']); ?></textarea>
                <small style="color: var(--text-muted); display: block; margin-top: 0.35rem;">
                  Customize your welcome greeting, instructions, or FAQs freely.
                </small>
              </div>

              <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 1rem; flex-wrap: wrap; gap: 0.75rem;">
                <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer; font-size: 0.85rem;">
                  <input type="checkbox" name="is_start" value="1" <?php echo $n['is_start'] ? 'checked' : ''; ?>>
                  <span style="font-weight: 600;">Set as Start / Greeting Node (#start)</span>
                </label>

                <div style="display: flex; gap: 0.5rem;">
                  <button type="button" class="btn btn-outline btn-sm" onclick="toggleEditNode(<?php echo $n['id']; ?>)">Cancel</button>
                  <button type="submit" class="btn btn-primary btn-sm">💾 Save Node Changes</button>
                </div>
              </div>
            </form>
          </div>

          <!-- Message Text Box -->
          <div style="background: var(--bg-subtle); padding: 0.85rem 1rem; border-radius: var(--radius-sm); border: 1px solid var(--border); font-size: 0.875rem; line-height: 1.6; margin-bottom: 1rem;">
            <?php echo nl2br(htmlspecialchars($n['response_text'])); ?>
          </div>

          <!-- Options / Quick Reply Buttons -->
          <div>
            <div style="font-size: 0.75rem; font-weight: 700; text-transform: uppercase; color: var(--text-muted); margin-bottom: 0.5rem;">
              Quick Reply Buttons (Customer Choices)
            </div>

            <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1rem;">
              <?php if (empty($options_by_node[$n['id']])): ?>
                <span style="font-size: 0.8rem; color: var(--text-muted); font-style: italic;">No buttons attached. Customer proceeds by typing.</span>
              <?php else: ?>
                <?php foreach ($options_by_node[$n['id']] as $opt): ?>
                  <span class="btn btn-outline btn-sm" style="display: inline-flex; align-items: center; gap: 0.5rem;">
                    <span>👉 <?php echo htmlspecialchars($opt['option_label']); ?></span>
                    <form method="POST" style="display: inline; margin: 0;">
                      <input type="hidden" name="action" value="delete_option">
                      <input type="hidden" name="option_id" value="<?php echo $opt['id']; ?>">
                      <button type="submit" style="background: none; border: none; color: var(--danger); cursor: pointer; padding: 0; font-size: 0.9rem;" title="Remove button">×</button>
                    </form>
                  </span>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>

            <!-- Add Button Form Toggle -->
            <details style="font-size: 0.8rem;">
              <summary style="cursor: pointer; color: var(--primary); font-weight: 600;">+ Add Quick Reply Button</summary>
              <form method="POST" style="margin-top: 0.75rem; display: flex; gap: 0.5rem; flex-wrap: wrap; align-items: center; background: var(--bg-card); padding: 0.75rem; border: 1px solid var(--border); border-radius: var(--radius-sm);">
                <input type="hidden" name="action" value="add_option">
                <input type="hidden" name="node_id" value="<?php echo $n['id']; ?>">
                <input type="text" name="option_label" class="form-control" placeholder="Button Label (e.g. View Rates)" style="width: 220px;" required>
                <select name="destination_node_id" class="form-control" style="width: 220px;">
                  <option value="">-- Jumps to Node --</option>
                  <?php foreach ($nodes as $dest): ?>
                    <option value="<?php echo $dest['id']; ?>"><?php echo htmlspecialchars($dest['node_name']); ?> (#<?php echo htmlspecialchars($dest['node_key']); ?>)</option>
                  <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-primary btn-sm">Attach Button</button>
              </form>
            </details>
          </div>
        </div>
      <?php endforeach; ?>
  </main>

  <script>
    function toggleEditNode(id) {
      var el = document.getElementById('edit-node-' + id);
      if (el) {
        var isHidden = el.style.display === 'none' || el.style.display === '';
        el.style.display = isHidden ? 'block' : 'none';
        if (isHidden) {
          el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    }

    function checkCarouselNotice(selectEl, noteId) {
      var el = document.getElementById(noteId);
      if (el) {
        el.style.display = (selectEl.value === 'carousel') ? 'block' : 'none';
      }
    }
  </script>
</body>
</html>
