<?php
/**
 * Facebook Graph Send API v19.0 Integration Helper
 * Sends standard text, quick replies, product carousels (generic template), image attachments, and sender actions.
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/config.php';

/**
 * Send standard text message with optional quick reply buttons
 */
function fb_send_message(string $pageAccessToken, string $recipientId, string $text, array $quickReplies = [], ?string $tag = null): array {
    if (empty($pageAccessToken) || empty($recipientId)) {
        return ['status' => 0, 'error' => 'Missing token or recipient ID'];
    }

    $url = 'https://graph.facebook.com/v19.0/me/messages?access_token=' . urlencode($pageAccessToken);

    $messageData = [
        'text' => $text,
    ];

    if (!empty($quickReplies)) {
        $messageData['quick_replies'] = array_slice($quickReplies, 0, 13);
    }

    $payload = [
        'recipient' => ['id' => $recipientId],
        'message' => $messageData,
        'messaging_type' => !empty($tag) ? 'MESSAGE_TAG' : 'RESPONSE',
    ];

    if (!empty($tag)) {
        $payload['tag'] = $tag;
    }

    return fb_post_json($url, $payload);
}

/**
 * Send interactive Generic Template Carousel (Product Cards with Images, Titles, Pricing & Buttons)
 * Meta Messenger Documentation: https://developers.facebook.com/docs/messenger-platform/reference/templates/generic
 */
function fb_send_generic_template(string $pageAccessToken, string $recipientId, array $elements, array $quickReplies = []): array {
    if (empty($pageAccessToken) || empty($recipientId) || empty($elements)) {
        return ['status' => 0, 'error' => 'Missing parameters for generic template'];
    }

    $url = 'https://graph.facebook.com/v19.0/me/messages?access_token=' . urlencode($pageAccessToken);

    // Meta limits generic template to max 10 cards per carousel
    $elements = array_slice($elements, 0, 10);

    $messageData = [
        'attachment' => [
            'type' => 'template',
            'payload' => [
                'template_type' => 'generic',
                'elements' => $elements,
            ],
        ],
    ];

    if (!empty($quickReplies)) {
        $messageData['quick_replies'] = array_slice($quickReplies, 0, 13);
    }

    $payload = [
        'recipient' => ['id' => $recipientId],
        'message' => $messageData,
        'messaging_type' => !empty($tag) ? 'MESSAGE_TAG' : 'RESPONSE',
    ];

    if (!empty($tag)) {
        $payload['tag'] = $tag;
    }

    return fb_post_json($url, $payload);
}

/**
 * Send standalone Image Attachment to customer on Messenger
 */
function fb_send_image(string $pageAccessToken, string $recipientId, string $imageUrl): array {
    if (empty($pageAccessToken) || empty($recipientId) || empty($imageUrl)) {
        return ['status' => 0, 'error' => 'Missing parameters for image attachment'];
    }

    $url = 'https://graph.facebook.com/v19.0/me/messages?access_token=' . urlencode($pageAccessToken);

    $payload = [
        'recipient' => ['id' => $recipientId],
        'message' => [
            'attachment' => [
                'type' => 'image',
                'payload' => [
                    'url' => $imageUrl,
                    'is_reusable' => true,
                ],
            ],
        ],
        'messaging_type' => !empty($tag) ? 'MESSAGE_TAG' : 'RESPONSE',
    ];

    if (!empty($tag)) {
        $payload['tag'] = $tag;
    }

    return fb_post_json($url, $payload);
}

/**
 * Helper to obtain public HTTPS image URL for a product item
 * Works seamlessly with external URLs or camera-captured base64 photos via media.php
 */
function get_product_public_image_url(array $product): string {
    if (empty($product['image_url'])) {
        return '';
    }

    $raw = trim($product['image_url']);
    $baseUrl = rtrim(defined('APP_BASE_URL') ? APP_BASE_URL : '', '/');

    // If it's a camera base64 data URL, route through media.php
    if (strpos($raw, 'data:image/') === 0) {
        return $baseUrl . '/media.php?id=' . (int)$product['id'];
    }

    // If it's an absolute URL
    if (filter_var($raw, FILTER_VALIDATE_URL)) {
        return $raw;
    }

    // Relative path
    return $baseUrl . '/' . ltrim($raw, '/');
}

function sendMessengerTextMessage(string $recipientId, string $text, ?string $pageAccessToken = null, ?string $tag = 'HUMAN_AGENT'): array {
    if ($pageAccessToken === null) {
        try {
            $pdo = db();
            $stmt = $pdo->prepare("SELECT setting_value FROM bot_settings WHERE setting_key = 'page_access_token' LIMIT 1");
            $stmt->execute();
            $pageAccessToken = $stmt->fetchColumn() ?: '';
        } catch (Throwable $e) {
            $pageAccessToken = '';
        }
    }

    return fb_send_message((string)$pageAccessToken, $recipientId, $text, [], $tag);
}


/**
 * Send a Button Template message (up to 3 web_url or postback buttons).
 * Use for sending a direct "Visit Website" button that opens the URL inside Messenger.
 * Meta template_type: "button" — compliant with Meta Messenger Platform policy.
 */
function fb_send_button_template(string $pageAccessToken, string $recipientId, string $text, array $buttons, ?string $tag = null): array {
    if (empty($pageAccessToken) || empty($recipientId) || empty($text) || empty($buttons)) {
        return ['status' => 0, 'error' => 'Missing parameters for button template'];
    }

    $url = 'https://graph.facebook.com/v19.0/me/messages?access_token=' . urlencode($pageAccessToken);

    // Meta limits button template to max 3 buttons
    $buttons = array_slice($buttons, 0, 3);

    $messageData = [
        'attachment' => [
            'type' => 'template',
            'payload' => [
                'template_type' => 'button',
                'text'          => mb_substr($text, 0, 640),
                'buttons'       => $buttons,
            ],
        ],
    ];

    $payload = [
        'recipient'      => ['id' => $recipientId],
        'message'        => $messageData,
        'messaging_type' => !empty($tag) ? 'MESSAGE_TAG' : 'RESPONSE',
    ];

    if (!empty($tag)) {
        $payload['tag'] = $tag;
    }

    return fb_post_json($url, $payload);
}
function fb_send_action(string $pageAccessToken, string $recipientId, string $action = 'typing_on'): void {
    if (empty($pageAccessToken) || empty($recipientId)) return;

    $url = 'https://graph.facebook.com/v19.0/me/messages?access_token=' . urlencode($pageAccessToken);
    $payload = [
        'recipient' => ['id' => $recipientId],
        'sender_action' => $action,
    ];

    fb_post_json($url, $payload, 5);
}

function fb_post_json(string $url, array $payload, int $timeout = 10): array {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);

    return [
        'status' => $httpCode,
        'response' => json_decode($response, true),
        'error' => $err,
    ];
}

/**
 * Retrieve user's public Facebook profile (first_name, last_name, name, profile_pic) via PSID
 * Included by default under Meta's pages_messaging permission
 */
function fb_get_user_profile(string $pageAccessToken, string $psid): array {
    if (empty($pageAccessToken) || empty($psid)) {
        return ['first_name' => '', 'last_name' => '', 'name' => ''];
    }

    $url = 'https://graph.facebook.com/v19.0/' . urlencode($psid) . '?fields=first_name,last_name,name,profile_pic&access_token=' . urlencode($pageAccessToken);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 4);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200 && !empty($response)) {
        $data = json_decode($response, true);
        if (is_array($data)) {
            $firstName = trim($data['first_name'] ?? '');
            $lastName  = trim($data['last_name'] ?? '');
            $fullName  = trim($data['name'] ?? trim("{$firstName} {$lastName}"));
            return [
                'first_name'  => $firstName,
                'last_name'   => $lastName,
                'name'        => $fullName,
                'profile_pic' => $data['profile_pic'] ?? ''
            ];
        }
    }

    return ['first_name' => '', 'last_name' => '', 'name' => ''];
}

