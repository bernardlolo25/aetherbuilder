<?php
/**
 * Product Media Delivery Handler for Facebook Messenger & Web
 * Serves device-camera captured base64 images as standard JPEG binary streams,
 * or redirects external image URLs so Meta Graph API can fetch and display them.
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/config.php';

$productId = (int)($_GET['id'] ?? 0);

if ($productId <= 0) {
    http_response_code(404);
    exit('Missing or invalid product ID.');
}

try {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT image_url, name FROM products WHERE id = ? LIMIT 1");
    $stmt->execute([$productId]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product || empty($product['image_url'])) {
        // Output default placeholder SVG
        header('Content-Type: image/svg+xml');
        echo '<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400"><rect width="600" height="400" fill="#1e293b"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#94a3b8" font-family="sans-serif" font-size="24">Product Photo</text></svg>';
        exit;
    }

    $raw = trim($product['image_url']);

    // Case 1: Base64 Data URL (e.g. from camera snapshot: data:image/jpeg;base64,...)
    if (strpos($raw, 'data:image/') === 0) {
        $parts = explode(',', $raw, 2);
        if (count($parts) === 2) {
            $meta = $parts[0]; // e.g. data:image/jpeg;base64
            $base64Data = $parts[1];

            $mime = 'image/jpeg';
            if (strpos($meta, 'image/png') !== false) {
                $mime = 'image/png';
            } elseif (strpos($meta, 'image/webp') !== false) {
                $mime = 'image/webp';
            }

            $binary = base64_decode($base64Data);

            if ($binary !== false) {
                header('Content-Type: ' . $mime);
                header('Content-Length: ' . strlen($binary));
                header('Cache-Control: public, max-age=86400');
                header('Access-Control-Allow-Origin: *');
                echo $binary;
                exit;
            }
        }
    }

    // Case 2: Standard HTTP / HTTPS URL
    if (filter_var($raw, FILTER_VALIDATE_URL)) {
        header('Location: ' . $raw, true, 302);
        exit;
    }

    // Fallback: 404
    http_response_code(404);
    exit('Image not available.');

} catch (Throwable $e) {
    http_response_code(500);
    exit('Media error: ' . htmlspecialchars($e->getMessage()));
}
