========================================================================
FACEBOOK MESSENGER 24/7 SUPPORT BOT - PRODUCTION WEB HOSTING PACKAGE
Format: Pure PHP, CSS, and Vanilla JavaScript (No Node.js / No TypeScript)
========================================================================

DATABASE CONFIGURATION PRE-SET:
- Host: sql309.infinityfree.com
- Database: if0_43065915_messenger_bot
- Username: if0_43065915
- Setup / Verify Key: AetherBuilder_Messenger_Verify_8K3mN5pQ7rT1vX9zC4wL2hF6dJ8sB0
- App Base URL: https://uspf-mcle.ct.ws/messenger

------------------------------------------------------------------------
STEP 1: UPLOAD TO WEB SERVER FILE MANAGER OR FTP
------------------------------------------------------------------------
1. Log in to your web hosting control panel (cPanel / Hostinger / etc).
2. Open the Online File Manager (or use FileZilla FTP).
3. Navigate to: /htdocs/
4. Create a folder named: messenger
5. Upload all files from this package inside /htdocs/messenger/:
   - index.php
   - webhook.php
   - send_api.php
   - setup.php
   - schema.sql
   - config/
       - config.php
       - database.php
       - .htaccess
   - includes/
       - auth.php
       - .htaccess
   - assets/
       - css/app.css
       - js/admin.js
   - admin/
       - login.php
       - logout.php
       - dashboard.php
       - flow-builder.php
       - keywords.php
       - conversations.php
       - leads.php
       - settings.php

------------------------------------------------------------------------
STEP 2: RUN INITIAL SETUP
------------------------------------------------------------------------
1. In your browser, open:
   https://uspf-mcle.ct.ws/messenger/setup.php
2. Enter the Admin Setup Key:
   AetherBuilder_Messenger_Verify_8K3mN5pQ7rT1vX9zC4wL2hF6dJ8sB0
3. Create your master administrator username & password.
4. Click "Initialize Setup & Create Admin".
5. For security, delete setup.php from your server after setup is done.

------------------------------------------------------------------------
STEP 3: CONNECT TO META FACEBOOK DEVELOPER PORTAL
------------------------------------------------------------------------
1. Go to https://developers.facebook.com/apps/
2. Select your App -> Messenger -> Webhooks.
3. Click "Add Callback URL" (or Edit):
   - Callback URL: https://uspf-mcle.ct.ws/messenger/webhook.php
   - Verify Token: AetherBuilder_Messenger_Verify_8K3mN5pQ7rT1vX9zC4wL2hF6dJ8sB0
4. Click "Verify and Save". Meta will send a GET request and verify instantly.
5. In Webhook Subscriptions, subscribe your Facebook Page to:
   - messages
   - messaging_postbacks
   - messaging_optins
6. Generate a Page Access Token for your Facebook Page and paste it into:
   https://uspf-mcle.ct.ws/messenger/admin/settings.php

------------------------------------------------------------------------
FEATURES & ARCHITECTURE:
------------------------------------------------------------------------
- 100% Deterministic (NO AI / No API fees / No hallucinations).
- Dark and Light theme presets switchable in 1 click (persisted in localStorage).
- Decision-Tree Flow Builder: Create menus, interactive quick replies, FAQs.
- Priority Keyword Matching: Exact, contains, or phrase triggers.
- Live Conversation Monitor with 1-click Human Agent Takeover toggle.
- Inquiries & CRM Leads table with instant 1-click CSV Export.
- Standalone CSS and Vanilla JS with zero external npm or Node dependencies.
========================================================================
