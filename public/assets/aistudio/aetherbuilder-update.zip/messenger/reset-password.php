<?php
/**
 * Administrator Password & Account Recovery
 * Production Single-Host Architecture (PHP, CSS, JS)
 * Protected by ADMIN_SETUP_KEY from config/config.php
 */
require_once __DIR__ . '/config/database.php';

$message = '';
$error = '';
$admins_list = [];

try {
    $pdo = db();
    // Fetch all registered admins to help user recall their username
    $admins_list = $pdo->query("SELECT id, username, email, role, is_active FROM admins ORDER BY id ASC")->fetchAll();
} catch (Throwable $e) {
    $error = 'Database connection error: ' . htmlspecialchars($e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $setup_key = $_POST['setup_key'] ?? '';
    $target_username = trim($_POST['username'] ?? '');
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (!hash_equals(ADMIN_SETUP_KEY, $setup_key)) {
        $error = 'Incorrect Setup Key. Please verify the ADMIN_SETUP_KEY in your config/config.php.';
    } elseif (empty($target_username)) {
        $error = 'Please select or enter the username to reset.';
    } elseif (strlen($new_password) < 6) {
        $error = 'New password must be at least 6 characters long.';
    } elseif ($new_password !== $confirm_password) {
        $error = 'The new passwords do not match. Please re-type carefully.';
    } else {
        try {
            $checkStmt = $pdo->prepare("SELECT id FROM admins WHERE username = :u LIMIT 1");
            $checkStmt->execute([':u' => $target_username]);
            $admin_id = $checkStmt->fetchColumn();

            if (!$admin_id) {
                $error = 'No administrator account found with username: ' . htmlspecialchars($target_username);
            } else {
                $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
                $updateStmt = $pdo->prepare("UPDATE admins SET password_hash = :hash, is_active = 1 WHERE id = :id");
                $updateStmt->execute([':hash' => $new_hash, ':id' => $admin_id]);

                $message = "Success! Password for administrator '" . htmlspecialchars($target_username) . "' has been reset. You can now log in.";
            }
        } catch (Throwable $e) {
            $error = 'Failed to update password: ' . htmlspecialchars($e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Reset Admin Password - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="assets/css/app.css?v=1.4.0">
  <script src="assets/js/admin.js?v=1.4.0" defer></script>
</head>
<body class="auth-page">
  <main class="auth-card" style="max-width: 480px;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
      <div class="brand-mark">🔑</div>
      <button class="theme-btn theme-toggle" type="button">🌓 Theme</button>
    </div>

    <h2>Superadmin Password Reset</h2>
    <p style="color: var(--text-muted); font-size: 13px; margin: 0 0 16px;">
      Recover your administrator access using your master <code>ADMIN_SETUP_KEY</code>.
    </p>

    <?php if ($error): ?>
      <div class="alert alert-danger" style="margin-bottom: 1rem;"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($message): ?>
      <div class="alert alert-success" style="margin-bottom: 1.5rem;"><?php echo $message; ?></div>
      <div style="text-align: center;">
        <a href="admin/login.php" class="btn btn-primary" style="display: block; width: 100%; text-align: center; text-decoration: none;">
          ➔ Sign In with New Password
        </a>
      </div>
    <?php else: ?>
      <?php if (!empty($admins_list)): ?>
        <div style="background: var(--bg-hover); padding: 0.75rem 1rem; border-radius: var(--radius); margin-bottom: 1.25rem; border: 1px solid var(--border); font-size: 0.8rem;">
          <strong style="color: var(--text);">Existing Accounts in Database:</strong>
          <ul style="margin: 0.25rem 0 0; padding-left: 1.2rem; color: var(--text-muted);">
            <?php foreach ($admins_list as $adm): ?>
              <li>
                <strong><?php echo htmlspecialchars($adm['username']); ?></strong> 
                (<?php echo htmlspecialchars($adm['role']); ?><?php echo $adm['email'] ? ' - ' . htmlspecialchars($adm['email']) : ''; ?>)
              </li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="POST">
        <div class="form-group">
          <label class="form-label">Master Setup Key</label>
          <input type="password" name="setup_key" class="form-control" required placeholder="Paste ADMIN_SETUP_KEY from config/config.php" autocomplete="off">
          <small style="color: var(--text-muted); font-size: 11px;">Found in <code>config/config.php</code></small>
        </div>

        <div class="form-group">
          <label class="form-label">Select or Type Username</label>
          <?php if (!empty($admins_list)): ?>
            <select name="username" class="form-control" required>
              <?php foreach ($admins_list as $adm): ?>
                <option value="<?php echo htmlspecialchars($adm['username']); ?>">
                  <?php echo htmlspecialchars($adm['username']); ?> (<?php echo htmlspecialchars($adm['role']); ?>)
                </option>
              <?php endforeach; ?>
            </select>
          <?php else: ?>
            <input type="text" name="username" class="form-control" placeholder="e.g. admin" required>
          <?php endif; ?>
        </div>

        <div class="form-group">
          <label class="form-label">New Password</label>
          <input type="password" name="new_password" class="form-control" required minlength="6" placeholder="Enter new password">
        </div>

        <div class="form-group">
          <label class="form-label">Confirm New Password</label>
          <input type="password" name="confirm_password" class="form-control" required minlength="6" placeholder="Confirm new password">
        </div>

        <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 0.75rem;">
          Reset Password Now
        </button>

        <div style="text-align: center; margin-top: 1rem;">
          <a href="admin/login.php" style="color: var(--text-muted); font-size: 0.8rem; text-decoration: none;">
            ← Return to Sign In
          </a>
        </div>
      </form>
    <?php endif; ?>
  </main>
</body>
</html>
