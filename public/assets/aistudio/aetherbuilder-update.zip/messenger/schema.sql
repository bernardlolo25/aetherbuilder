-- =========================================
-- MESSENGER BOT DATABASE PRODUCTION SCHEMA
-- Initial Database Structure v1.0
-- Host: sql309.infinityfree.com
-- Database: if0_43065915_messenger_bot
-- =========================================

SET NAMES utf8mb4;

-- 1. ADMIN ACCOUNTS
CREATE TABLE IF NOT EXISTS admins (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(190) DEFAULT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('superadmin','admin','editor')
        NOT NULL DEFAULT 'admin',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    last_login DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. FLOW VERSIONS
CREATE TABLE IF NOT EXISTS flow_versions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    version_name VARCHAR(150) NOT NULL,
    status ENUM('draft','published','archived')
        NOT NULL DEFAULT 'draft',
    created_by BIGINT UNSIGNED DEFAULT NULL,
    published_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES admins(id)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. DECISION TREE NODES
CREATE TABLE IF NOT EXISTS flow_nodes (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    version_id BIGINT UNSIGNED NOT NULL,
    node_key VARCHAR(100) NOT NULL,
    node_name VARCHAR(150) NOT NULL,
    node_type VARCHAR(50) NOT NULL DEFAULT 'message',
    response_text TEXT,
    is_start TINYINT(1) NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_node_key (version_id, node_key),
    FOREIGN KEY (version_id) REFERENCES flow_versions(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. NODE OPTIONS / QUICK REPLIES
CREATE TABLE IF NOT EXISTS flow_options (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    node_id BIGINT UNSIGNED NOT NULL,
    option_label VARCHAR(255) NOT NULL,
    option_payload VARCHAR(255) NOT NULL,
    destination_node_id BIGINT UNSIGNED DEFAULT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (node_id) REFERENCES flow_nodes(id)
        ON DELETE CASCADE,
    FOREIGN KEY (destination_node_id) REFERENCES flow_nodes(id)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. KEYWORD TRIGGERS
CREATE TABLE IF NOT EXISTS keyword_triggers (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    keyword VARCHAR(255) NOT NULL,
    match_type ENUM('exact','contains','phrase')
        NOT NULL DEFAULT 'contains',
    node_id BIGINT UNSIGNED NOT NULL,
    priority INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (node_id) REFERENCES flow_nodes(id)
        ON DELETE CASCADE,
    INDEX idx_keyword_active (is_active, priority)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. MESSENGER CONVERSATIONS
CREATE TABLE IF NOT EXISTS conversations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    page_scoped_id VARCHAR(100) NOT NULL UNIQUE,
    current_node_id BIGINT UNSIGNED DEFAULT NULL,
    flow_version_id BIGINT UNSIGNED DEFAULT NULL,
    conversation_status ENUM('active','completed','closed')
        NOT NULL DEFAULT 'active',
    human_takeover TINYINT(1) NOT NULL DEFAULT 0,
    context_data LONGTEXT DEFAULT NULL,
    last_interaction DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (current_node_id) REFERENCES flow_nodes(id)
        ON DELETE SET NULL,
    FOREIGN KEY (flow_version_id) REFERENCES flow_versions(id)
        ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. MESSAGE HISTORY
CREATE TABLE IF NOT EXISTS messages (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    conversation_id BIGINT UNSIGNED NOT NULL,
    direction ENUM('incoming','outgoing') NOT NULL,
    message_text TEXT,
    message_type VARCHAR(50) DEFAULT 'text',
    meta_message_id VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id)
        ON DELETE CASCADE,
    INDEX idx_message_history (conversation_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. LEAD & INQUIRY CAPTURE
CREATE TABLE IF NOT EXISTS leads (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    page_scoped_id VARCHAR(100) NOT NULL,
    full_name VARCHAR(190) DEFAULT NULL,
    email VARCHAR(190) DEFAULT NULL,
    phone VARCHAR(50) DEFAULT NULL,
    notes TEXT DEFAULT NULL,
    lead_status ENUM('new','contacted','qualified','closed')
        NOT NULL DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_leads_psid (page_scoped_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. BOT SETTINGS
CREATE TABLE IF NOT EXISTS bot_settings (
    setting_key VARCHAR(100) PRIMARY KEY,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. PRODUCTS & SERVICES CATALOG
CREATE TABLE IF NOT EXISTS products (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100) DEFAULT 'Services',
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    currency VARCHAR(10) NOT NULL DEFAULT 'USD',
    description TEXT,
    sku VARCHAR(100) DEFAULT NULL,
    stock_status ENUM('available','in_stock','preorder','out_of_stock') NOT NULL DEFAULT 'available',
    features TEXT,
    image_url LONGTEXT,
    action_label VARCHAR(100) DEFAULT 'Order Now',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_products_active_sort (is_active, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. CANNED RESPONSES & KNOWLEDGE BASE
CREATE TABLE IF NOT EXISTS canned_responses (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL DEFAULT 'General',
    response_text TEXT NOT NULL,
    quick_replies TEXT DEFAULT NULL,
    tags VARCHAR(255) DEFAULT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_canned_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default Approved FAQ Answers
INSERT IGNORE INTO canned_responses (id, title, category, response_text, quick_replies, tags, sort_order) VALUES
(1, '24/7 Support Commitment', 'Support Policy', 'Our automated assistant operates 24 hours a day, 7 days a week to provide immediate answers. Live representatives review all escalated inquiries Monday through Friday from 9 AM to 6 PM.', 'View Pricing, Speak to Agent, Main Menu', '24/7, availability, support, hours', 1),
(2, 'Certificate & Receipt Issuance', 'Billing & Records', 'All official certificates, receipts, and compliance confirmations are sent directly to your registered email address within 24 hours of successful processing.', 'Submit Inquiry, Main Menu', 'certificate, receipt, email, billing', 2),
(3, 'Refund & Cancellation Policy', 'Policies', 'Cancellations requested at least 48 hours prior to scheduled live events are eligible for a 100% full refund or credit transfer to future sessions.', 'Contact Support, Main Menu', 'refund, cancel, policy, credit', 3),
(4, 'MCLE Accreditation & State Bar Verification', 'Compliance', 'All compliance seminars and online modules are fully accredited and verified for mandatory legal education credit units with automated bar attendance reporting.', 'View Packages, Enroll Now, Main Menu', 'mcle, accredited, units, legal education', 4);

