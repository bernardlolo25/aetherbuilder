<?php
/**
 * Product & Service Catalog Management
 * Includes: Camera Snapshot, File Upload, AI Flow Studio Connection,
 * Live Search & Category Filter Toolbar, Variations & Layers Repeater,
 * Fulfillment Modes (Booking vs Stock), and Batch Price Adjustment Tool.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';

$pdo = db();
$msg = '';
$error = '';

// Self-healing database migrations: add missing columns & create tables
try {
    try { $pdo->exec("ALTER TABLE products ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1"); } catch (\Throwable $e) {}
    try { $pdo->exec("ALTER TABLE products ADD COLUMN sort_order INT NOT NULL DEFAULT 0"); } catch (\Throwable $e) {}
    try { $pdo->exec("ALTER TABLE products ADD COLUMN variations LONGTEXT NULL"); } catch (\Throwable $e) {}
    try { $pdo->exec("ALTER TABLE products ADD COLUMN fulfillment_mode VARCHAR(30) NOT NULL DEFAULT 'booking'"); } catch (\Throwable $e) {}
    try { $pdo->exec("ALTER TABLE products ADD COLUMN stock_quantity INT NOT NULL DEFAULT 0"); } catch (\Throwable $e) {}

    // Ensure bookings table exists for culinary & store orders
    $pdo->exec("CREATE TABLE IF NOT EXISTS bookings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        booking_ref VARCHAR(50) UNIQUE NOT NULL,
        customer_name VARCHAR(150) NOT NULL,
        customer_phone VARCHAR(50) NOT NULL,
        customer_email VARCHAR(150) NULL,
        delivery_type VARCHAR(50) DEFAULT 'pickup',
        delivery_address TEXT NULL,
        event_date DATE NULL,
        event_time VARCHAR(30) NULL,
        dedication_text TEXT NULL,
        items_json LONGTEXT NOT NULL,
        total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        currency VARCHAR(10) DEFAULT 'PHP',
        status VARCHAR(30) DEFAULT 'pending',
        notes TEXT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_status (status),
        INDEX idx_event_date (event_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Fix: Only seed sample products on INITIAL setup, NEVER on refresh after user deletes products
    $hasSeeded = false;
    try {
        $stmtS = $pdo->prepare("SELECT setting_value FROM bot_settings WHERE setting_key = 'products_seeded' LIMIT 1");
        $stmtS->execute();
        $hasSeeded = ($stmtS->fetchColumn() === '1');
    } catch (\Throwable $e) {}

    if (!$hasSeeded) {
        $count = (int)$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
        if ($count === 0) {
            $sampleStmt = $pdo->prepare("INSERT INTO products (name, category, price, currency, description, sku, stock_status, fulfillment_mode, stock_quantity, variations, image_url, action_label) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            // Sample Cake with Variations
            $cakeVars = json_encode([
                ['name' => '1 Layer (6-inch)', 'price' => 35.00, 'description' => 'Serves 4-6 pax, single moist layer'],
                ['name' => '2 Layers (8-inch)', 'price' => 60.00, 'description' => 'Serves 8-12 pax, double chocolate ganache'],
                ['name' => '3 Layers (10-inch)', 'price' => 95.00, 'description' => 'Serves 16-20 pax, triple celebration tier']
            ]);
            $sampleStmt->execute([
                'Classic Strawberry Velvet Cake',
                'Cakes',
                35.00,
                'USD',
                'Freshly baked artisanal strawberry cake with pure cream cheese frosting.',
                'CAKE-STR-01',
                'available',
                'booking',
                0,
                $cakeVars,
                'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=600&q=80',
                'Book Cake'
            ]);

            // Sample Retail Utensils with Stock
            $sampleStmt->execute([
                'Stainless Steel Cake Decorating Spatula Set (3-Piece)',
                'Utensils',
                18.50,
                'USD',
                'Professional angled offset icing spatulas with ergonomic heat-resistant handles.',
                'UTN-SPAT-03',
                'available',
                'stock',
                24,
                null,
                'https://images.unsplash.com/photo-1590794056226-79ef3a8147e1?auto=format&fit=crop&w=600&q=80',
                'Order Tools'
            ]);
        }

        try {
            $pdo->exec("INSERT INTO bot_settings (setting_key, setting_value) VALUES ('products_seeded', '1') ON DUPLICATE KEY UPDATE setting_value = '1'");
        } catch (\Throwable $e) {}
    }
} catch (Throwable $e) {
    $error = "Database notice: " . $e->getMessage();
}

// Handle Form Submissions with Post-Redirect-Get to prevent duplicate resubmissions & re-seeding
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create_product') {
        $name = trim($_POST['name'] ?? '');
        $category = trim($_POST['category'] ?? 'General');
        $price = (float)($_POST['price'] ?? 0);
        $currency = trim($_POST['currency'] ?? 'PHP');
        $description = trim($_POST['description'] ?? '');
        $sku = trim($_POST['sku'] ?? '');
        $stock_status = $_POST['stock_status'] ?? 'available';
        $fulfillment_mode = $_POST['fulfillment_mode'] ?? 'booking';
        $stock_quantity = (int)($_POST['stock_quantity'] ?? 0);
        $variations = trim($_POST['variations'] ?? '');
        $features = trim($_POST['features'] ?? '');
        $image_url = trim($_POST['image_url'] ?? '');
        $action_label = trim($_POST['action_label'] ?? 'Order Now');

        if ($name !== '') {
            try {
                $stmt = $pdo->prepare("INSERT INTO products (name, category, price, currency, description, sku, stock_status, fulfillment_mode, stock_quantity, variations, features, image_url, action_label) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $category, $price, $currency, $description, $sku, $stock_status, $fulfillment_mode, $stock_quantity, $variations ?: null, $features, $image_url, $action_label]);
                header("Location: products.php?created=1");
                exit;
            } catch (Throwable $e) {
                $error = "Failed to add product: " . $e->getMessage();
            }
        } else {
            $error = "Product / Service Name is required.";
        }
    } elseif ($action === 'update_product') {
        $id = (int)($_POST['product_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $category = trim($_POST['category'] ?? 'General');
        $price = (float)($_POST['price'] ?? 0);
        $currency = trim($_POST['currency'] ?? 'PHP');
        $description = trim($_POST['description'] ?? '');
        $sku = trim($_POST['sku'] ?? '');
        $stock_status = $_POST['stock_status'] ?? 'available';
        $fulfillment_mode = $_POST['fulfillment_mode'] ?? 'booking';
        $stock_quantity = (int)($_POST['stock_quantity'] ?? 0);
        $variations = trim($_POST['variations'] ?? '');
        $features = trim($_POST['features'] ?? '');
        $image_url = trim($_POST['image_url'] ?? '');
        $action_label = trim($_POST['action_label'] ?? 'Order Now');

        if ($id > 0 && $name !== '') {
            try {
                $stmt = $pdo->prepare("UPDATE products SET name = ?, category = ?, price = ?, currency = ?, description = ?, sku = ?, stock_status = ?, fulfillment_mode = ?, stock_quantity = ?, variations = ?, features = ?, image_url = ?, action_label = ? WHERE id = ?");
                $stmt->execute([$name, $category, $price, $currency, $description, $sku, $stock_status, $fulfillment_mode, $stock_quantity, $variations ?: null, $features, $image_url, $action_label, $id]);
                header("Location: products.php?updated=1");
                exit;
            } catch (Throwable $e) {
                $error = "Failed to update product: " . $e->getMessage();
            }
        }
    } elseif ($action === 'delete_product') {
        $id = (int)($_POST['product_id'] ?? 0);
        if ($id > 0) {
            try {
                $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
                $stmt->execute([$id]);
                header("Location: products.php?deleted=1");
                exit;
            } catch (Throwable $e) {
                $error = "Failed to delete product: " . $e->getMessage();
            }
        }
    } elseif ($action === 'batch_price_adjust') {
        // Price Management Tool (e.g. ingredient price increase across category)
        $targetCategory = trim($_POST['batch_category'] ?? 'all');
        $adjustType = $_POST['adjust_type'] ?? 'percent'; // percent or fixed
        $direction = $_POST['adjust_direction'] ?? 'increase'; // increase or decrease
        $value = (float)($_POST['adjust_value'] ?? 0);

        if ($value > 0) {
            try {
                $query = "SELECT id, price, variations FROM products";
                $params = [];
                if ($targetCategory !== 'all') {
                    $query .= " WHERE category = ?";
                    $params[] = $targetCategory;
                }
                $stmt = $pdo->prepare($query);
                $stmt->execute($params);
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

                $updStmt = $pdo->prepare("UPDATE products SET price = ?, variations = ? WHERE id = ?");
                foreach ($rows as $r) {
                    $oldPrice = (float)$r['price'];
                    $delta = ($adjustType === 'percent') ? ($oldPrice * ($value / 100)) : $value;
                    $newPrice = ($direction === 'increase') ? ($oldPrice + $delta) : max(0.01, $oldPrice - $delta);

                    // Also adjust variation prices if present
                    $newVars = null;
                    if (!empty($r['variations'])) {
                        $varsList = @json_decode($r['variations'], true);
                        if (is_array($varsList)) {
                            foreach ($varsList as &$vItem) {
                                $vOld = (float)($vItem['price'] ?? 0);
                                $vDelta = ($adjustType === 'percent') ? ($vOld * ($value / 100)) : $value;
                                $vItem['price'] = round(($direction === 'increase') ? ($vOld + $vDelta) : max(0.01, $vOld - $vDelta), 2);
                            }
                            $newVars = json_encode($varsList, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                        }
                    }

                    $updStmt->execute([round($newPrice, 2), $newVars ?: $r['variations'], $r['id']]);
                }
                header("Location: products.php?adjusted=1&count=" . count($rows));
                exit;
            } catch (Throwable $e) {
                $error = "Batch adjustment failed: " . $e->getMessage();
            }
        }
    } elseif ($action === 'seed_samples') {
        try {
            $pdo->exec("DELETE FROM products");
            header("Location: products.php?seeded=1");
            exit;
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
}

// Flash messages from Post-Redirect-Get
if (isset($_GET['created'])) $msg = "Product / Service added to catalog successfully!";
if (isset($_GET['updated'])) $msg = "Product details and pricing updated successfully!";
if (isset($_GET['deleted'])) $msg = "Product permanently deleted from catalog.";
if (isset($_GET['adjusted'])) $msg = "Batch price adjustment applied to " . (int)($_GET['count'] ?? 0) . " product(s) successfully!";

// Fetch all products
$products = [];
$categories = [];
try {
    $stmt = $pdo->query("SELECT * FROM products ORDER BY sort_order ASC, id DESC");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($products as $p) {
        $c = trim($p['category'] ?? '');
        if ($c !== '' && !in_array($c, $categories, true)) {
            $categories[] = $c;
        }
    }
    sort($categories);
} catch (Throwable $e) {
    $error = "Could not fetch products: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Products & Services Management - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/admin.css">
  <style>
    .catalog-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(290px, 1fr));
      gap: 1.25rem;
    }
    .product-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      overflow: hidden;
      display: flex;
      flex-direction: column;
      transition: all 0.2s ease;
      position: relative;
    }
    .product-card:hover {
      border-color: #6366f1;
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(0,0,0,0.12);
    }
    .product-thumb-wrap {
      width: 100%;
      aspect-ratio: 16/10;
      background: var(--bg-subtle);
      position: relative;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .product-thumb-wrap img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .badge-category {
      position: absolute;
      top: 10px;
      left: 10px;
      background: rgba(15, 23, 42, 0.75);
      backdrop-filter: blur(4px);
      color: #fff;
      font-size: 0.7rem;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 99px;
      border: 1px solid rgba(255,255,255,0.15);
    }
    .price-pill {
      position: absolute;
      bottom: 10px;
      right: 10px;
      background: #10b981;
      color: #fff;
      font-size: 0.825rem;
      font-weight: 800;
      padding: 4px 10px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.25);
    }
    .card-body {
      padding: 1rem;
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      gap: 0.75rem;
    }
    .card-title {
      font-size: 0.95rem;
      font-weight: 700;
      margin: 0 0 0.35rem;
      color: var(--text-main);
    }
    .card-desc {
      font-size: 0.8rem;
      color: var(--text-muted);
      line-height: 1.4;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      margin: 0;
    }
    .card-meta {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding-top: 0.5rem;
      border-top: 1px solid var(--border-color);
      font-size: 0.75rem;
    }
    .var-badge {
      display: inline-block;
      background: rgba(236, 72, 153, 0.12);
      color: #ec4899;
      border: 1px solid rgba(236, 72, 153, 0.25);
      border-radius: 6px;
      padding: 2px 6px;
      font-size: 0.72rem;
      font-weight: 600;
      margin-top: 4px;
    }
    .stock-badge {
      display: inline-block;
      background: rgba(59, 130, 246, 0.12);
      color: #3b82f6;
      border: 1px solid rgba(59, 130, 246, 0.25);
      border-radius: 6px;
      padding: 2px 6px;
      font-size: 0.72rem;
      font-weight: 600;
      margin-top: 4px;
    }
    .toolbar-bar {
      display: flex;
      flex-wrap: wrap;
      gap: 0.75rem;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 1.25rem;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      padding: 0.85rem 1.15rem;
      border-radius: var(--radius-sm);
    }
    .camera-modal {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.85);
      z-index: 10000;
      align-items: center;
      justify-content: center;
      padding: 1rem;
    }
    .camera-modal.active {
      display: flex;
    }
    .camera-box {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      width: 100%;
      max-width: 580px;
      overflow: hidden;
      box-shadow: 0 20px 40px rgba(0,0,0,0.5);
    }
    .camera-viewport {
      position: relative;
      background: #000;
      width: 100%;
      aspect-ratio: 4/3;
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
    }
    .camera-viewport video {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .var-row {
      display: grid;
      grid-template-columns: 2fr 1fr 2fr auto;
      gap: 6px;
      align-items: center;
      margin-bottom: 6px;
    }
  </style>
</head>
<body class="app-page">
  <?php renderAdminHeader('products'); ?>

  <main class="main-content">
    <header class="topbar">
      <div class="topbar-left">
        <span class="eyebrow">CATALOG & OFFERINGS</span>
        <h1 class="page-title">Products & Services Management</h1>
        <p class="page-subtitle">Manage cakes, made-to-order layers, retail utensils, stock counts, batch price adjustments, and device camera photos.</p>
      </div>

      <div class="topbar-right">
        <button type="button" class="btn btn-outline btn-sm" onclick="openBatchPriceModal()" style="border-color: #f59e0b; color: #f59e0b;" title="Adjust prices across categories for ingredient cost inflation">
          ⚡ Batch Price Adjust
        </button>
        <a href="bookings.php" class="btn btn-outline btn-sm" style="border-color: #10b981; color: #10b981;" title="View client bookings & orders">
          📅 View Bookings
        </a>
        <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
          🌙 Dark Mode
        </button>
        <button type="button" class="btn btn-primary btn-sm" onclick="openAddProductModal()">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
          Add Product / Cake
        </button>
      </div>
    </header>

    <?php if ($msg): ?>
      <div class="alert alert-success" style="padding: 0.85rem 1.25rem; border-radius: var(--radius-sm); margin-bottom: 1.25rem; background: rgba(16, 185, 129, 0.12); border-left: 4px solid #10b981; color: #10b981; font-size: 0.875rem;">
        <?php echo htmlspecialchars($msg); ?>
      </div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div class="alert alert-danger" style="padding: 0.85rem 1.25rem; border-radius: var(--radius-sm); margin-bottom: 1.25rem; background: rgba(239, 68, 68, 0.12); border-left: 4px solid #ef4444; color: #ef4444; font-size: 0.875rem;">
        <?php echo htmlspecialchars($error); ?>
      </div>
    <?php endif; ?>

    <!-- Live Search & Filter Toolbar -->
    <div class="toolbar-bar">
      <div style="display: flex; gap: 0.6rem; align-items: center; flex: 1; min-width: 260px; flex-wrap: wrap;">
        <input type="text" id="catalogSearchInput" oninput="filterCatalog()" placeholder="🔍 Search product by name, SKU, or description..." style="flex: 2; min-width: 220px; padding: 0.45rem 0.75rem; font-size: 0.8rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);">
        
        <select id="catalogCategoryFilter" onchange="filterCatalog()" style="flex: 1; min-width: 140px; padding: 0.45rem 0.75rem; font-size: 0.8rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);">
          <option value="all">All Categories (<?php echo count($products); ?>)</option>
          <?php foreach ($categories as $cat): ?>
            <option value="<?php echo htmlspecialchars($cat); ?>"><?php echo htmlspecialchars($cat); ?></option>
          <?php endforeach; ?>
        </select>

        <select id="catalogModeFilter" onchange="filterCatalog()" style="flex: 1; min-width: 140px; padding: 0.45rem 0.75rem; font-size: 0.8rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);">
          <option value="all">All Fulfillment Types</option>
          <option value="booking">🎂 Made-to-Order / Booking</option>
          <option value="stock">🍴 Retail Stock (Utensils)</option>
        </select>
      </div>

      <div style="display: flex; gap: 0.75rem; align-items: center;">
        <span id="catalogCountBadge" style="font-size: 0.8rem; color: var(--text-muted);">
          Showing <?php echo count($products); ?> products
        </span>
      </div>
    </div>

    <!-- Products Grid -->
    <?php if (empty($products)): ?>
      <div class="card" style="text-align: center; padding: 3rem 1rem;">
        <div style="font-size: 2.5rem; margin-bottom: 0.75rem;">📦</div>
        <h3 style="margin: 0 0 0.5rem; font-size: 1.1rem; font-weight: 700;">No Products in Catalog</h3>
        <p style="margin: 0 0 1.25rem; font-size: 0.85rem; color: var(--text-muted); max-width: 460px; margin-left: auto; margin-right: auto;">
          Your catalog is currently clean. Add your cakes, pastry sets, or kitchen utensils below:
        </p>
        <button type="button" class="btn btn-primary" onclick="openAddProductModal()">
          + Add Your First Product
        </button>
      </div>
    <?php else: ?>
      <div class="catalog-grid" id="catalogGrid">
        <?php foreach ($products as $p): 
          $vars = @json_decode($p['variations'] ?? '', true);
          $hasVars = is_array($vars) && !empty($vars);
          $currSymbol = $p['currency'] === 'USD' ? '$' : ($p['currency'] === 'PHP' ? '₱' : ($p['currency'] === 'EUR' ? '€' : $p['currency'] . ' '));
          $priceDisplay = $currSymbol . number_format((float)$p['price'], 2);
          if ($hasVars) {
            $priceDisplay = "From " . $priceDisplay;
          }
        ?>
          <div class="product-card"
               data-name="<?php echo htmlspecialchars($p['name']); ?>"
               data-category="<?php echo htmlspecialchars($p['category']); ?>"
               data-sku="<?php echo htmlspecialchars($p['sku'] ?? ''); ?>"
               data-desc="<?php echo htmlspecialchars($p['description'] ?? ''); ?>"
               data-mode="<?php echo htmlspecialchars($p['fulfillment_mode'] ?? 'booking'); ?>">

            <div class="product-thumb-wrap">
              <?php if (!empty($p['image_url'])): ?>
                <img src="<?php echo htmlspecialchars($p['image_url']); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>" loading="lazy">
              <?php else: ?>
                <div style="color: var(--text-muted); font-size: 0.75rem; text-align: center;">
                  <span style="font-size: 1.5rem; display: block; margin-bottom: 2px;">🍰</span>
                  No Photo Attached
                </div>
              <?php endif; ?>
              <span class="badge-category"><?php echo htmlspecialchars($p['category']); ?></span>
              <span class="price-pill"><?php echo $priceDisplay; ?></span>
            </div>

            <div class="card-body">
              <div>
                <h4 class="card-title"><?php echo htmlspecialchars($p['name']); ?></h4>
                <p class="card-desc"><?php echo htmlspecialchars($p['description'] ?: 'Artisanal item.'); ?></p>
                
                <div style="display: flex; gap: 5px; flex-wrap: wrap; margin-top: 6px;">
                  <?php if ($hasVars): ?>
                    <span class="var-badge">🎂 <?php echo count($vars); ?> Layer Variations</span>
                  <?php endif; ?>
                  
                  <?php if (($p['fulfillment_mode'] ?? 'booking') === 'stock'): ?>
                    <?php if ((int)($p['stock_quantity'] ?? 0) > 0): ?>
                      <span class="stock-badge">📦 Stock: <?php echo (int)$p['stock_quantity']; ?> left</span>
                    <?php else: ?>
                      <span class="stock-badge" style="background:rgba(239,68,68,0.12);color:#ef4444;border-color:rgba(239,68,68,0.25);">Out of Stock</span>
                    <?php endif; ?>
                  <?php else: ?>
                    <span style="font-size:0.7rem;color:var(--text-muted);padding:2px 6px;border-radius:4px;background:var(--bg-subtle);">📅 Made to Order</span>
                  <?php endif; ?>
                </div>
              </div>

              <div>
                <div class="card-meta">
                  <span style="color: var(--text-muted); font-family: monospace;">SKU: <?php echo htmlspecialchars($p['sku'] ?: 'N/A'); ?></span>
                  <div style="display: flex; gap: 6px;">
                    <button type="button" class="btn btn-outline btn-sm" style="padding: 3px 8px; font-size: 0.75rem;" onclick='editProduct(<?php echo json_encode($p, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>)'>
                      Edit
                    </button>
                    <form method="POST" style="margin: 0;" onsubmit="return confirm('Permanently delete this product from catalog?');">
                      <input type="hidden" name="action" value="delete_product">
                      <input type="hidden" name="product_id" value="<?php echo (int)$p['id']; ?>">
                      <button type="submit" class="btn btn-danger btn-sm" style="padding: 3px 8px; font-size: 0.75rem;">
                        Delete
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <!-- Add / Edit Modal -->
    <div id="productModal" class="camera-modal">
      <div class="camera-box" style="max-width: 620px; max-height: 92vh; overflow-y: auto;">
        <div style="padding: 1rem 1.25rem; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; justify-content: space-between;">
          <h3 id="modalTitle" style="margin: 0; font-size: 0.95rem; font-weight: 700;">Add Product / Cake</h3>
          <button type="button" onclick="closeProductModal()" style="background: none; border: none; font-size: 1.25rem; cursor: pointer; color: var(--text-muted);">&times;</button>
        </div>

        <form method="POST" id="productForm" onsubmit="return prepareProductSubmit()" style="padding: 1.25rem;">
          <input type="hidden" name="action" id="formAction" value="create_product">
          <input type="hidden" name="product_id" id="formProductId" value="">
          <input type="hidden" name="variations" id="fieldVariationsJson" value="">

          <div style="margin-bottom: 0.85rem;">
            <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Product / Cake Name *</label>
            <input type="text" name="name" id="fieldName" required class="form-control" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);" placeholder="e.g. Classic Red Velvet Cake, Silicone Spatula">
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; margin-bottom: 0.85rem;">
            <div>
              <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Category</label>
              <input type="text" name="category" id="fieldCategory" class="form-control" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);" placeholder="e.g. Cakes, Utensils">
            </div>
            <div>
              <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">SKU / Product Code</label>
              <input type="text" name="sku" id="fieldSku" class="form-control" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);" placeholder="e.g. CK-001">
            </div>
          </div>

          <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 0.75rem; margin-bottom: 0.85rem;">
            <div>
              <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Base Price *</label>
              <input type="number" step="any" min="0" name="price" id="fieldPrice" required class="form-control" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);" value="45.00">
            </div>
            <div>
              <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Currency</label>
              <select name="currency" id="fieldCurrency" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);">
                <option value="PHP">PHP (₱)</option>
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
                <option value="CAD">CAD ($)</option>
                <option value="AUD">AUD ($)</option>
              </select>
            </div>
          </div>

          <!-- Fulfillment Mode & Inventory Stock Count -->
          <div style="background: var(--bg-subtle); border: 1px solid var(--border-color); border-radius: var(--radius-sm); padding: 0.75rem; margin-bottom: 0.85rem;">
            <label style="display: block; font-size: 0.75rem; font-weight: 700; margin-bottom: 0.4rem; color: var(--text-main);">Fulfillment & Stock Mode</label>
            <div style="display: flex; gap: 1rem; align-items: center; margin-bottom: 0.5rem;">
              <label style="font-size: 0.8rem; cursor: pointer; display: flex; align-items: center; gap: 4px;">
                <input type="radio" name="fulfillment_mode" value="booking" id="modeBooking" checked onchange="toggleFulfillmentFields()">
                <span>🎂 Made-to-Order / Booking (Cakes)</span>
              </label>
              <label style="font-size: 0.8rem; cursor: pointer; display: flex; align-items: center; gap: 4px;">
                <input type="radio" name="fulfillment_mode" value="stock" id="modeStock" onchange="toggleFulfillmentFields()">
                <span>🍴 Retail Physical Stock (Utensils)</span>
              </label>
            </div>

            <div id="stockQuantityWrap" style="display: none; margin-top: 0.5rem;">
              <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.25rem;">Inventory Units in Stock:</label>
              <input type="number" min="0" name="stock_quantity" id="fieldStockQuantity" value="0" style="width: 120px; padding: 0.4rem 0.6rem; font-size: 0.8rem; border-radius: 4px; border: 1px solid var(--border-color); background: var(--bg-card); color: var(--text-main);">
            </div>
          </div>

          <!-- Variations & Layers Section -->
          <div style="background: var(--bg-subtle); border: 1px solid var(--border-color); border-radius: var(--radius-sm); padding: 0.75rem; margin-bottom: 0.85rem;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.4rem;">
              <label style="font-size: 0.75rem; font-weight: 700; color: var(--text-main); cursor: pointer; display: flex; align-items: center; gap: 6px;">
                <input type="checkbox" id="chkEnableVariations" onchange="toggleVariationsSection()">
                <span>🍰 Enable Variations & Layers (Different sizes/tiers with own price & description)</span>
              </label>
              <button type="button" class="btn btn-outline btn-sm" id="btnAddVarRow" onclick="addVariationRow()" style="display: none; padding: 2px 8px; font-size: 0.72rem;">
                + Add Layer / Size
              </button>
            </div>

            <div id="variationsWrapper" style="display: none; margin-top: 0.65rem;">
              <div style="font-size: 0.7rem; color: var(--text-muted); margin-bottom: 6px; display: grid; grid-template-columns: 2fr 1fr 2fr auto; gap: 6px;">
                <span>Layer / Size Name</span>
                <span>Price</span>
                <span>Servings / Description</span>
                <span></span>
              </div>
              <div id="variationsRowsContainer"></div>
            </div>
          </div>

          <div style="margin-bottom: 0.85rem;">
            <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Description</label>
            <textarea name="description" id="fieldDescription" rows="2" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);" placeholder="Ingredients, flavor profile, or instructions..."></textarea>
          </div>

          <!-- Photo & Camera Capture Section -->
          <div style="margin-bottom: 0.85rem;">
            <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Product Photo (Camera or Upload)</label>
            <div style="display: flex; gap: 0.75rem; align-items: center; margin-bottom: 0.5rem;">
              <button type="button" class="btn btn-outline btn-sm" onclick="openCameraModal()" style="border-color: #2563eb; color: #2563eb;">
                📸 Snap with Camera
              </button>
              <label class="btn btn-outline btn-sm" style="margin: 0; cursor: pointer;">
                📁 Choose Image File
                <input type="file" accept="image/*" style="display: none;" onchange="handleImageFileSelect(event)">
              </label>
            </div>
            <input type="text" name="image_url" id="fieldImageUrl" class="form-control" style="width: 100%; padding: 0.4rem 0.65rem; font-size: 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);" placeholder="Or paste image URL...">
            <div id="imagePreviewContainer" style="margin-top: 0.5rem; display: none;">
              <img id="imagePreview" src="" style="width: 90px; height: 70px; object-fit: cover; border-radius: 6px; border: 1px solid var(--border-color);">
            </div>
          </div>

          <div style="margin-bottom: 1.25rem;">
            <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Button Action Label</label>
            <input type="text" name="action_label" id="fieldActionLabel" value="Add to Cart" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);" placeholder="e.g. Add to Cart, Book Cake, Order">
          </div>

          <div style="display: flex; justify-content: flex-end; gap: 0.5rem;">
            <button type="button" class="btn btn-outline" onclick="closeProductModal()">Cancel</button>
            <button type="submit" class="btn btn-primary" id="modalSubmitBtn">Save Product</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Batch Price Adjustment Modal -->
    <div id="batchPriceModal" class="camera-modal">
      <div class="camera-box" style="max-width: 480px;">
        <div style="padding: 1rem 1.25rem; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; justify-content: space-between;">
          <h3 style="margin: 0; font-size: 0.95rem; font-weight: 700;">⚡ Batch Price Adjustment</h3>
          <button type="button" onclick="closeBatchPriceModal()" style="background: none; border: none; font-size: 1.25rem; cursor: pointer; color: var(--text-muted);">&times;</button>
        </div>

        <form method="POST" style="padding: 1.25rem;">
          <input type="hidden" name="action" value="batch_price_adjust">

          <p style="font-size: 0.8rem; color: var(--text-muted); margin: 0 0 1rem; line-height: 1.4;">
            Easily update catalog prices when ingredient costs (flour, eggs, chocolate) increase or when launching a seasonal sale. Adjusts base prices and all layer variations.
          </p>

          <div style="margin-bottom: 0.85rem;">
            <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Target Category:</label>
            <select name="batch_category" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);">
              <option value="all">Entire Catalog (All Categories)</option>
              <?php foreach ($categories as $cat): ?>
                <option value="<?php echo htmlspecialchars($cat); ?>"><?php echo htmlspecialchars($cat); ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; margin-bottom: 0.85rem;">
            <div>
              <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Action:</label>
              <select name="adjust_direction" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);">
                <option value="increase">📈 Increase (+)</option>
                <option value="decrease">📉 Decrease (-)</option>
              </select>
            </div>
            <div>
              <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Adjustment Type:</label>
              <select name="adjust_type" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);">
                <option value="percent">Percentage (%)</option>
                <option value="fixed">Fixed Currency Amount (₱ / $)</option>
              </select>
            </div>
          </div>

          <div style="margin-bottom: 1.25rem;">
            <label style="display: block; font-size: 0.75rem; font-weight: 600; margin-bottom: 0.35rem;">Adjustment Value (e.g. 10 for 10%, or 50 for ₱50):</label>
            <input type="number" step="any" min="0.01" name="adjust_value" required value="10" style="width: 100%; padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);">
          </div>

          <div style="display: flex; justify-content: flex-end; gap: 0.5rem;">
            <button type="button" class="btn btn-outline" onclick="closeBatchPriceModal()">Cancel</button>
            <button type="submit" class="btn btn-primary" onclick="return confirm('Apply this price adjustment across the selected products?');">Apply Adjustment</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Live Camera Capture Modal -->
    <div id="liveCameraModal" class="camera-modal">
      <div class="camera-box">
        <div style="padding: 0.75rem 1rem; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; justify-content: space-between;">
          <h4 style="margin: 0; font-size: 0.875rem; font-weight: 700;">📸 Camera Viewfinder</h4>
          <button type="button" onclick="closeCameraModal()" style="background: none; border: none; font-size: 1.25rem; color: #fff; cursor: pointer;">&times;</button>
        </div>
        <div class="camera-viewport">
          <video id="cameraVideo" autoplay playsinline muted></video>
          <canvas id="cameraCanvas" style="display: none;"></canvas>
        </div>
        <div style="padding: 0.75rem 1rem; display: flex; align-items: center; justify-content: space-between; background: var(--bg-subtle);">
          <button type="button" class="btn btn-outline btn-sm" onclick="switchCamera()">🔄 Switch Lens</button>
          <button type="button" class="btn btn-primary btn-sm" onclick="takeSnapshot()">📸 Take Snapshot</button>
        </div>
      </div>
    </div>
  </main>

  <script>
    let cameraStream = null;
    let currentFacingMode = 'environment';

    // ── Live Instant Search & Filter ─────────────────────────
    function filterCatalog() {
      const q = (document.getElementById('catalogSearchInput').value || '').toLowerCase().trim();
      const cat = document.getElementById('catalogCategoryFilter').value;
      const mode = document.getElementById('catalogModeFilter').value;
      const cards = document.querySelectorAll('#catalogGrid .product-card');
      let visible = 0;

      cards.forEach(card => {
        const name = (card.dataset.name || '').toLowerCase();
        const category = (card.dataset.category || '').toLowerCase();
        const sku = (card.dataset.sku || '').toLowerCase();
        const desc = (card.dataset.desc || '').toLowerCase();
        const cardMode = card.dataset.mode || 'booking';

        const matchesSearch = !q || name.includes(q) || category.includes(q) || sku.includes(q) || desc.includes(q);
        const matchesCat = (cat === 'all' || category === cat.toLowerCase());
        const matchesMode = (mode === 'all' || cardMode === mode);

        if (matchesSearch && matchesCat && matchesMode) {
          card.style.display = '';
          visible++;
        } else {
          card.style.display = 'none';
        }
      });

      const badge = document.getElementById('catalogCountBadge');
      if (badge) badge.textContent = `Showing ${visible} of ${cards.length} products`;
    }

    // ── Fulfillment Mode Toggler ─────────────────────────────
    function toggleFulfillmentFields() {
      const isStock = document.getElementById('modeStock').checked;
      document.getElementById('stockQuantityWrap').style.display = isStock ? 'block' : 'none';
    }

    // ── Variations / Layers UI Logic ─────────────────────────
    function toggleVariationsSection() {
      const enabled = document.getElementById('chkEnableVariations').checked;
      document.getElementById('variationsWrapper').style.display = enabled ? 'block' : 'none';
      document.getElementById('btnAddVarRow').style.display = enabled ? 'inline-block' : 'none';
      if (enabled && document.querySelectorAll('.var-row').length === 0) {
        addVariationRow('1 Layer (6-inch)', 35.00, 'Serves 4-6 pax');
        addVariationRow('2 Layers (8-inch)', 60.00, 'Serves 8-12 pax');
      }
    }

    function addVariationRow(name = '', price = '', desc = '') {
      const container = document.getElementById('variationsRowsContainer');
      const row = document.createElement('div');
      row.className = 'var-row';
      row.innerHTML = `
        <input type="text" class="var-name form-control" placeholder="e.g. 2 Layers (8-inch)" value="${escapeHtml(name)}" style="padding: 0.35rem 0.5rem; font-size: 0.75rem; border-radius: 4px; border: 1px solid var(--border-color); background: var(--bg-card); color: var(--text-main);">
        <input type="number" step="any" min="0" class="var-price form-control" placeholder="Price" value="${price}" style="padding: 0.35rem 0.5rem; font-size: 0.75rem; border-radius: 4px; border: 1px solid var(--border-color); background: var(--bg-card); color: var(--text-main);">
        <input type="text" class="var-desc form-control" placeholder="e.g. Serves 8-12 pax" value="${escapeHtml(desc)}" style="padding: 0.35rem 0.5rem; font-size: 0.75rem; border-radius: 4px; border: 1px solid var(--border-color); background: var(--bg-card); color: var(--text-main);">
        <button type="button" onclick="this.closest('.var-row').remove()" style="background: none; border: none; color: #ef4444; font-size: 1rem; cursor: pointer; padding: 0 4px;" title="Remove layer">&times;</button>
      `;
      container.appendChild(row);
    }

    function prepareProductSubmit() {
      const enabled = document.getElementById('chkEnableVariations').checked;
      if (!enabled) {
        document.getElementById('fieldVariationsJson').value = '';
        return true;
      }
      const rows = document.querySelectorAll('#variationsRowsContainer .var-row');
      const vars = [];
      rows.forEach(r => {
        const vName = r.querySelector('.var-name').value.trim();
        const vPrice = parseFloat(r.querySelector('.var-price').value) || 0;
        const vDesc = r.querySelector('.var-desc').value.trim();
        if (vName !== '') {
          vars.push({ name: vName, price: vPrice, description: vDesc });
        }
      });
      document.getElementById('fieldVariationsJson').value = vars.length > 0 ? JSON.stringify(vars) : '';
      return true;
    }

    function escapeHtml(s) {
      return String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    }

    // ── Modal Open / Edit ────────────────────────────────────
    function openAddProductModal() {
      document.getElementById('formAction').value = 'create_product';
      document.getElementById('formProductId').value = '';
      document.getElementById('modalTitle').textContent = 'Add Product / Cake';
      document.getElementById('modalSubmitBtn').textContent = 'Save Product';
      document.getElementById('fieldName').value = '';
      document.getElementById('fieldCategory').value = 'Cakes';
      document.getElementById('fieldSku').value = 'CK-' + Math.floor(1000 + Math.random() * 9000);
      document.getElementById('fieldPrice').value = '45.00';
      document.getElementById('fieldDescription').value = '';
      document.getElementById('fieldImageUrl').value = '';
      document.getElementById('fieldActionLabel').value = 'Add to Cart';
      document.getElementById('modeBooking').checked = true;
      document.getElementById('fieldStockQuantity').value = '0';
      toggleFulfillmentFields();

      // Variations reset
      document.getElementById('chkEnableVariations').checked = false;
      document.getElementById('variationsRowsContainer').innerHTML = '';
      toggleVariationsSection();

      document.getElementById('imagePreviewContainer').style.display = 'none';
      document.getElementById('productModal').classList.add('active');
    }

    function editProduct(product) {
      document.getElementById('formAction').value = 'update_product';
      document.getElementById('formProductId').value = product.id;
      document.getElementById('modalTitle').textContent = 'Edit Product / Cake';
      document.getElementById('modalSubmitBtn').textContent = 'Update Product';
      document.getElementById('fieldName').value = product.name || '';
      document.getElementById('fieldCategory').value = product.category || '';
      document.getElementById('fieldSku').value = product.sku || '';
      document.getElementById('fieldPrice').value = product.price || '';
      document.getElementById('fieldCurrency').value = product.currency || 'PHP';
      document.getElementById('fieldDescription').value = product.description || '';
      document.getElementById('fieldImageUrl').value = product.image_url || '';
      document.getElementById('fieldActionLabel').value = product.action_label || 'Add to Cart';

      // Fulfillment mode
      if (product.fulfillment_mode === 'stock') {
        document.getElementById('modeStock').checked = true;
      } else {
        document.getElementById('modeBooking').checked = true;
      }
      document.getElementById('fieldStockQuantity').value = product.stock_quantity || 0;
      toggleFulfillmentFields();

      // Variations
      document.getElementById('variationsRowsContainer').innerHTML = '';
      let vars = [];
      try {
        if (typeof product.variations === 'string' && product.variations.trim()) {
          vars = JSON.parse(product.variations);
        } else if (Array.isArray(product.variations)) {
          vars = product.variations;
        }
      } catch (e) {}

      if (Array.isArray(vars) && vars.length > 0) {
        document.getElementById('chkEnableVariations').checked = true;
        toggleVariationsSection();
        vars.forEach(v => addVariationRow(v.name, v.price, v.description));
      } else {
        document.getElementById('chkEnableVariations').checked = false;
        toggleVariationsSection();
      }

      if (product.image_url) {
        document.getElementById('imagePreview').src = product.image_url;
        document.getElementById('imagePreviewContainer').style.display = 'block';
      } else {
        document.getElementById('imagePreviewContainer').style.display = 'none';
      }
      document.getElementById('productModal').classList.add('active');
    }

    function closeProductModal() {
      document.getElementById('productModal').classList.remove('active');
    }

    function openBatchPriceModal() {
      document.getElementById('batchPriceModal').classList.add('active');
    }
    function closeBatchPriceModal() {
      document.getElementById('batchPriceModal').classList.remove('active');
    }

    // ── Camera Snapshot Engine ───────────────────────────────
    async function openCameraModal() {
      document.getElementById('liveCameraModal').classList.add('active');
      startCamera(currentFacingMode);
    }
    function closeCameraModal() {
      stopCamera();
      document.getElementById('liveCameraModal').classList.remove('active');
    }
    async function startCamera(mode) {
      stopCamera();
      try {
        cameraStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: mode, width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false
        });
        const video = document.getElementById('cameraVideo');
        video.srcObject = cameraStream;
      } catch (err) {
        alert('Could not access camera: ' + err.message + '. You may select an image file instead.');
        closeCameraModal();
      }
    }
    function stopCamera() {
      if (cameraStream) {
        cameraStream.getTracks().forEach(t => t.stop());
        cameraStream = null;
      }
    }
    function switchCamera() {
      currentFacingMode = currentFacingMode === 'environment' ? 'user' : 'environment';
      startCamera(currentFacingMode);
    }
    function takeSnapshot() {
      const video = document.getElementById('cameraVideo');
      const canvas = document.getElementById('cameraCanvas');
      if (!video || !canvas) return;

      const maxDim = 800;
      let w = video.videoWidth || 640;
      let h = video.videoHeight || 480;
      if (w > maxDim || h > maxDim) {
        if (w > h) { h = Math.round((h * maxDim) / w); w = maxDim; }
        else { w = Math.round((w * maxDim) / h); h = maxDim; }
      }
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0, w, h);

      const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.82);
      document.getElementById('fieldImageUrl').value = compressedDataUrl;
      document.getElementById('imagePreview').src = compressedDataUrl;
      document.getElementById('imagePreviewContainer').style.display = 'block';

      closeCameraModal();
    }

    function handleImageFileSelect(e) {
      const file = e.target.files && e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = function(evt) {
        const img = new Image();
        img.onload = function() {
          const canvas = document.createElement('canvas');
          const maxDim = 800;
          let w = img.width;
          let h = img.height;
          if (w > maxDim || h > maxDim) {
            if (w > h) { h = Math.round((h * maxDim) / w); w = maxDim; }
            else { w = Math.round((w * maxDim) / h); h = maxDim; }
          }
          canvas.width = w;
          canvas.height = h;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, w, h);
          const compressed = canvas.toDataURL('image/jpeg', 0.82);
          document.getElementById('fieldImageUrl').value = compressed;
          document.getElementById('imagePreview').src = compressed;
          document.getElementById('imagePreviewContainer').style.display = 'block';
        };
        img.src = evt.target.result;
      };
      reader.readAsDataURL(file);
    }
  </script>
</body>
</html>
