<?php
/**
 * Bookings & Event Orders Dashboard
 * Real-time orders from website culinary grid, cart, and made-to-order cake bookings
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/header.php';

$pdo = db();
$msg = '';
$error = '';

// Self-healing: create bookings table if not exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS bookings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        booking_ref VARCHAR(50) UNIQUE NOT NULL,
        customer_name VARCHAR(150) NOT NULL,
        customer_phone VARCHAR(50) NOT NULL,
        customer_email VARCHAR(150) NULL,
        delivery_type VARCHAR(50) DEFAULT 'pickup',
        delivery_address TEXT NULL,
        event_date DATE NULL,
        event_time VARCHAR(30) NULL,
        dedication_text TEXT NULL,
        items_json LONGTEXT NOT NULL,
        total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        currency VARCHAR(10) DEFAULT 'PHP',
        status VARCHAR(30) DEFAULT 'pending',
        notes TEXT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_status (status),
        INDEX idx_event_date (event_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Throwable $e) {}

// Handle Status Updates & Actions (Post-Redirect-Get pattern)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_status') {
        $id = (int)($_POST['booking_id'] ?? 0);
        $newStatus = trim($_POST['status'] ?? 'pending');
        $validStatuses = ['pending', 'confirmed', 'preparing', 'ready', 'completed', 'cancelled'];
        if ($id > 0 && in_array($newStatus, $validStatuses, true)) {
            try {
                $stmt = $pdo->prepare("UPDATE bookings SET status = ? WHERE id = ?");
                $stmt->execute([$newStatus, $id]);
                header("Location: bookings.php?updated=1");
                exit;
            } catch (Throwable $e) {
                $error = "Failed to update booking status: " . $e->getMessage();
            }
        }
    } elseif ($action === 'delete_booking') {
        $id = (int)($_POST['booking_id'] ?? 0);
        if ($id > 0) {
            try {
                $stmt = $pdo->prepare("DELETE FROM bookings WHERE id = ?");
                $stmt->execute([$id]);
                header("Location: bookings.php?deleted=1");
                exit;
            } catch (Throwable $e) {
                $error = "Failed to delete booking: " . $e->getMessage();
            }
        }
    }
}

// Export CSV handler
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=bookings_' . date('Y-m-d') . '.csv');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Ref', 'Customer Name', 'Phone', 'Email', 'Type', 'Address', 'Event Date', 'Event Time', 'Cake Dedication', 'Total Amount', 'Status', 'Date Booked']);
    $rows = $pdo->query("SELECT * FROM bookings ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) {
        fputcsv($out, [
            $r['booking_ref'],
            $r['customer_name'],
            $r['customer_phone'],
            $r['customer_email'],
            $r['delivery_type'],
            $r['delivery_address'],
            $r['event_date'],
            $r['event_time'],
            $r['dedication_text'],
            $r['currency'] . ' ' . number_format((float)$r['total_amount'], 2),
            $r['status'],
            $r['created_at']
        ]);
    }
    fclose($out);
    exit;
}

if (isset($_GET['updated'])) $msg = "Booking status updated successfully!";
if (isset($_GET['deleted'])) $msg = "Booking deleted successfully.";

// Fetch all bookings
$bookings = [];
try {
    $stmt = $pdo->query("SELECT * FROM bookings ORDER BY id DESC LIMIT 200");
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {}

// Calculate quick stats
$totalBookings = count($bookings);
$pendingCount = 0;
$confirmedCount = 0;
$totalRevenue = 0.0;
foreach ($bookings as $b) {
    if ($b['status'] === 'pending') $pendingCount++;
    if (in_array($b['status'], ['confirmed', 'preparing', 'ready'], true)) $confirmedCount++;
    if ($b['status'] !== 'cancelled') $totalRevenue += (float)$b['total_amount'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bookings & Event Orders - <?php echo htmlspecialchars(APP_NAME); ?></title>
  <link rel="stylesheet" href="../assets/css/admin.css">
  <style>
    .booking-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(360px, 1fr));
      gap: 1.25rem;
    }
    .booking-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: var(--radius-md);
      padding: 1.25rem;
      display: flex;
      flex-direction: column;
      gap: 0.85rem;
      transition: all 0.2s ease;
      position: relative;
    }
    .booking-card:hover {
      border-color: #6366f1;
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(0,0,0,0.12);
    }
    .status-badge {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 3px 10px;
      border-radius: 99px;
      font-size: 0.72rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .status-pending { background: rgba(245, 158, 11, 0.15); color: #f59e0b; border: 1px solid rgba(245, 158, 11, 0.3); }
    .status-confirmed { background: rgba(59, 130, 246, 0.15); color: #3b82f6; border: 1px solid rgba(59, 130, 246, 0.3); }
    .status-preparing { background: rgba(168, 85, 247, 0.15); color: #a855f7; border: 1px solid rgba(168, 85, 247, 0.3); }
    .status-ready { background: rgba(6, 182, 212, 0.15); color: #06b6d4; border: 1px solid rgba(6, 182, 212, 0.3); }
    .status-completed { background: rgba(16, 185, 129, 0.15); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.3); }
    .status-cancelled { background: rgba(239, 68, 68, 0.15); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.3); }
    .dedication-box {
      background: rgba(236, 72, 153, 0.08);
      border: 1px dashed rgba(236, 72, 153, 0.4);
      border-radius: 8px;
      padding: 0.65rem 0.85rem;
      font-size: 0.8rem;
      color: #ec4899;
      line-height: 1.4;
    }
    .item-pill {
      background: var(--bg-subtle);
      border: 1px solid var(--border-color);
      border-radius: 6px;
      padding: 0.45rem 0.65rem;
      font-size: 0.78rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 4px;
    }
    .toolbar-bar {
      display: flex;
      flex-wrap: wrap;
      gap: 0.75rem;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 1.25rem;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      padding: 0.85rem 1.15rem;
      border-radius: var(--radius-sm);
    }
  </style>
</head>
<body class="app-page">
  <?php renderAdminHeader('bookings'); ?>

  <main class="main-content">
    <header class="topbar">
      <div class="topbar-left">
        <span class="eyebrow">ORDER FULFILLMENT</span>
        <h1 class="page-title">📅 Bookings & Event Orders</h1>
        <p class="page-subtitle">View and manage made-to-order cake bookings, retail utensil orders, event dates, and custom dedications.</p>
      </div>

      <div class="topbar-right">
        <a href="bookings.php?export=csv" class="btn btn-outline btn-sm" title="Download bookings as CSV spreadsheet">
          📊 Export CSV
        </a>
        <button type="button" class="btn-theme-toggle theme-toggle" title="Toggle Theme">
          🌙 Dark Mode
        </button>
      </div>
    </header>

    <?php if ($msg): ?>
      <div class="alert alert-success" style="padding: 0.85rem 1.25rem; border-radius: var(--radius-sm); margin-bottom: 1.25rem; background: rgba(16, 185, 129, 0.12); border-left: 4px solid #10b981; color: #10b981; font-size: 0.875rem;">
        <?php echo htmlspecialchars($msg); ?>
      </div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div class="alert alert-danger" style="padding: 0.85rem 1.25rem; border-radius: var(--radius-sm); margin-bottom: 1.25rem; background: rgba(239, 68, 68, 0.12); border-left: 4px solid #ef4444; color: #ef4444; font-size: 0.875rem;">
        <?php echo htmlspecialchars($error); ?>
      </div>
    <?php endif; ?>

    <!-- Summary KPI Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.25rem;">
      <div class="card" style="padding: 1rem 1.25rem;">
        <span style="font-size: 0.75rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase;">Total Orders</span>
        <div style="font-size: 1.6rem; font-weight: 800; color: var(--text-main); margin-top: 4px;"><?php echo $totalBookings; ?></div>
      </div>
      <div class="card" style="padding: 1rem 1.25rem; border-left: 3px solid #f59e0b;">
        <span style="font-size: 0.75rem; color: #f59e0b; font-weight: 600; text-transform: uppercase;">⏳ Pending Confirmation</span>
        <div style="font-size: 1.6rem; font-weight: 800; color: #f59e0b; margin-top: 4px;"><?php echo $pendingCount; ?></div>
      </div>
      <div class="card" style="padding: 1rem 1.25rem; border-left: 3px solid #3b82f6;">
        <span style="font-size: 0.75rem; color: #3b82f6; font-weight: 600; text-transform: uppercase;">🎂 In Kitchen / Confirmed</span>
        <div style="font-size: 1.6rem; font-weight: 800; color: #3b82f6; margin-top: 4px;"><?php echo $confirmedCount; ?></div>
      </div>
      <div class="card" style="padding: 1rem 1.25rem; border-left: 3px solid #10b981;">
        <span style="font-size: 0.75rem; color: #10b981; font-weight: 600; text-transform: uppercase;">💰 Total Value</span>
        <div style="font-size: 1.6rem; font-weight: 800; color: #10b981; margin-top: 4px;">₱<?php echo number_format($totalRevenue, 2); ?></div>
      </div>
    </div>

    <!-- Filter & Search Toolbar -->
    <div class="toolbar-bar">
      <div style="display: flex; gap: 0.6rem; align-items: center; flex: 1; min-width: 260px;">
        <input type="text" id="bookingSearchInput" oninput="filterBookings()" placeholder="🔍 Search by customer name, phone, ref, dedication..." style="width: 100%; max-width: 380px; padding: 0.45rem 0.75rem; font-size: 0.8rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);">
        <select id="bookingStatusFilter" onchange="filterBookings()" style="padding: 0.45rem 0.75rem; font-size: 0.8rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main);">
          <option value="all">All Statuses</option>
          <option value="pending">⏳ Pending</option>
          <option value="confirmed">✓ Confirmed</option>
          <option value="preparing">🎂 Preparing / Baking</option>
          <option value="ready">📦 Ready for Pickup</option>
          <option value="completed">🎉 Completed</option>
          <option value="cancelled">❌ Cancelled</option>
        </select>
      </div>
      <span id="bookingCountBadge" style="font-size: 0.8rem; color: var(--text-muted);">
        Showing <?php echo $totalBookings; ?> bookings
      </span>
    </div>

    <!-- Bookings Cards Grid -->
    <?php if (empty($bookings)): ?>
      <div class="card" style="text-align: center; padding: 3rem 1rem;">
        <div style="font-size: 2.5rem; margin-bottom: 0.75rem;">🎂</div>
        <h3 style="margin: 0 0 0.5rem; font-size: 1.1rem; font-weight: 700;">No Bookings Received Yet</h3>
        <p style="margin: 0 0 1.25rem; font-size: 0.85rem; color: var(--text-muted); max-width: 480px; margin-left: auto; margin-right: auto;">
          When visitors order from your Culinary Grid add-on on your website or book a cake, orders will appear here in real time.
        </p>
      </div>
    <?php else: ?>
      <div class="booking-grid" id="bookingGrid">
        <?php foreach ($bookings as $b): 
          $items = @json_decode($b['items_json'], true) ?: [];
          $cleanPhone = preg_replace('/[^0-9]/', '', $b['customer_phone']);
          $waMsg = urlencode("Hi {$b['customer_name']}! Regarding your order {$b['booking_ref']} for " . ($b['event_date'] ?: 'your event') . ": ");
          $waLink = !empty($cleanPhone) ? "https://wa.me/{$cleanPhone}?text={$waMsg}" : "#";
        ?>
          <div class="booking-card" 
               data-ref="<?php echo htmlspecialchars($b['booking_ref']); ?>"
               data-name="<?php echo htmlspecialchars($b['customer_name']); ?>"
               data-phone="<?php echo htmlspecialchars($b['customer_phone']); ?>"
               data-dedication="<?php echo htmlspecialchars($b['dedication_text'] ?? ''); ?>"
               data-status="<?php echo htmlspecialchars($b['status']); ?>">
            
            <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 8px;">
              <div>
                <span style="font-family: monospace; font-size: 0.78rem; color: #6366f1; font-weight: 700;">
                  <?php echo htmlspecialchars($b['booking_ref']); ?>
                </span>
                <h3 style="margin: 2px 0 0; font-size: 1.05rem; font-weight: 700; color: var(--text-main);">
                  <?php echo htmlspecialchars($b['customer_name']); ?>
                </h3>
              </div>
              <span class="status-badge status-<?php echo htmlspecialchars($b['status']); ?>">
                <?php echo htmlspecialchars($b['status']); ?>
              </span>
            </div>

            <!-- Event Date & Delivery Badge -->
            <div style="display: flex; gap: 8px; flex-wrap: wrap; font-size: 0.78rem;">
              <?php if (!empty($b['event_date'])): ?>
                <span style="background: rgba(99,102,241,0.12); color: #818cf8; padding: 3px 8px; border-radius: 6px; font-weight: 600;">
                  📅 Event: <?php echo date('M d, Y', strtotime($b['event_date'])); ?> <?php echo htmlspecialchars($b['event_time'] ?? ''); ?>
                </span>
              <?php endif; ?>
              <span style="background: var(--bg-subtle); color: var(--text-muted); padding: 3px 8px; border-radius: 6px;">
                <?php echo $b['delivery_type'] === 'delivery' ? '🚚 Delivery' : '🏪 Store Pickup'; ?>
              </span>
            </div>

            <?php if (!empty($b['delivery_address'])): ?>
              <div style="font-size: 0.78rem; color: var(--text-muted);">
                📍 <strong>Address:</strong> <?php echo htmlspecialchars($b['delivery_address']); ?>
              </div>
            <?php endif; ?>

            <!-- Cake Dedication Text -->
            <?php if (!empty($b['dedication_text'])): ?>
              <div class="dedication-box">
                <strong>🎂 Cake Dedication:</strong><br>
                "<?php echo htmlspecialchars($b['dedication_text']); ?>"
              </div>
            <?php endif; ?>

            <!-- Ordered Items List -->
            <div>
              <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase; margin-bottom: 4px;">
                Cart Items (<?php echo count($items); ?>):
              </div>
              <?php foreach ($items as $it): ?>
                <div class="item-pill">
                  <div>
                    <strong><?php echo (int)($it['quantity'] ?? 1); ?>x</strong> 
                    <?php echo htmlspecialchars($it['name'] ?? 'Product'); ?>
                    <?php if (!empty($it['variation'])): ?>
                      <span style="color: #ec4899; font-weight: 600;">[<?php echo htmlspecialchars($it['variation']); ?>]</span>
                    <?php endif; ?>
                  </div>
                  <span style="font-weight: 700; color: var(--text-main);">
                    <?php echo htmlspecialchars($it['price'] ?? ''); ?>
                  </span>
                </div>
              <?php endforeach; ?>
            </div>

            <!-- Total Price & Contact Phone -->
            <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 0.5rem; border-top: 1px solid var(--border-color);">
              <div>
                <span style="font-size: 0.75rem; color: var(--text-muted);">Total Order:</span>
                <div style="font-size: 1.15rem; font-weight: 800; color: #10b981;">
                  <?php echo htmlspecialchars($b['currency']); ?> <?php echo number_format((float)$b['total_amount'], 2); ?>
                </div>
              </div>
              <div style="text-align: right;">
                <a href="<?php echo htmlspecialchars($waLink); ?>" target="_blank" rel="noopener" class="btn btn-outline btn-sm" style="border-color: #25d366; color: #25d366; padding: 4px 10px; font-size: 0.75rem;">
                  💬 WhatsApp: <?php echo htmlspecialchars($b['customer_phone']); ?>
                </a>
              </div>
            </div>

            <!-- Status Changer & Actions -->
            <div style="display: flex; gap: 6px; align-items: center; justify-content: space-between; margin-top: 4px;">
              <form method="POST" style="margin: 0; display: flex; gap: 6px; align-items: center; flex: 1;">
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="booking_id" value="<?php echo (int)$b['id']; ?>">
                <select name="status" onchange="this.form.submit()" style="padding: 3px 8px; font-size: 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); background: var(--bg-subtle); color: var(--text-main); flex: 1;">
                  <option value="pending" <?php if($b['status']==='pending') echo 'selected'; ?>>⏳ Set: Pending</option>
                  <option value="confirmed" <?php if($b['status']==='confirmed') echo 'selected'; ?>>✓ Set: Confirmed</option>
                  <option value="preparing" <?php if($b['status']==='preparing') echo 'selected'; ?>>🎂 Set: Preparing / Baking</option>
                  <option value="ready" <?php if($b['status']==='ready') echo 'selected'; ?>>📦 Set: Ready for Pickup</option>
                  <option value="completed" <?php if($b['status']==='completed') echo 'selected'; ?>>🎉 Set: Completed</option>
                  <option value="cancelled" <?php if($b['status']==='cancelled') echo 'selected'; ?>>❌ Set: Cancelled</option>
                </select>
              </form>

              <form method="POST" style="margin: 0;" onsubmit="return confirm('Permanently delete this booking record?');">
                <input type="hidden" name="action" value="delete_booking">
                <input type="hidden" name="booking_id" value="<?php echo (int)$b['id']; ?>">
                <button type="submit" class="btn btn-outline btn-sm" style="color: #ef4444; border-color: rgba(239,68,68,0.3); padding: 3px 8px; font-size: 0.75rem;">
                  🗑️
                </button>
              </form>
            </div>

            <div style="font-size: 0.7rem; color: var(--text-dim); text-align: right;">
              Booked: <?php echo date('M d, Y h:i A', strtotime($b['created_at'])); ?>
            </div>

          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  </main>

  <script>
    function filterBookings() {
      const q = (document.getElementById('bookingSearchInput').value || '').toLowerCase().trim();
      const status = document.getElementById('bookingStatusFilter').value;
      const cards = document.querySelectorAll('#bookingGrid .booking-card');
      let visible = 0;

      cards.forEach(card => {
        const ref = (card.dataset.ref || '').toLowerCase();
        const name = (card.dataset.name || '').toLowerCase();
        const phone = (card.dataset.phone || '').toLowerCase();
        const dedication = (card.dataset.dedication || '').toLowerCase();
        const cardStatus = card.dataset.status || 'pending';

        const matchesSearch = !q || ref.includes(q) || name.includes(q) || phone.includes(q) || dedication.includes(q);
        const matchesStatus = (status === 'all' || cardStatus === status);

        if (matchesSearch && matchesStatus) {
          card.style.display = '';
          visible++;
        } else {
          card.style.display = 'none';
        }
      });

      const badge = document.getElementById('bookingCountBadge');
      if (badge) badge.textContent = `Showing ${visible} of ${cards.length} bookings`;
    }
  </script>
</body>
</html>

